module.exports = {
	apps: [
		{
			name: "schoolapp-api",
			script: "./server/main.js",
			watch: true,
			env: {
				NODE_ENV: "development",
			},
			env_production: {
				NODE_ENV: "production",
			},
		},
		// {
		// 	name: "schoolapp-client",
		// 	script: "./client/index.html",
		// 	watch: true,
		// 	env: {
		// 		NODE_ENV: "development",
		// 	},
		// 	env_production: {
		// 		NODE_ENV: "production",
		// 	},
		// },
	],
};
