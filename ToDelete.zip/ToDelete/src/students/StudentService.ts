import { injectable } from "inversify";
import { getManager, getConnection, EntityManager, Like } from "typeorm";
import { IStudent, IParents, IAddress, IStudentFilter } from "./IStudent";
import { Students } from "../core/entities/Students/Student";
import { BadRequest, BadMapping, InternalServerError, NotFound } from "../core/exceptions";
import { Address } from "../core/entities/Students/Address";
import { Parents } from "../core/entities/Students/Parents";
import { AcadYear } from "../core/entities/Master/AcadYear";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { Length, Validator } from "class-validator";

@injectable()
export class StudentService {
	constructor() { }

	private errorArr = Array<string>();

	public async addNewAdmission(profile: IStudent, parents: IParents, address: IAddress, classId: string, currentUser: string): Promise<any> {

		this.errorArr = [];
		const validateError = this.validateAll(profile, parents, address);
		if (validateError.length) {
			this.errorArr = [];
			throw new Error(`Please enter the mandatory fields. ${validateError}`);
		}

		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const studNo = await this.getNewStudentNo();

			const addressEntity = Object.assign(new Address(), address);
			addressEntity.createdby = currentUser;

			await queryRunner.manager.save(addressEntity)
				.catch(error => {
					throw new NotFound("Unable to save", error);
				});

			const parentsEntity = Object.assign(new Parents(), parents);
			parentsEntity.address = [addressEntity];
			parentsEntity.createdby = currentUser;

			await queryRunner.manager.save(parentsEntity)
				.catch(error => {
					throw new NotFound("Unable to save", error);
				});

			const studentEntity = Object.assign(new Students(), profile);
			studentEntity.studentno = studNo.studentno;
			studentEntity.prefixyear = studNo.prefixyear;
			studentEntity.parents = [parentsEntity];
			studentEntity.createdby = currentUser;

			const res = await queryRunner.manager.save(studentEntity)
				.then(stud => {
					return stud;
				})
				.catch(error => {
					throw new NotFound("Unable to save", error);
				});

			const studentId = res.id;
			const response = await this.addStudentClass(studentId, classId, queryRunner.manager);

			await queryRunner.commitTransaction();
			if (response) {
				return res;
			} else {
				throw new InternalServerError("Unhandled Error: Unable to save");
			}

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	private async addStudentClass(studentId: string, classId: string, queryRunner: EntityManager): Promise<any> {
		try {
			if (studentId.length === 0 || !classId.length) {
				throw new BadRequest("Student Id or Class Id is missing.");
			}

			const res = await queryRunner
				.getRepository(Students)
				.createQueryBuilder()
				.relation(Students, "classsec")
				.of(studentId)
				.add(classId)
				.then(res => {
					return { Messages: "Student has been admitted to the Class" };
				})
				.catch(err => {
					throw new BadMapping(
						"Student and Class Mapping not match. Please select Student and Class"
					);
				});
			return res;
		} catch (error) {
			throw error;
		}
	}

	public async editProfileParents(id: string, profile: IStudent, parents: IParents, classId: string, currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			this.errorArr = [];
			const validateError = this.validateStudent(profile);
			if (validateError.length) {
				this.errorArr = [];
				throw new BadRequest(`Please enter the mandatory fields. ${validateError}`);
			}

			const studentEntity = Object.assign(new Students(), profile);
			studentEntity.updatedby = currentUser;

			const profileRes = await queryRunner.manager
				.getRepository(Students)
				.update(id, studentEntity);

			const parentsRes = await this.editParents(parents, currentUser, queryRunner.manager);
			// await this.editStudentClass(id, classId, queryRunner.manager);
			await queryRunner.commitTransaction();

			return profileRes;
		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	private async editStudentClass(studentId: string, classId: string, queryRunner: EntityManager): Promise<any> {
		try {
			let success = false;
			if (!classId || !studentId) {
				throw new BadRequest("Student Id or Class Id is missing");
			}
			const isExists = await getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.classsec", "classsec")
				.select(["stud.id", "classsec.id"])
				.where("stud.id = :studId", { studId: studentId })
				.getMany();

			const chkArray: [string] = [""];
			isExists.map((v) => {
				return v.classsec.map((m) => {
					return chkArray.push(m.id);
				});
			});

			if (isExists.length) {
				await queryRunner
					.getRepository(Students)
					.createQueryBuilder()
					.relation(Students, "classsec")
					.of(studentId)
					.remove(chkArray)
					.then(() => {
						success = true;
						return true;
					})
					.catch(err => {
						success = false;
						throw new BadMapping(
							"Remove Failed: Student and Class Mapping not match. Please select Student and Class."
						);
					});
			}

			if (success) {
				await queryRunner
					.getRepository(Students)
					.createQueryBuilder()
					.relation(Students, "classsec")
					.of(studentId)
					.add(classId)
					.then(res => {
						return { Messages: "Student has been assigned to the Class" };
					})
					.catch(err => {
						throw new BadMapping(
							"Student and Class Mapping not match. Please select Student and Class"
						);
					});
			}

			return true;
		} catch (error) {
			throw new BadMapping(
				"Student and Class Mapping not match. Please select Student and Class."
			);
		}
	}

	private async editParents(parents: IParents, currentUser: string, queryRunner: EntityManager): Promise<any> {
		try {
			this.errorArr = [];
			const validateError = this.validateParents(parents);
			if (validateError.length) {
				this.errorArr = [];
				throw new BadRequest(`Please enter the mandatory fields. ${validateError}`);
			}

			const parentsEntity = Object.assign(new Parents(), parents);
			parentsEntity.updatedby = currentUser;
			const parentId = parents.id;

			const res = await queryRunner
				.getRepository(Parents)
				.update(parentId, parentsEntity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editAddress(id: string, address: IAddress, currentUser: string): Promise<any> {
		try {
			this.errorArr = [];
			const validateError = this.validateAddress(address);
			if (validateError.length) {
				this.errorArr = [];
				throw new BadRequest(`Please enter the mandatory fields. ${validateError}`);
			}

			const addressEntity = Object.assign(new Address(), address);
			addressEntity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(Address)
				.update(id, addressEntity);

			return res;

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async studentParentsAdd(id: string, parents: IParents, currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();
			this.errorArr = [];
			const validateError = this.validateParents(parents);
			if (validateError.length) {
				this.errorArr = [];
				throw new BadRequest(`Please enter the mandatory fields. ${validateError}`);
			}

			const parentsEntity = Object.assign(new Parents(), parents);
			parentsEntity.createdby = currentUser;
			await queryRunner.manager.save(parentsEntity)
				.catch(error => {
					throw new NotFound("Unable to save parents info", error);
				});

			await queryRunner.manager
				.getRepository(Students)
				.createQueryBuilder()
				.relation(Students, "parents")
				.of(id)
				.add(parentsEntity.id)
				.then(res => {
					return { Messages: "Parents has been added" };
				})
				.catch(err => {
					throw new BadMapping(
						"Parents not match."
					);
				});

			// const studentEntity = await getManager()
			// 	.getRepository(Students)
			// 	.createQueryBuilder("stud")
			// 	.where("stud.id = :value", { value: id })
			// 	.getOne();

			// // const studentEntity = new Students();
			// studentEntity.parents = [parentsEntity];

			// const res = await queryRunner.manager.save(studentEntity)
			// 	.then(stud => {
			// 		return stud;
			// 	})
			// 	.catch(error => {
			// 		throw new NotFound("Unable to save", error);
			// 	});

			await queryRunner.commitTransaction();
			return true;
		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async studentInactive(id: string, currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const allIds = await this.findOnlyIds(id);

			const studentId = allIds.id;
			const studentFName = allIds.firstname;
			await queryRunner.manager
				.createQueryBuilder()
				.update(Students)
				.set({
					isactive: false,
					updatedby: currentUser
				})
				.where("id = :id", { id: studentId })
				.execute()
				.catch(error => {
					throw new NotFound("Unable to save", error);
				});

			allIds.parents.map(async p => {
				return await queryRunner.manager
					.createQueryBuilder()
					.update(Parents)
					.set({
						isactive: false,
						updatedby: currentUser
					})
					.where("id = :id", { id: p.id })
					.execute()
					.catch(error => {
						throw new NotFound("Unable to save", error);
					});
			});

			allIds.parents.map(p => {
				return p.address.map(async addr => {
					await queryRunner.manager
						.createQueryBuilder()
						.update(Address)
						.set({
							isactive: false,
							updatedby: currentUser
						})
						.where("id = :id", { id: addr.id })
						.execute()
						.catch(error => {
							throw new NotFound("Unable to save", error);
						});

					return addr.id;
				});
			});

			await queryRunner.commitTransaction();
			return { Messages: `${studentFName} has been deleted successfully` };

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async getStudent(id: string): Promise<any> {
		try {
			const result = await getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.classsec", "classsec")
				.leftJoinAndSelect("stud.parents", "parents")
				.leftJoinAndSelect("parents.address", "address")
				.where("stud.isactive = true")
				.andWhere("stud.id = :id", { id: id })
				.getOne();

			return result;
		} catch (error) {
			throw new NotFound(`Student not found. Please change the search criteria`);
		}
	}

	public async listStudents(pageNo: number, pageSize: number, sortCol: string, isAsc: string,
		filter: IStudentFilter): Promise<any> {
		try {
			const currenPageNo = pageNo - 1;
			const orderBy = sortCol ? sortCol : "stud.firstname";

			const qb = await getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.classsec", "classsec")
				.leftJoinAndSelect("stud.parents", "parents")
				.leftJoinAndSelect("parents.address", "address")
				.where("stud.isactive = true");

			if (filter.classId.length > 0 && filter.classId !== "ALL") {
				qb.andWhere("classsec.id = :clsId", { clsId: filter.classId });
			}
			if (filter.genderId.length > 0 && filter.genderId !== "ALL") {
				qb.andWhere("stud.gender = :genderId", { genderId: filter.genderId });
			}
			if (filter.textId.trim().length > 0) {
				qb.andWhere("stud.firstname like :textId", { textId: `%${filter.textId}%` });
			}

			qb.orderBy(orderBy, isAsc === "ASC" ? "ASC" : "DESC");
			qb.skip(currenPageNo * pageSize);
			qb.take(pageSize);

			const students = {
				rows: await qb.getMany(),
				count: await qb.getCount()
			};
			return students;
		} catch (error) {
			throw new NotFound(`Students not found. Please change the search criteria`);
		}
	}

	public async getStudentByClass(classId: string): Promise<any> {
		try {
			const qb = getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.classsec", "classsec")
				.where("stud.isactive = true");

			if (classId !== "ALL") {
				qb.andWhere("classsec.id = :id", { id: classId });
			}
			qb.orderBy("stud.gender", "DESC")
				.addOrderBy("stud.firstname", "ASC")
				.addOrderBy("stud.lastname", "ASC");

			const result = await qb.getMany();

			return result;
		} catch (error) {
			throw new NotFound(`Student not found. Please change the search criteria`);
		}
	}

	public async listParents(pageNo: number, pageSize: number): Promise<any> {
		try {
			const parents = await getManager()
				.getRepository(Parents)
				.createQueryBuilder("parents")
				.leftJoinAndSelect("parents.address", "address")
				.skip(pageNo)
				.take(pageSize)
				.getMany();
			return parents;
		} catch (error) {
			throw new NotFound(`Parents not found. Please change the search criteria`);
		}
	}

	public async listAddress(pageNo: number, pageSize: number): Promise<any> {
		try {
			const address = await getManager()
				.getRepository(Address)
				.createQueryBuilder()
				.skip(pageNo)
				.take(pageSize)
				.getMany();
			return address;
		} catch (error) {
			throw new NotFound(`Address not found. Please change the search criteria`);
		}
	}

	public async findStudentByParent(parentId: string): Promise<any> {
		try {
			const students = await getManager()
				.getRepository(Parents)
				.createQueryBuilder("parents")
				.leftJoinAndSelect("parents.students", "students")
				.leftJoinAndSelect("parents.address", "address")
				.where("parents.id = :value", { value: parentId })
				.getMany();
			return students;
		} catch (error) {
			throw new NotFound(`Data not found. Please change the search criteria`);
		}
	}

	public async findStudentByAddress(addressId: string): Promise<any> {
		try {
			const students = await getManager()
				.getRepository(Address)
				.createQueryBuilder("address")
				.leftJoinAndSelect("address.parents", "parents")
				.leftJoinAndSelect("parents.students", "students")
				.where("address.id = :value", { value: addressId })
				.getOne();
			return students;
		} catch (error) {
			throw new NotFound(`Data not found. Please change the search criteria`);
		}
	}

	private async findOnlyIds(id: string): Promise<Students> {
		try {
			return await getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.parents", "parents")
				.leftJoinAndSelect("parents.address", "address")
				.where("stud.id = :value", { value: id })
				.select(["stud.id", "stud.firstname", "parents.id", "address.id"])
				.getOne();
		} catch (error) {
			throw new InternalServerError("Error", error);
		}
	}

	private async findStudentById(id: string): Promise<any> {
		try {
			const student = await getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.parents", "parents")
				.leftJoinAndSelect("parents.address", "address")
				.where("stud.id = :value", { value: id })
				.getOne();
			return student;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async findOneStudent(id: string): Promise<any> {
		try {
			return await getManager()
				.getRepository(Students)
				.findOne({ where: { id: id } })
				.catch(error => {
					throw new NotFound("Student not found", error);
				});
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async findOneParents(id: string): Promise<any> {
		try {
			return await getManager()
				.getRepository(Parents)
				.findOne({ where: { id: id } });
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async findOneAddress(id: string): Promise<any> {
		try {
			return await getManager()
				.getRepository(Address)
				.findOne({ where: { id: id } });
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async getNewStudentNo(): Promise<any> {
		try {

			let { studentno } = await getManager()
				.getRepository(Students)
				.createQueryBuilder("stud")
				.select("MAX(stud.studentno)", "studentno")
				.getRawOne();

			if (!studentno) {
				studentno = 0;
			}
			studentno = Number(studentno) + 1;

			let getPrefixYear = await getManager()
				.getRepository(AcadYear)
				.createQueryBuilder("acadyear")
				.select("acadyear.prefixyear", "prefixyear")
				.where("acadyear.is_current = :active", { active: true })
				.getRawOne();

			if (!getPrefixYear) {
				getPrefixYear = new Date().getFullYear().toString().substr(-2);
			}
			else {
				getPrefixYear = getPrefixYear.prefixyear;
			}
			getPrefixYear = getPrefixYear + "0";
			return { studentno: studentno, prefixyear: getPrefixYear };
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private validateAll(student: IStudent, parents: IParents, address: IAddress): Array<string> {
		this.validateStudent(student);
		this.validateParents(parents);
		this.validateAddress(address);
		return this.errorArr;
	}

	private validateStudent(student: IStudent): Array<string> {
		const validator = new Validator();
		if (validator.isEmpty(student)) this.errorArr.push("Student profile can not be empty");
		if (validator.isEmpty(student.firstname)) this.errorArr.push("First name can not be empty");
		if (validator.isEmpty(student.lastname)) this.errorArr.push("Last name can not be empty");
		if (validator.isEmpty(student.gender)) this.errorArr.push("Gender can not be empty");
		if (validator.isDate(student.dob)) this.errorArr.push("Date of Birth can not be empty");
		if (validator.isDate(student.doj)) this.errorArr.push("Date of Join can not be empty");

		return this.errorArr;
	}

	private validateParents(parents: IParents) {
		const validator = new Validator();
		if (validator.isEmpty(parents)) this.errorArr.push("Parents profile can not be empty");
		if (validator.isEmpty(parents.fathername)) this.errorArr.push("Father's First name can not be empty");
		if (validator.isEmpty(parents.fathergraduation)) this.errorArr.push("Graduation can not be empty");
		if (validator.isEmpty(parents.fatheroccupation)) this.errorArr.push("Occupation name can not be empty");
		if (validator.isEmpty(parents.fatherincome)) this.errorArr.push("Income can not be empty");

		return this.errorArr;
	}

	private validateAddress(address: IAddress) {
		const validator = new Validator();
		if (validator.isEmpty(address)) throw new BadRequest("Address profile can not be ");
		if (validator.isEmpty(address.type)) this.errorArr.push("Type of address can not be empty");
		if (validator.isEmpty(address.address1)) this.errorArr.push("Address-1 Type can not be empty");
		if (validator.isEmpty(address.city)) this.errorArr.push("City/Village can not be empty");
		if (validator.isEmpty(address.state)) this.errorArr.push("State can not be empty");
		if (validator.isEmpty(address.mobile)) this.errorArr.push("Mobile number can not be empty");

		return this.errorArr;
	}

}
