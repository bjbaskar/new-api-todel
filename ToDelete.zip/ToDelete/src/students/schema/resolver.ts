import { IAppContext } from "../../context";
import { IStudent, IParents, IAddress, IStudentFilter } from "../IStudent";

export const resolvers = {
	Query: {
		async getStudent(_: any, args: { id: string }, context: IAppContext) {
			const studService = context.StudentService;
			return await studService.getStudent(args.id);
		},
		studentList: async (_: any, args: {
			pageNo: number, pageSize: number, sortCol: string, isAsc: string,
			filter: IStudentFilter
		}, context: IAppContext) => {
			return await context.StudentService.listStudents(args.pageNo, args.pageSize, args.sortCol, args.isAsc, args.filter);
		},
		async getStudentByClass(_: any, args: { classId: string }, context: IAppContext) {
			const studService = context.StudentService;
			const res = await studService.getStudentByClass(args.classId);
			return res;
		}
		// parentsList: async (_: any, args: { pageNo: number, pageSize: number }, context: IAppContext) => {
		// 	return await context.StudentService.listParents(args.pageNo, args.pageSize);
		// },
		// addressList: async (_: any, args: { pageNo: number, pageSize: number }, context: IAppContext) => {
		// 	return await context.StudentService.listAddress(args.pageNo, args.pageSize);
		// },
		// studentByParent: async (_: any, args: { parentId: string }, context: IAppContext) => {
		// 	return await context.StudentService.findStudentByParent(args.parentId);
		// },
		// studentByAddress: async (_: any, args: { addressId: string }, context: IAppContext) => {
		// 	return await context.StudentService.findStudentByAddress(args.addressId);
		// }
	},
	Mutation: {
		async addNewAdmission(root: any, args: { profile: IStudent, parents: IParents, address: IAddress, class_section: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.StudentService.addNewAdmission(args.profile, args.parents, args.address, args.class_section, currentUser);
			return res;
		},
		async editProfileParents(
			root: any,
			args: { id: string; profile: IStudent, parents: IParents, classId: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.StudentService.editProfileParents(args.id, args.profile, args.parents, args.classId, currentUser);
			return res;
		},
		// async studentProfileEdit(
		// 	root: any,
		// 	args: { id: string; student: IStudent, classId: string },
		// 	context: IAppContext
		// ) {
		// 	const currentUser = context.CurrentUser.UserName;
		// 	const res = await context.StudentService.studentProfileEdit(args.id, args.student, args.classId, currentUser);
		// 	return res;
		// },
		// async studentParentsEdit(root: any,
		// 	args: { id: string, parents: IParents },
		// 	context: IAppContext) {
		// 	const currentUser = context.CurrentUser.UserName;
		// 	return await context.StudentService.studentParentsEdit(args.id, args.parents, currentUser);
		// },
		// async studentParentsAdd(root: any,
		// 	args: { id: string, parents: IParents },
		// 	context: IAppContext) {
		// 	const currentUser = context.CurrentUser.UserName;
		// 	return await context.StudentService.studentParentsAdd(args.id, args.parents, currentUser);
		// },
		async editAddress(root: any,
			args: { id: string, address: IAddress },
			context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			return await context.StudentService.editAddress(args.id, args.address, currentUser);
		},
		async studentInactive(
			root: any,
			args: { id: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.StudentService.studentInactive(args.id, currentUser);
			return res;
		}
	}
};
