import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const studentTypeDef = typeDef;
const studentResolver = resolvers;

export { studentTypeDef, studentResolver };
