
export interface IStudent {
	id: string;
	studentno: number;
	prefixyear: number;
	aadhaarno: string;
	emisno: string;
	udiseno: string;
	firstname: string;
	lastname: string;
	gender: string;
	dob: Date;
	doj: Date;
	nationality: string;
	religion: string;
	castecategory: string;
	community: string;
	mothertongue: string;
	bloodgroup: string;
	identification: string;
	isactive: boolean;
	disability: string;
	notes: string;
	parents: Array<IParents>;
}

export interface IParents {
	id: string;
	fathername: string;
	fatherdob: Date;
	fathergraduation: string;
	fatheroccupation: string;
	fathercompanyname: string;
	fatherincome: number;
	fatheraadhaarno: string;
	mothername: string;
	motherdob: Date;
	mothergraduation: string;
	motheroccupation: string;
	mothercompanyname: string;
	motherincome: number;
	motheraadhaarno: string;
	guardianname: string;
	guardianoccupation: string;
	notes: string;
	address: Array<IAddress>;
}

export interface IAddress {
	id: string;
	type: string;
	address1: string;
	address2: string;
	city: string;
	state: string;
	district: string;
	country: string;
	postalcode: number;
	mobile: string;
	homephone: string;
	email: string;
	notes: string;
}

export interface IStudentFilter {
	classId: string;
	genderId: string;
	textId: string;
}