import { IAppContext } from "../../context";
import { IAttendance } from "../IAttendance";

export const resolvers = {
	Query: {
		async getStudAttByClass(_: any, args: { classId: string, currDate: Date }, context: IAppContext) {
			const svr = context.AttendanceService;
			const res = await svr.getStudAttByClass(args.classId, args.currDate);
			return res;
		},
		async getPieChartByMonth(_: any, args: { classId: string, studentId: string, currDate: string }, context: IAppContext) {
			const svr = context.AttendanceService;
			const res = await svr.getPieChartByMonth(args.classId, args.studentId, args.currDate);
			return res;
		},
		async getPieChartClassWiseByMonth(_: any, args: { classId: string, currDate: string }, context: IAppContext) {
			const svr = context.AttendanceService;
			const res = await svr.getPieChartClassWiseByMonth(args.classId, args.currDate);
			return res;
		}
	},
	Mutation: {
		async addStudAttendance(root: any, args: { input: IAttendance }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AttendanceService.addStudAttendance(args.input, currentUser);
			return res;
		},
		async editStudAttendance(
			root: any,
			args: { input: IAttendance },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AttendanceService.editStudAttendance(args.input, currentUser);
			return res;
		},

	}
};
