import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const attendanceTypeDef = typeDef;
const attendanceResolver = resolvers;

export { attendanceTypeDef, attendanceResolver };