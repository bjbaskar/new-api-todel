import { injectable } from "inversify";
import { getManager, getConnection, EntityManager } from "typeorm";
import _ from "lodash";
import moment from "moment";
import { IAttendance } from "./IAttendance";
import { BadRequest, BadMapping, InternalServerError, NotFound } from "../core/exceptions";
import { Length, Validator } from "class-validator";
import { Attendance } from "../core/entities/Attendance/Attendance";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { Students } from "../core/entities/Students/Student";

@injectable()
export class AttendanceService {
	constructor() { }

	public async addStudAttendance(input: IAttendance, currentUser: string): Promise<any> {

		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const oData: Attendance[] = [];
			const studentsId = input.studentid;
			const allPresent = input.allpresent;

			if (allPresent === false && studentsId.length) {
				for (let i = 0; i <= studentsId.length - 1; i++) {
					const entity = new Attendance();
					entity.attdate = input.attdate;
					entity.classid = input.classid;
					entity.allpresent = input.allpresent;
					entity.session = input.session;
					entity.notes = input.notes;
					entity.studentid = studentsId[i];
					entity.createdby = currentUser;
					oData.push(entity);
				}
			} else {
				const entity = new Attendance();
				entity.attdate = input.attdate;
				entity.classid = input.classid;
				entity.allpresent = input.allpresent;
				entity.session = input.session;
				entity.notes = input.notes;
				entity.studentid = undefined;
				entity.createdby = currentUser;
				oData.push(entity);
			}

			const result = await queryRunner.manager
				.getRepository(Attendance)
				.save(oData);

			await queryRunner.commitTransaction();

			if (result) {
				return { Messages: "Attendance updated successfully" };
			} else {
				return { Messages: "No Records updated" };
			}
		}
		catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addStudAttendance Unhandled Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async editStudAttendance(input: IAttendance, currentUser: string): Promise<any> {

		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const oData: Attendance[] = [];
			const studentsId = input.studentid;
			const allPresent = input.allpresent;
			const todaysDate = moment(input.attdate).format("YYYY-MM-DD");
			let result = undefined;

			if (allPresent === false && studentsId.length) {
				for (let i = 0; i <= studentsId.length - 1; i++) {
					const entity = new Attendance();
					entity.attdate = input.attdate;
					entity.classid = input.classid;
					entity.allpresent = input.allpresent;
					entity.session = input.session;
					entity.notes = input.notes;
					entity.studentid = studentsId[i];
					entity.createdby = currentUser;
					oData.push(entity);
				}
			} else {
				const entity = new Attendance();
				entity.attdate = input.attdate;
				entity.classid = input.classid;
				entity.allpresent = input.allpresent;
				entity.session = input.session;
				entity.notes = input.notes;
				entity.studentid = undefined;
				entity.createdby = currentUser;
				oData.push(entity);
			}

			const res = await queryRunner.manager
				.createQueryBuilder()
				.delete()
				.from(Attendance)
				.where("classid = :classid", { classid: input.classid })
				.andWhere("DATE_FORMAT(attdate, '%Y-%m-%d') = :cDate", { cDate: todaysDate })
				.execute();
			if (res.affected >= 1) {
				result = await queryRunner.manager
					.getRepository(Attendance)
					.save(oData);
			} else {
				return { Messages: "No Records updated" };
			}

			await queryRunner.commitTransaction();

			if (result) {
				return { Messages: "Attendance updated successfully" };
			} else {
				return { Messages: "No Records updated" };
			}
		}
		catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addStudAttendance Unhandled Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async getStudAttByClass(classId: string, currDate: Date): Promise<any> {
		try {
			let isNew: boolean = true;
			let result = undefined;
			const todaysDate = moment(currDate).format("YYYY-MM-DD");
			const count = await this.getStudAttCount(classId, todaysDate);
			if (count > 0) {
				isNew = false;
			}

			if (isNew) {
				result = await getManager()
					.getRepository(Students)
					.createQueryBuilder("st")
					.select(["st.id", "st.firstname", "st.lastname", "st.gender"])
					.leftJoinAndSelect("st.classsec", "classsec")
					.where("st.isactive = true")
					.andWhere("classsec.id = :id", { id: classId })
					.orderBy("st.gender", "DESC")
					.addOrderBy("st.firstname", "ASC")
					.addOrderBy("st.lastname", "ASC")
					.getMany();
			} else {

				// if all student present in a class then return result from this.getAllPresentStudent()
				const allPresent = await this.getAllPresentStudent(classId, todaysDate);

				if (allPresent.length > 0) {
					result = allPresent;
				} else {

					const absentees = getManager()
						.createQueryBuilder()
						.select(["att.studId AS id",
							"att.firstname",
							"att.lastname",
							"att.gender",
							"'absent' AS selected"])
						.from(subQry => {
							const qb = subQry
								.select([
									"a.id",
									"s.id AS studId",
									"s.firstname AS firstname",
									"s.lastname AS lastname",
									"s.gender AS gender"])
								.from(Attendance, "a")
								.leftJoin("a.studentid", "s")
								.where("a.classid = :classid", { classid: classId })
								.andWhere("DATE_FORMAT(a.attdate, '%Y-%m-%d') = :cDate", { cDate: todaysDate });
							return qb;
						}, "att");
					// .orderBy("att.firstname", "ASC")
					// .addOrderBy("att.lastname", "ASC")
					// .addOrderBy("att.gender", "DESC");

					const getAttSQL = await getManager()
						.getRepository(Attendance)
						.createQueryBuilder("a")
						.select("a.studentid")
						.where("a.classid = :classid")
						.andWhere("DATE_FORMAT(a.attdate, '%Y-%m-%d') = :cDate")
						.getQuery();

					const present = getManager()
						.getRepository(Students)
						.createQueryBuilder("s")
						.select([
							"s.id AS id",
							"s.firstname AS firstname",
							"s.lastname AS lastname",
							"s.gender AS gender",
							"'present' AS selected"])
						.leftJoin("s.classsec", "c")
						.where("c.id = :classId", { classId: classId })
						.andWhere("s.id NOT IN (" + getAttSQL + ") ")
						.setParameter("classid", classId)
						.setParameter("cDate", todaysDate);

					const abData = await absentees.getRawMany();
					const prData = await present.getRawMany();
					result = _.concat(abData, prData);
					result = _.orderBy(result, [
						"gender", "firstname", "lastname"
					], ["desc", "asc", "asc"]);
				}
			}

			return {
				students: result,
				isnew: isNew
			};

		} catch (error) {
			throw new NotFound(`Student not found. Please change the search criteria`);
		}
	}

	public async getPieChartByMonth(classId: string, studentId: string, currMonth: string): Promise<any> {
		try {
			// to get no of working days in a class
			// const clsCount = await getManager()
			// 	.getRepository(Attendance)
			// 	.createQueryBuilder("a")
			// 	.where("a.classid = :classid", { classid: classId })
			// 	.andWhere("DATE_FORMAT(a.attdate, '%m') = :cDate", {
			// 		cDate: currMonth
			// 	})
			// 	.getCount();
			const clsAttCount = await this.getNoWorkingDays(classId, currMonth);
			const clsWorkingDays = Number(clsAttCount);

			// to get no of absent for the given month
			const studCount = await getManager()
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.where("a.classid = :classid", { classid: classId })
				.andWhere("a.studentid = :studId", { studId: studentId })
				.andWhere("DATE_FORMAT(a.attdate, '%m') = :cDate", {
					cDate: currMonth
				})
				.getCount();

			// student class total
			// const classTotalStrength: number = await getManager()
			// 	.getRepository(ClassSections)
			// 	.createQueryBuilder("c")
			// 	.leftJoin(Students, "s", "s.classsec = c.id")
			// 	.where("c.classid = :classid")
			// 	.andWhere("s.isactive = true")
			// 	.setParameter("classid", classId)
			// 	.getCount();

			// no of days present in a month
			const noOfDaysPresent = clsWorkingDays - studCount;

			let percentage = (((noOfDaysPresent | 0) / clsWorkingDays) * 100).toFixed(1);
			if (noOfDaysPresent === 0) {
				percentage = "0";
			}
			if (isNaN(Number(percentage))) {
				percentage = "0";
			}

			if (clsWorkingDays === 0 && studCount === 0) {
				throw new NotFound(`No Records found for the selected month`);
			}

			const response = {
				chartdata: [{
					x: "Present", y: noOfDaysPresent
				}, {
					x: "Absent", y: studCount
				}],
				attrate: percentage
			};

			return response;
		} catch (error) {
			throw new NotFound(`getPieChartByMonth Error: Please change the search criteria`);
		}
	}

	public async getPieChartClassWiseByMonth(classId: string, currMonth: string): Promise<any> {
		try {
			// to get no of working days
			const clsAttCount = await this.getNoWorkingDays(classId, currMonth);
			const totalStudentInCls = await this.getClassStrength(classId);

			// to get no of absent for the given month
			const studAbsCount = await getManager()
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.select("COUNT(DISTINCT DATE_FORMAT(attdate, '%Y-%m-%d'))", "unique")
				.where("a.classid = :classid", { classid: classId })
				.andWhere("a.studentid IS NOT NULL")
				.andWhere("a.allpresent = 0 ")
				.andWhere("DATE_FORMAT(a.attdate, '%m') = :cDate", {
					cDate: currMonth
				})
				.getRawOne();
			const noOfAbsentees = Number(studAbsCount.unique);
			const clsWorkingDays = Number(clsAttCount);

			// Absent Rale Formula = (Number of Absence Days / (Total StudentinClass x Work Days)) x 100%
			const absentRate = ((noOfAbsentees / (totalStudentInCls * clsWorkingDays)) * 100);
			let percentage = (100 - absentRate);

			if (absentRate === 0) {
				percentage = 100;
			}
			if (isNaN(Number(percentage))) {
				percentage = 100;
			}

			if (clsWorkingDays === 0 && noOfAbsentees === 0) {
				throw new NotFound(`No Records found for the selected month`);
			}

			const noOfPresent = percentage.toFixed();
			const noOfAbsent = absentRate.toFixed();
			const totalMonthlyPerc = percentage.toFixed(1);

			const response = {
				chartdata: [{
					x: "Present", y: noOfPresent
				}, {
					x: "Absent", y: noOfAbsent
				}],
				attrate: totalMonthlyPerc
			};

			return response;
		} catch (error) {
			throw new NotFound(`getPieChartByMonth Error: Please change the search criteria`);
		}
	}

	// to get no of working days for a given month and class
	private async getNoWorkingDays(classId: string, currMonth: string) {
		try {
			const res = await getManager()
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.select("COUNT(DISTINCT DATE_FORMAT(attdate, '%Y-%m-%d'))", "unique")
				.where("a.classid = :classid", { classid: classId })
				.andWhere("DATE_FORMAT(a.attdate, '%m') = :cDate", {
					cDate: currMonth
				})
				.getRawOne();
			return res.unique;
		} catch (error) {
			throw new NotFound(`getNoWorkingDays Error: Please change the search criteria`);

		}
	}

	// to check the attendance made or not for the particular date/class
	private async getStudAttCount(classId: string, currDate: string): Promise<any> {
		try {
			const result = await getManager()
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.where("a.classid = :classid", { classid: classId })
				.andWhere("DATE_FORMAT(a.attdate, '%Y-%m-%d') = :cDate", { cDate: currDate })
				.getCount();
			return result;
		} catch (error) {
			throw new NotFound(`Error: Attendance not found. Please change the search criteria`);
		}
	}

	// to get all present student. it is used to display in edit mode
	private async getAllPresentStudent(classId: string, todaysDate: string): Promise<any> {
		try {
			const result = await getManager()
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.select([
					"s.id AS id",
					"s.firstname AS firstname",
					"s.lastname AS lastname",
					"s.gender AS gender",
					"'present' AS selected"
				])
				.leftJoin(ClassSections, "c", "c.id = a.classid")
				.leftJoin("c.students", "s")
				.where("a.classid = :classid")
				.andWhere("DATE_FORMAT(a.attdate, '%Y-%m-%d') = :cDate")
				.andWhere("a.allpresent = true")
				.setParameter("classid", classId)
				.setParameter("cDate", todaysDate)
				.orderBy("s.gender", "DESC")
				.addOrderBy("s.firstname", "ASC")
				.addOrderBy("s.lastname", "ASC")
				.getRawMany();
			return result;
		} catch (error) {
			throw new NotFound(`Error: getAllPresentStudent Attendance not found. Please change the search criteria`);
		}
	}

	// to get no of student in a class
	private async getClassStrength(classId: string): Promise<any> {
		try {
			const result = await getManager()
				.getRepository(Students)
				.createQueryBuilder("st")
				.leftJoinAndSelect("st.classsec", "classsec")
				.where("st.isactive = true")
				.andWhere("classsec.id = :id", { id: classId })
				.getCount();
			return result;
		} catch (error) {
			throw new NotFound(`getClassStrength Error:`);
		}
	}


}