export interface IAttendance {
	id: string;
	attdate: Date;
	classid: string;
	studentid: [string];
	session: string;
	allpresent: boolean;
	notes: string;
}