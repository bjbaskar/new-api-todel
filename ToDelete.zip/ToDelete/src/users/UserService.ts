import { injectable, inject, decorate } from "inversify";
import { getManager, Like } from "typeorm";
import * as bcrypt from "bcrypt";
import * as jwt from "jsonwebtoken";
import { AbstractSetting } from "../core/config/AbstractSetting";
import { TYPES } from "../core/config/InversifyTypes";
import { IUser, ICurrentUser, TokenData, DataStoredInToken, IUserAgent } from "./IUser";
import { Users } from "../core/entities/Users/Users";
import { NotFound, InternalServerError, Unauthorized, BadRequest } from "../core/exceptions";
import { LoginHistory } from "../core/entities/Users/LoginHistory";
// import { AbstractPubsubManager } from "../../graphql/subscriptions/Pubsub/AbstractPubsubManager";
// import TOPICS from "../../graphql/subscriptions/Topics/PubsubTopicsImpl";

import * as parser from "ua-parser-js";

const enum LoginEnum {
	NOT_FOUND = "User not found.",
	PASSWORD_INCORRECT = "Username or Password is not correct.",
	MAX_ATTEMPTS = "The maximum number of login attempts has been reached. Please try again in 5 minutes.",
	PASSWORD_EXPIRED = "Password has been expired. Please contact the admin."
}

@injectable()
export class UserService {
	constructor(@inject(TYPES.Setting) private settings: AbstractSetting) { }

	public async registerUser(user: IUser, currentUser: string): Promise<any> {
		try {
			return new Promise(async (resolve, reject) => {
				const userFound = await this.isUserFound(user.username);

				if (userFound) {
					reject("UserName already exists");
				} else {
					const userEntity = Object.assign(new Users(), user);
					userEntity.createdby = currentUser;

					const password = user.password;
					this.hashPassword(password, async (err, passwordHashed) => {
						if (err) {
							reject(`Error: HashPassword ${err}`);
						} else {
							userEntity.password = passwordHashed;
							if (user.usertype.toUpperCase() === "STUDENT") {
								userEntity.staff = undefined;
							}
							else {
								userEntity.students = undefined;
							}
							await getManager()
								.getRepository(Users)
								.save(userEntity)
								.then(resUser => {
									return resolve(resUser);
								})
								.catch(err => {
									return reject(new BadRequest("Student or Staff mapping not match. please select Student or Staff", err));
								});
						}
					});
				}
			});
		} catch (error) {
			throw new InternalServerError("Error:", error);
		}
	}

	public login(usrname: string, password: string, userAgent: any): Promise<any> {

		return new Promise(async (resolve, reject) => {
			if (!usrname && password) {
				reject(new Unauthorized(`Please enter UserName and Password!`));
			}

			const userFound = await this.isUserFound(usrname);

			if (!userFound) {
				reject(new Unauthorized(`${usrname} ${LoginEnum.NOT_FOUND}`));
			} else {
				if (this.isLocked(userFound)) {
					return this.incLoginAttempts(userFound)
						.then(data => {
							reject(new Unauthorized(data));
						})
						.catch(error => {
							reject(new Unauthorized(error));
						});
				}

				const userPassword = userFound.password;
				this.comparePassword(
					password,
					userPassword,
					async (error: string | undefined, isMatch: boolean | undefined) => {
						if (isMatch) {
							if (!userFound.loginattempts && !Number(userFound.lockuntil)) {
								const getAuthToken = await this.getToken(userFound, userAgent);
								return resolve({ token: getAuthToken, user: userFound });
							}

							await getManager()
								.getRepository(Users)
								.createQueryBuilder()
								.update(Users)
								.set({ lockuntil: 0, loginattempts: 0 })
								.where("id = :id", { id: userFound.id })
								.andWhere("isactive = true")
								.execute();
							const getAuthToken = await this.getToken(userFound, userAgent);
							return resolve({ token: getAuthToken, user: userFound });
						} else {
							return this.incLoginAttempts(userFound)
								.then(data => {
									reject(new Unauthorized(data));
								})
								.catch(error => {
									reject(new Unauthorized(error));
								});
						}
					}
				);
			}
		});
	}

	public loginWithToken(userName: string, userAgent: any): Promise<any> {
		return new Promise(async (resolve, reject) => {
			try {
				const userFound = await this.isUserFound(userName);
				const getAuthToken = await this.getToken(userFound, userAgent);
				return resolve({ token: getAuthToken, user: userFound });
			} catch (error) {
				reject(error);
			}
		});
	}

	public changePassword(userId: string, newPassword: string): Promise<any> {
		return new Promise(async (resolve, reject) => {
			if (!userId) {
				reject(new Error(`Please enter Password and New Password!`));
			}
			// bb login validation required here before the user changing the password

			const password = newPassword;
			this.hashPassword(password, async (err, passwordHashed) => {
				if (err) {
					reject(new Error(`HashPassword ${err}`));
				} else {
					const res = await getManager()
						.getRepository(Users)
						.createQueryBuilder()
						.update(Users)
						.set({ password: passwordHashed })
						.where("id = :id", { id: userId })
						.execute();
					resolve({ Messages: "Password changed successfully" });
				}
			});
		});
	}

	public forgotPassword(usrname: string, password: string): Promise<any> {
		return undefined;
	}

	public resetPassword(
		userAdmin: ICurrentUser,
		userId: string,
		newPassword: string
	): Promise<any> {
		return new Promise(async (resolve, reject) => {
			if (!userAdmin.UserName || !userId || !newPassword) {
				reject(new Error(`ERROR: Please enter Username and New Password!`));
			}

			const userAdminFound = await this.isUserFound(userAdmin.UserName);
			if (userAdminFound.isadmin) {
				// const userFound = await this.isUserFound(usrname);

				const password = newPassword;
				this.hashPassword(password, async (err, passwordHashed) => {
					if (err) {
						reject(new Error(`Error: HashPassword ${err}`));
					} else {
						const res = await getManager()
							.getRepository(Users)
							.createQueryBuilder()
							.update(Users)
							.set({ password: passwordHashed })
							.where("id = :id", { id: userId })
							.execute();

						resolve({ Messages: "Password reset successfully" });
					}
				});
			} else {
				reject(
					new Error(`ERROR: Only Admin can reset the password of the selected user!`)
				);
			}
		});
	}

	public async getUsers(classId: string, userType: string, pageNo: number, pageSize: number): Promise<any> {
		try {
			const currenPageNo = pageNo === 1 ? 0 : pageNo - 1;

			const qb = getManager()
				.getRepository(Users)
				.createQueryBuilder("user")
				.leftJoinAndSelect("user.roles", "roles")
				.leftJoinAndSelect("roles.permissions", "permissions");

			if (userType === "student" && classId) {
				qb.leftJoinAndSelect("user.students", "students")
					.leftJoinAndSelect("students.classsec", "classsec");
			}
			else {
				qb.leftJoinAndSelect("user.staff", "staff");
			}

			qb.where("user.isactive = true")
				.andWhere("user.usertype = :usertype", { usertype: userType });

			if (userType === "student" && classId !== "ALL") {
				qb.andWhere("classsec.id = :classId", { classId: classId })
					.orderBy("students.firstname", "ASC");
			}
			qb.skip(currenPageNo * pageSize)
				.take(pageSize);

			const allUsers = {
				data: await qb.getMany(),
				count: await qb.getCount()
			};

			return allUsers;
		} catch (error) {
			throw error;
		}
	}

	public async updateInactive(userId: string, currentUser: string): Promise<any> {
		try {
			const usr = new Users();
			usr.updatedby = currentUser;
			usr.isactive = false;

			const res = await getManager()
				.getRepository(Users)
				.update(userId, usr);

			if (res) {
				return { Messages: "User has been removed successfully." };
			} else {
				return res;
			}
		} catch (error) {
			throw new InternalServerError("updateInactive Error", error);
		}
	}

	public async user(username: string): Promise<any> {
		try {
			const allUsers = await getManager()
				.getRepository(Users)
				.find({
					where: [
						{ username: Like(`%${username}%`) },
						{ username: Like(`%${username}%`) }
					]
				})
				.then(res => res)
				.catch(error => { throw new NotFound(`Users not found. ${error}`); }
				);

			return allUsers;
		} catch (error) {
			throw error;
		}
	}

	private async isUserFound(userName: string) {
		try {
			let userType = "";
			let userFound = undefined;
			const checkUser = await getManager()
				.getRepository(Users)
				.findOne({ where: [{ username: userName, isactive: true }] });

			if (checkUser) {
				userType = checkUser.usertype;
				if (userType.toUpperCase() === "STUDENT") {
					userFound = await getManager()
						.getRepository(Users)
						.createQueryBuilder("user")
						.leftJoinAndSelect("user.students", "students")
						.leftJoinAndSelect("user.roles", "roles")
						.leftJoinAndSelect("roles.permissions", "permissions")
						.leftJoinAndSelect("students.classsec", "classsec")
						.where("user.id = :id", { id: checkUser.id })
						.andWhere("user.isactive = true")
						.getOne();
				}
				else {
					userFound = await getManager()
						.getRepository(Users)
						.createQueryBuilder("user")
						.leftJoinAndSelect("user.staff", "staff")
						.leftJoinAndSelect("user.roles", "roles")
						.leftJoinAndSelect("roles.permissions", "permissions")
						.where("user.id = :id", { id: checkUser.id })
						.andWhere("user.isactive = true")
						.getOne();
				}
			}
			return userFound;
		} catch (error) {
			throw new Error(`UnHandledError: ${error}`);
		}
	}

	private async incLoginAttempts(user: IUser): Promise<any> {
		const MAX_LOGIN_ATTEMPTS = this.settings.config.server.max_login_attempts;
		const LOCK_TIME = this.settings.config.server.lock_time;

		// if we have a previous lock that has expired, restart at 1
		if (
			Number(user.lockuntil) < Date.now() &&
			user.loginattempts === MAX_LOGIN_ATTEMPTS
		) {
			//
			await getManager()
				.getRepository(Users)
				.createQueryBuilder()
				.update(Users)
				.set({ loginattempts: 1, lockuntil: 0 })
				.where("id = :id", { id: user.id })
				.execute();
			return LoginEnum.PASSWORD_INCORRECT;
		}

		// if loginAttempts more then MAX_LOGIN_ATTEMPTS return;
		const loginAttempt: number = user.loginattempts + 1;
		if (loginAttempt - 1 === MAX_LOGIN_ATTEMPTS) {
			return LoginEnum.MAX_ATTEMPTS;
		}

		// lock the user
		if (loginAttempt >= MAX_LOGIN_ATTEMPTS && !this.isLocked(user)) {
			const lockUntil = Date.now() + LOCK_TIME;

			await getManager()
				.getRepository(Users)
				.createQueryBuilder()
				.update(Users)
				.set({ lockuntil: lockUntil, loginattempts: loginAttempt })
				.where("id = :id", { id: user.id })
				.execute();
			return LoginEnum.MAX_ATTEMPTS;
		}

		// inc the loginAttempts
		await getManager()
			.getRepository(Users)
			.createQueryBuilder()
			.update(Users)
			.set({ loginattempts: loginAttempt })
			.where("id = :id", { id: user.id })
			.execute();
		return LoginEnum.PASSWORD_INCORRECT;
	}

	private isLocked(user: IUser) {
		return !!(user.lockuntil && Number(user.lockuntil) > Date.now());
	}

	private async getToken(user: IUser, userAgent: any) {
		const tokenData = await this.createToken(user);
		// const cookie = this.createCookie(tokenData);

		if (tokenData && tokenData.token) {
			const usrAgent = this.parseUserAgent(userAgent);

			const loginHis = new LoginHistory();
			loginHis.username = user.username;
			if (usrAgent.Browser && usrAgent.Browser.name) {
				loginHis.browser = usrAgent.Browser.name || "";
			}

			if (usrAgent.CPU && usrAgent.CPU.architecture) {
				loginHis.cpu = usrAgent.CPU.architecture || "";
			}
			if (usrAgent.Device) {
				let vendor = "";
				let model = "";
				if (usrAgent.Device.vendor) {
					vendor = usrAgent.Device.vendor;
				}
				if (usrAgent.Device.model) {
					model = usrAgent.Device.model;
				}
				loginHis.device = vendor + " - " + model;
			}
			if (usrAgent.Engine && usrAgent.Engine.name) {
				loginHis.engine = usrAgent.Engine.name || "";
			}
			if (usrAgent.OS) {
				let os = "";
				let ver = "";
				if (usrAgent.OS.name) {
					os = usrAgent.OS.name;
				}
				if (usrAgent.OS.version) {
					ver = " - " + usrAgent.OS.version;
				}
				loginHis.os = os + ver;
			}

			getManager()
				.getRepository(LoginHistory)
				.save(loginHis)
				.then(resUser => {
					return (resUser);
				})
				.catch(err => {

				});
		}

		return tokenData.token;
	}

	private async createToken(user: IUser): Promise<TokenData> {
		user.password = undefined;
		const expiresIn = this.settings.config.server.token_expires_in;
		const secret = this.settings.config.server.jwt_secret;
		const dataStoredInToken: DataStoredInToken = {
			username: user.username,
			usertype: user.usertype,
			id: user.usertype.toUpperCase() === "STUDENT" ? user.students.id : user.staff.id
		};
		const jwtToken = await jwt.sign(dataStoredInToken, secret, { expiresIn });
		return {
			expiresIn,
			token: jwtToken
		};
	}

	// public createCookie(tokenData: TokenData) {
	// 	return `Authorization=${tokenData.token}; HttpOnly; Max-Age=${
	// 		tokenData.expiresIn
	// 	}`;
	// }

	private hashPassword(
		password: string,
		callback: (error: Error, hash: string) => void
	): void {
		const saltRounds = 10;
		bcrypt.hash(password, saltRounds, (error, hash) => {
			callback(error, hash);
		});
	}

	private async comparePassword(
		password: string,
		passwordHash: string,
		callback: (error: string | undefined, match: boolean | undefined) => void
	) {
		await bcrypt.compare(
			password,
			passwordHash,
			(err: Error, match: boolean) => {
				if (match) {
					callback(undefined, true);
				} else {
					callback(`Invalid password match ${err}`, undefined);
				}
			}
		);
	}

	private parseUserAgent(ua: any): IUserAgent {
		try {
			const data: IUserAgent = {} as IUserAgent;

			const res = new parser.UAParser(ua);
			data.Browser = res.getBrowser() || "";
			data.CPU = res.getCPU() || "";
			data.Device = res.getDevice() || "";
			data.Engine = res.getEngine() || "";
			data.OS = res.getOS() || "";

			return data;
		} catch (error) {

		}
	}

	// private parseUserAgent1(ua: any): IUserAgent {
	// 	try {
	// 		const data: IUserAgent = {
	// 			Mobile: false,
	// 			iOS: "",
	// 			iPhone: false,
	// 			iPad: false,
	// 			Android: "",
	// 			webOS: "",
	// 			Mac: "",
	// 			Windows: "",
	// 		};

	// 		if (/mobile/i.test(ua))
	// 			data.Mobile = true;

	// 		if (/like Mac OS X/.test(ua)) {
	// 			data.iOS = /CPU( iPhone)? OS ([0-9\._]+) like Mac OS X/.exec(ua)[2].replace(/_/g, ".");
	// 			data.iPhone = /iPhone/.test(ua);
	// 			data.iPad = /iPad/.test(ua);
	// 		}

	// 		if (/Android/.test(ua))
	// 			data.Android = /Android ([0-9\.]+)[\);]/.exec(ua)[1];

	// 		if (/webOS\//.test(ua))
	// 			data.webOS = /webOS\/([0-9\.]+)[\);]/.exec(ua)[1];

	// 		if (/(Intel|PPC) Mac OS X/.test(ua))
	// 			data.Mac = /(Intel|PPC) Mac OS X ?([0-9\._]*)[\)\;]/.exec(ua)[2].replace(/_/g, ".");

	// 		if (/Windows NT/.test(ua))
	// 			data.Windows = /Windows NT ([0-9\._]+)[\);]/.exec(ua)[1];

	// 		return data;
	// 	} catch (error) {

	// 	}
	// }
}

// public getCars(firstname?: string): Promise<IUser[]> {
//   this.logger.info("Returning all users...");

//   return new Promise(resolve => {
//     let filteredCarsList;
//     if (firstname) {
//       filteredCarsList = this.userList.filter(
//         car => car.firstname === firstname
//       );
//       resolve(filteredCarsList);
//     } else {
//       resolve(this.userList);
//     }
//   });

//   public updateCarName(_id: string, newName: string): Promise<Car> {
//     return new Promise(resolve => {
//       for (const car of this.carList) {
//         if (car._id === _id) {
//           car.name = newName;
//           this.pubsubManager.publish(TOPICS.CAR_CHANGED_TOPIC, {
//             carChanged: car
//           });
//           resolve(car);

//           return;
//         }
//       }

//       resolve({});
//     });
//   }
