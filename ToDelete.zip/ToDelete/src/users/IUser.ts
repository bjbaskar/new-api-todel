import { IBaseModel } from "../common/IBaseModel";
import { IStaff } from "../staff/IStaff";
import { IStudent } from "../students/IStudent";
import { IRole } from "../userroles/IRole";
import { StringValueNode } from "graphql";

export interface IUser {
	id: string;
	username: string;
	email: string;
	password: string;
	isactive: boolean;
	isadmin: boolean;
	loginattempts: number;
	lockuntil: number;
	passwordexpires: number;
	usertype: string;
	staff: IStaff;
	students: IStudent;
	createdby: string;
	createdon: Date;
	updatedby: string;
	updatedon: Date;
}

export interface TokenData {
	token: string;
	expiresIn: number;
}

export interface DataStoredInToken {
	username: string;
	usertype: string;
	id: string;
}

export interface ICurrentUser {
	UserId: string;
	UserName: string;
	UserType: string;
	Student: IStudent;
	Staff: IStaff;
	Roles: Array<IRole>;
}

export interface IUserAgent {
	Browser: any;
	CPU: any;
	Device: any;
	Engine: any;
	OS: any;
}