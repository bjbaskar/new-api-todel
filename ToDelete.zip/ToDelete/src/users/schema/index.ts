import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const userTypeDef = typeDef;
const userResolver = resolvers;

export { userTypeDef, userResolver };
