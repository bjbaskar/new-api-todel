import { IAppContext } from "../../context";
import { AuthenticationError } from "apollo-server-express";

import { IUser } from "../IUser";

export const resolvers = {
	Query: {
		async user(_: any, args: { username: string }, context: IAppContext) {
			const verifyPerm = await context.AuthService.getAuthorize(context.CurrentUser.Roles, "MASTER", "USER", "CAN_READ");
			if (!verifyPerm) {
				throw new AuthenticationError("Authorization failed!");
			}

			const userService = context.userService.user(args.username);
			return userService;
		},
		async getUsers(_: any, args: { classId: string, userType: string, pageNo: number, pageSize: number }, context: IAppContext) {
			// const verifyPerm = await context.AuthService.getAuthorize(context.CurrentUser.Roles, "MASTER", "USER", "CAN_READ");
			// if (!verifyPerm) {
			// 	throw new AuthenticationError("Authorization failed!");
			// }

			const userService = context.userService.getUsers(args.classId, args.userType, args.pageNo, args.pageSize);
			return userService;
		}
	},
	Mutation: {
		async registerUser(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const user = await context.userService.registerUser(args, currentUser);
			return user;
		},
		async login(
			root: any,
			args: { username: string; password: string },
			context: IAppContext
		) {
			const userAgent = context.ReqUserAgent;
			const user = await context.userService.login(
				args.username,
				args.password,
				userAgent
			);
			return user;
		},
		async loginWithToken(
			root: any,
			args: {},
			context: IAppContext
		) {
			// console.log(context.Request);
			const userAgent = context.ReqUserAgent;
			const user = await context.userService.loginWithToken(context.CurrentUser.UserName, userAgent);
			return user;
		},
		async changePassword(
			root: any,
			args: { newPassword: string },
			context: IAppContext
		) {
			const verifyPerm = await context.AuthService.getAuthorize(context.CurrentUser.Roles, "MASTER", "USER", "CAN_EDIT");
			if (!verifyPerm) {
				throw new AuthenticationError("Authorization failed!");
			}

			const auth = context.CurrentUser.UserId;
			const user = await context.userService.changePassword(
				auth,
				args.newPassword
			);
			return user;
		},
		async resetPassword(
			root: any,
			args: { userId: string; password: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser;
			// const auth = await context.AuthService.getAuthUser(currentUser);
			if (!currentUser) {
				throw new Error(`authentication failed`);
			}

			const user = await context.userService.resetPassword(
				currentUser,
				args.userId,
				args.password
			);
			return user;
		},
		async forgotPassword(root: any, args: any, context: any) {
			const user = await context.userService.registerUser(args);
			return user;
		},
		async updateInactive(root: any, args: { userId: string }, context: any) {
			const currentUser = context.CurrentUser.UserName;
			const user = await context.userService.updateInactive(args.userId, currentUser);
			return user;
		},
		async updateUser(root: any, args: any, context: any) {
			const user = await context.userService.registerUser(args);
			return user;
		}
	}
};
