import { ClassSections } from "../core/entities/Master/ClassSections";
import { Subject } from "../core/entities/Master/Subject";

export interface IAssignment {
	id: string;
	taskname: string;
	duedate: Date;
	classsec: string;
	subject: string;
	priority: string;
	tag: string;
	notes: string;
}