import { injectable } from "inversify";
import { getManager, getConnection, EntityManager } from "typeorm";
import _ from "lodash";
import moment from "moment";
import { IAssignment } from "./IAssignment";
import { BadRequest, BadMapping, InternalServerError, NotFound } from "../core/exceptions";
import { Length, Validator } from "class-validator";
import { Attendance } from "../core/entities/Attendance/Attendance";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { Assignment } from "../core/entities/Assignments/Assignments";
import { Subject } from "../core/entities/Master/Subject";

@injectable()
export class AssignmentService {
	constructor() { }

	public async getAssignment(classId: string, dueDate: Date, mode: string): Promise<any> {
		try {
			const qb = getManager()
				.getRepository(Assignment)
				.createQueryBuilder("asg")
				.leftJoinAndSelect("asg.classsec", "cls")
				.leftJoinAndSelect("asg.subject", "sub")
				.leftJoinAndSelect("asg.documents", "docs");

			if (classId) {
				qb.where("cls.id = :id", { id: classId });
			}

			if (mode === "LIST") {
				const toDate = moment(new Date()).format("YYYY-MM-DD");
				const fromDate = moment(new Date()).subtract(7, "days").format("YYYY-MM-DD");

				qb.andWhere("DATE_FORMAT(asg.dueDate, '%Y-%m-%d') BETWEEN :fromDate AND :toDate", {
					fromDate: fromDate,
					toDate: toDate
				});
			}

			if (mode === "CAL" && dueDate) {
				const dueDateString = dueDate; //  moment(dueDate).format("YYYY-MM-DD");
				qb.andWhere("DATE_FORMAT(asg.dueDate, '%Y-%m-%d') = :dueDate", {
					dueDate: dueDateString
				});
			}

			const result = await qb.getMany();

			const response = await _(result)
				.groupBy(grp => moment(grp.duedate).format("YYYY-MM-DD"))
				.map((value, key) => ({
					duedate: key, data: value
				}))
				.orderBy(ord => moment(ord.duedate).format("YYYY-MM-DD"), ["desc"])
				.value();

			return response;

		} catch (error) {
			throw new NotFound(`getAssignment Error: Please change the search criteria`);
		}
	}

	public async getSubjectsByClass(classId: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("cls")
				.select(["s.id as id, s.name as name, s.color as color, s.subcode as subcode"])
				.leftJoin("cls.classteachersub", "ct")
				.leftJoin("ct.subject", "s")
				.where("cls.id = :id", { id: classId })
				.orderBy({
					"s.orderby": "ASC",
					"s.name": "ASC"
				})
				.getRawMany();
			return res;
		} catch (error) {
			throw new NotFound(`getSubjectsByClass Error: Please change the search criteria`);
		}
	}

	public async addAssignment(input: IAssignment, currentUser: string): Promise<any> {
		try {

			const entity = new Assignment();
			entity.duedate = input.duedate;
			entity.taskname = input.taskname;
			entity.notes = input.notes;
			entity.priority = input.priority;
			entity.tag = input.tag;
			entity.createdby = currentUser;

			const cls = new ClassSections();
			cls.id = input.classsec;
			const clsArr: Array<ClassSections> = [];
			clsArr.push(cls);
			entity.classsec = clsArr;

			const sub = new Subject();
			sub.id = input.subject;
			const subArr: Array<Subject> = [];
			subArr.push(sub);
			entity.subject = subArr;

			const res = await getManager()
				.getRepository(Assignment).save(entity);
			return res;
		} catch (error) {
			throw new InternalServerError("addAssignment", error);
		}
	}

	public async editAssignment(id: string, input: IAssignment, currentUser: string): Promise<any> {

		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const entity = new Assignment();
			entity.id = id;
			entity.duedate = input.duedate;
			entity.taskname = input.taskname;
			entity.notes = input.notes;
			entity.priority = input.priority;
			entity.tag = input.tag;
			entity.createdby = currentUser;

			const cls = await queryRunner.manager
				.createQueryBuilder()
				.relation(Assignment, "classsec")
				.of({ id: id })
				.loadMany();

			const remCls = await queryRunner.manager
				.createQueryBuilder()
				.relation(Assignment, "classsec")
				.of({ id: id })
				.addAndRemove(input.classsec, cls);

			const subj = await queryRunner.manager
				.createQueryBuilder()
				.relation(Assignment, "subject")
				.of({ id: id })
				.loadMany();

			const remSub = await queryRunner.manager
				.createQueryBuilder()
				.relation(Assignment, "subject")
				.of({ id: id })
				.addAndRemove(input.subject, subj);

			const res = await queryRunner.manager
				.getRepository(Assignment)
				.update(id, entity);

			await queryRunner.commitTransaction();

			return entity;

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("editAssignment", error);
		} finally {
			await queryRunner.release();
		}
	}

	public async delAssignment(id: string): Promise<any> {
		try {
			await getManager()
				.createQueryBuilder()
				.delete()
				.from(Assignment)
				.where("id = :id", { id: id })
				.execute();
		} catch (error) {
			throw new InternalServerError("Class Subject Delete Error:", error);
		}
	}
}