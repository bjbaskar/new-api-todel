import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const assignTypeDef = typeDef;
const assignResolver = resolvers;

export { assignTypeDef, assignResolver };