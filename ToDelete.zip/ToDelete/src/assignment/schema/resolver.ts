import { IAppContext } from "../../context";
import { IAssignment } from "../IAssignment";

export const resolvers = {
	Query: {
		async getAssignment(_: any, args: { classId: string, duedate: Date, mode: string }, context: IAppContext) {
			const svr = context.AssignmentService;
			const res = await svr.getAssignment(args.classId, args.duedate, args.mode);
			return res;
		},
		async getSubjectsByClass(_: any, args: { classId: string }, context: IAppContext) {
			const svr = context.AssignmentService;
			const res = await svr.getSubjectsByClass(args.classId);
			return res;
		},
	},
	Mutation: {
		async addAssignment(root: any, args: { input: IAssignment }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AssignmentService.addAssignment(args.input, currentUser);
			return res;
		},
		async editAssignment(
			root: any,
			args: { id: string, input: IAssignment },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AssignmentService.editAssignment(args.id, args.input, currentUser);
			return res;
		},
		async delAssignment(
			root: any,
			args: { id: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AssignmentService.delAssignment(args.id);
			return res;
		},

	}
};
