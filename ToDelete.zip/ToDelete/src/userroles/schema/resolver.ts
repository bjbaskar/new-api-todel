import { IAppContext } from "../../context";
import { IRole } from "../IRole";

export const resolvers = {
	Query: {
		async roleFind(_: any, args: { id: string }, context: IAppContext) {
			const roleSvc = await context.UserRoleService.roleFind(args.id);
			return roleSvc;
		},
		roleList: async (_: any, args: any, context: IAppContext) => {
			const roleSvc = await context.UserRoleService.roleList();
			return roleSvc;
		},
		async permFind(_: any, args: { id: string }, context: IAppContext) {
			const roleSvc = await context.UserRoleService.permFind(args.id);
			return roleSvc;
		},
		permList: async (_: any, args: any, context: IAppContext) => {
			const roleSvc = await context.UserRoleService.permList();
			return roleSvc;
		},
		async rolePermList(_: any, args: { roleId: string }, context: IAppContext) {
			const roleSvc = await context.UserRoleService.rolePermList(args.roleId);
			return roleSvc;
		},
		async userRolesList(_: any, args: { userId: string }, context: IAppContext) {
			const roleSvc = await context.UserRoleService.userRolesList(args.userId);
			return roleSvc;
		},
	},
	Mutation: {
		async roleAdd(root: any, args: { role: IRole }, context: IAppContext) {
			const role = await context.UserRoleService.roleAdd(args.role);
			return role;
		},
		async roleEdit(root: any, args: { id: string, role: IRole }, context: IAppContext) {
			const role = await context.UserRoleService.roleEdit(args.id, args.role);
			return role;
		},
		async roleDelete(root: any, args: { id: string }, context: IAppContext) {
			const role = await context.UserRoleService.roleDelete(args.id);
			return role;
		},
		async permAddToRole(root: any, args: { roleId: string, permIds: string[] }, context: IAppContext) {
			const role = await context.UserRoleService.permAddToRole(args.roleId, args.permIds);
			return role;
		},
		async rolesAddToUser(root: any, args: { userId: string, roleIds: string[] }, context: IAppContext) {
			const userRoles = await context.UserRoleService.rolesAddToUser(args.userId, args.roleIds);
			return userRoles;
		}
	}
};
