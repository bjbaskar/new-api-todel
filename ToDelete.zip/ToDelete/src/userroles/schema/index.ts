import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const roleTypeDef = typeDef;
const roleResolver = resolvers;

export { roleTypeDef, roleResolver };
