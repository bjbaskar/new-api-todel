import { injectable, inject, decorate } from "inversify";
import { getManager, getConnection } from "typeorm";
import { InternalServerError, NotFound } from "../core/exceptions";
import { IRole, IPermissions } from "./IRole";
import { Roles } from "../core/entities/Users/Roles";
import { Permissions } from "../core/entities/Users/Permissions";
import { Users } from "../core/entities/Users/Users";

@injectable()
export class UserRoleService {
	constructor() { }

	public async roleAdd(role: IRole): Promise<any> {
		try {
			const roleEntity = Object.assign(new Roles(), role);
			roleEntity.createdby = "bb";
			const res = await getManager().getRepository(Roles)
				.save(roleEntity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async roleEdit(id: string, role: IRole): Promise<any> {
		try {
			const roleEntity = Object.assign(new Roles(), role);
			roleEntity.updatedby = "bb";

			const res = await getManager()
				.getRepository(Roles)
				.update(id, roleEntity);

			return await this.findRolesById(id);
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async roleDelete(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(Roles)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async roleList() {
		try {
			const roles = await getManager()
				.getRepository(Roles)
				.createQueryBuilder("roles")
				.getMany();

			return roles;
		} catch (error) {
			throw new InternalServerError("Error", error);
		}
	}

	public async roleFind(id: string) {
		try {
			return this.findRolesById(id);
		} catch (error) {
			throw new InternalServerError("Error", error);
		}
	}

	public async permAddToRole(roleId: string, permIds: string[]): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			permIds.map(async p => {
				return await queryRunner.manager
					.createQueryBuilder()
					.relation(Roles, "permissions")
					.of(roleId)
					.add(p)
					.catch(error => {
						throw new NotFound("Unable to save Role & Permissions", error);
					});
			});
			await queryRunner.commitTransaction();
			return {
				Messages: "Role & Permissions saved successfully"
			};
		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async rolesAddToUser(userId: string, roleIds: string[]): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			try {

				const getRoleIds = await queryRunner.manager
					.getRepository(Users)
					.createQueryBuilder("users")
					.relation(Users, "roles")
					.of(userId).loadMany();

				const delRoleIds = getRoleIds.map(d => d.id);

				await queryRunner.manager
					.createQueryBuilder()
					.relation(Users, "roles")
					.of(userId)
					.remove(delRoleIds)
					.catch(error => {
						throw new NotFound("Unable to remove UserRoles", error);
					});

				await queryRunner.manager
					.createQueryBuilder()
					.relation(Users, "roles")
					.of(userId)
					.add(roleIds)
					.catch(error => {
						throw new NotFound("Unable to save User & Roles", error);
					});

			} catch (error) {
				throw new InternalServerError("UserRoles Delete Error:", error);
			}

			await queryRunner.commitTransaction();
			return {
				Messages: "Roles are assinged to the user successfully"
			};
		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async permList(): Promise<any> {
		try {
			const roles = await getManager()
				.getRepository(Permissions)
				.createQueryBuilder("perm")
				.getMany();

			// this.addPermissions();
			return roles;
		} catch (error) {
			throw new InternalServerError("Error", error);
		}
	}

	public async permFind(id: string): Promise<any> {
		try {
			return await getManager()
				.getRepository(Permissions)
				.findOne({ where: { id: id } });
		} catch (error) {
			throw new InternalServerError("Error", error);
		}
	}

	public async rolePermList(roleId: string): Promise<any> {
		try {
			const roles = await getManager()
				.getRepository(Roles)
				.createQueryBuilder("roles")
				.leftJoinAndSelect("roles.permissions", "permissions")
				.where("roles.id = :value", { value: roleId })
				.getOne();
			return roles;
		} catch (error) {
			throw new NotFound(`Roles not found. Please change the search criteria`);
		}
	}

	public async userRolesList(userId: string): Promise<any> {
		try {
			const roles = await getManager()
				.getRepository(Users)
				.createQueryBuilder("user")
				.leftJoinAndSelect("user.roles", "roles")
				.leftJoinAndSelect("roles.permissions", "permissions")
				.where("user.id = :value", { value: userId })
				.getOne();
			return roles;
		} catch (error) {
			throw new NotFound(`Roles not found. Please change the search criteria`);
		}
	}

	private async findRolesById(id: string): Promise<any> {
		try {
			return await getManager()
				.getRepository(Roles)
				.findOne({ where: { id: id } });
		} catch (error) {
			throw new InternalServerError("Error", error);
		}
	}

	private async addPermissions(): Promise<any> {
		try {

			const res = await getManager()
				.createQueryBuilder()
				.insert().into(Permissions)
				.values([
					{ module: "MASTER", title: "USER", key: "CAN_ADD" },
					{ module: "MASTER", title: "USER", key: "CAN_EDIT" },
					{ module: "MASTER", title: "USER", key: "CAN_DEL" },
					{ module: "MASTER", title: "USER", key: "CAN_READ" },
					{ module: "MASTER", title: "USER", key: "CAN_VIEW" },

					{ module: "MASTER", title: "ClassSection", key: "CAN_ADD" },
					{ module: "MASTER", title: "ClassSection", key: "CAN_EDIT" },
					{ module: "MASTER", title: "ClassSection", key: "CAN_DEL" },
					{ module: "MASTER", title: "ClassSection", key: "CAN_READ" },
					{ module: "MASTER", title: "ClassSection", key: "CAN_VIEW" },

					{ module: "MASTER", title: "Subject", key: "CAN_ADD" },
					{ module: "MASTER", title: "Subject", key: "CAN_EDIT" },
					{ module: "MASTER", title: "Subject", key: "CAN_DEL" },
					{ module: "MASTER", title: "Subject", key: "CAN_READ" },
					{ module: "MASTER", title: "Subject", key: "CAN_VIEW" },

					{ module: "MASTER", title: "DConfig", key: "CAN_ADD" },
					{ module: "MASTER", title: "DConfig", key: "CAN_EDIT" },
					{ module: "MASTER", title: "DConfig", key: "CAN_DEL" },
					{ module: "MASTER", title: "DConfig", key: "CAN_READ" },
					{ module: "MASTER", title: "DConfig", key: "CAN_VIEW" },

					{ module: "MASTER", title: "AcadYear", key: "CAN_ADD" },
					{ module: "MASTER", title: "AcadYear", key: "CAN_EDIT" },
					{ module: "MASTER", title: "AcadYear", key: "CAN_DEL" },
					{ module: "MASTER", title: "AcadYear", key: "CAN_READ" },
					{ module: "MASTER", title: "AcadYear", key: "CAN_VIEW" },

					{ module: "MASTER", title: "HOLIDAY", key: "CAN_ADD" },
					{ module: "MASTER", title: "HOLIDAY", key: "CAN_EDIT" },
					{ module: "MASTER", title: "HOLIDAY", key: "CAN_DEL" },
					{ module: "MASTER", title: "HOLIDAY", key: "CAN_READ" },
					{ module: "MASTER", title: "HOLIDAY", key: "CAN_VIEW" },

					{ module: "STUDENT", title: "Profile", key: "CAN_ADD" },
					{ module: "STUDENT", title: "Profile", key: "CAN_EDIT" },
					{ module: "STUDENT", title: "Profile", key: "CAN_DEL" },
					{ module: "STUDENT", title: "Profile", key: "CAN_READ" },
					{ module: "STUDENT", title: "Profile", key: "CAN_VIEW" },

					{ module: "STAFF", title: "Profile", key: "CAN_ADD" },
					{ module: "STAFF", title: "Profile", key: "CAN_EDIT" },
					{ module: "STAFF", title: "Profile", key: "CAN_DEL" },
					{ module: "STAFF", title: "Profile", key: "CAN_READ" },
					{ module: "STAFF", title: "Profile", key: "CAN_VIEW" },

					{ module: "EXAM", title: "Profile", key: "CAN_ADD" },
					{ module: "EXAM", title: "Profile", key: "CAN_EDIT" },
					{ module: "EXAM", title: "Profile", key: "CAN_DEL" },
					{ module: "EXAM", title: "Profile", key: "CAN_READ" },
					{ module: "EXAM", title: "Profile", key: "CAN_VIEW" },

					{ module: "PROMOTION", title: "Profile", key: "CAN_ADD" },
					{ module: "PROMOTION", title: "Profile", key: "CAN_EDIT" },
					{ module: "PROMOTION", title: "Profile", key: "CAN_DEL" },
					{ module: "PROMOTION", title: "Profile", key: "CAN_READ" },
					{ module: "PROMOTION", title: "Profile", key: "CAN_VIEW" },


				])
				.execute();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}



}