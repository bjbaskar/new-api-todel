import { IUser } from "../users/IUser";

export interface IRole {
	id: string;
	rolename: string;
	permissions: [IPermissions];
	user: [IUser];
}

export interface IPermissions {
	id: string;
	module: string;
	title: string;
	key: string;
	roles: [IRole];
	user: IUser;
}
