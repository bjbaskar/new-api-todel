import "reflect-metadata";
import { ContainerMain } from "./core/config/InversifyConfig";
import { TYPES } from "./core/config/InversifyTypes";
import { AuthService } from "./common/AuthService";
import { UserService } from "./users/UserService";
import { UserRoleService } from "./userroles/UserRoleService";


import { DataConfigService } from "./master/dataconfig/DataConfigService";

import { SchoolProfileService } from "./master/schoolprofile/SchoolProfileService";
import { AcadYearService } from "./master/academicyear/AcadYearService";
import { EduSystemService } from "./master/edusystems/EduSystemService";
import { SubjectService } from "./master/subjects/SubjectService";
import { ClassService } from "./master/classsec/ClassService";
import { TextBookService } from "./master/textbooks/TextBookService";
import { HolidayService } from "./master/holidays/HolidayService";
import { CalendarService } from "./master/calendar/CalendarService";

import { StudentService } from "./students/StudentService";
import { StaffService } from "./staff/StaffService";
import { ICurrentUser } from "./users/IUser";

import { UploadService } from "./uploads/UploadService";
import { Setting } from "./core/config/Setting";

import { DashboardService } from "./dashboard/DashboardService";
import { AttendanceService } from "./attendance/AttendanceService";
import { AssignmentService } from "./assignment/AssignmentService";

import { ExamService } from "./exams/ExamService";

import { FeedbackService } from "./feedback/FeedbackService";
import { FeeParticularService } from "./fee/feeparticulars/FeeParticularService";
import { FeeInstallmentService } from "./fee/feeinstallments/FeeInstallmentService";
import { FeeMasterService } from "./fee/feemaster/FeeMasterService";
import { FeeStudentConfigService } from "./fee/feestudentconfig/FeeStudentConfigSvc";
import { FeeTransactionService } from "./fee/feetransaction/FeeTransactionSvc";
import { FeeDiscountService } from "./fee/feediscount/FeeDiscountSvc";

// import { AbstractPubsubManager } from "./graphql/subscriptions/Pubsub/AbstractPubsubManager";

export function getContext(): IAppContext {
	return {
		// pubsubManager: injector.get(AbstractPubsubManager),
		Setting: ContainerMain.get<Setting>(TYPES.Setting),
		userService: ContainerMain.get<UserService>(TYPES.UserService),
		UserRoleService: ContainerMain.get<UserRoleService>(TYPES.UserRoleService),

		AuthService: ContainerMain.get<AuthService>(TYPES.AuthService),
		CurrentUser: undefined,
		ReqUserAgent: undefined,

		SchoolProfileService: ContainerMain.get<SchoolProfileService>(TYPES.SchoolProfileService),
		AcadYearService: ContainerMain.get<AcadYearService>(TYPES.AcadYearService),
		EduSystemService: ContainerMain.get<EduSystemService>(TYPES.EduSystemService),

		SubjectService: ContainerMain.get<SubjectService>(TYPES.SubjectService),
		ClassService: ContainerMain.get<ClassService>(TYPES.ClassService),
		TextBookService: ContainerMain.get<TextBookService>(TYPES.TextBookService),

		DataConfigService: ContainerMain.get<DataConfigService>(
			TYPES.DataConfigService
		),
		HolidayService: ContainerMain.get<HolidayService>(TYPES.HolidayService),
		CalendarService: ContainerMain.get<CalendarService>(TYPES.CalendarService),

		StaffService: ContainerMain.get<StaffService>(TYPES.StaffService),
		UploadService: ContainerMain.get<UploadService>(TYPES.UploadService),
		StudentService: ContainerMain.get<StudentService>(TYPES.StudentService),

		DashboardService: ContainerMain.get<DashboardService>(TYPES.DashboardService),
		AttendanceService: ContainerMain.get<AttendanceService>(TYPES.AttendanceService),
		AssignmentService: ContainerMain.get<AssignmentService>(TYPES.AssignmentService),

		ExamService: ContainerMain.get<ExamService>(TYPES.ExamService),

		FeedbackService: ContainerMain.get<FeedbackService>(TYPES.FeedbackService),

		FeeParticularService: ContainerMain.get<FeeParticularService>(TYPES.FeeParticularService),
		FeeInstallmentService: ContainerMain.get<FeeInstallmentService>(TYPES.FeeInstallmentService),
		FeeMasterService: ContainerMain.get<FeeMasterService>(TYPES.FeeMasterService),
		FeeStudentConfigService: ContainerMain.get<FeeStudentConfigService>(TYPES.FeeStudentConfigService),
		FeeTransactionService: ContainerMain.get<FeeTransactionService>(TYPES.FeeTransactionService),
		FeeDiscountService: ContainerMain.get<FeeDiscountService>(TYPES.FeeDiscountService),

	};
}

export interface IAppContext {
	Setting: Setting;
	userService: UserService;
	UserRoleService: UserRoleService;
	AuthService: AuthService;
	CurrentUser: ICurrentUser;
	ReqUserAgent: any;

	SchoolProfileService: SchoolProfileService;
	AcadYearService: AcadYearService;
	EduSystemService: EduSystemService;

	SubjectService: SubjectService;
	ClassService: ClassService;
	TextBookService: TextBookService;

	DataConfigService: DataConfigService;
	HolidayService: HolidayService;
	CalendarService: CalendarService;

	StaffService: StaffService;
	UploadService: UploadService;
	StudentService: StudentService;

	DashboardService: DashboardService;
	AttendanceService: AttendanceService;
	AssignmentService: AssignmentService;

	ExamService: ExamService;

	FeedbackService: FeedbackService;

	FeeParticularService: FeeParticularService;
	FeeInstallmentService: FeeInstallmentService;
	FeeMasterService: FeeMasterService;
	FeeStudentConfigService: FeeStudentConfigService;
	FeeTransactionService: FeeTransactionService;
	FeeDiscountService: FeeDiscountService;
}
