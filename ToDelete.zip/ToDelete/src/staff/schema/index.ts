import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const staffTypeDef = typeDef;
const staffResolver = resolvers;

export { staffTypeDef, staffResolver };
