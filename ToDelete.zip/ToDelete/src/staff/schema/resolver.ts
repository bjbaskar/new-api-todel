import { IAppContext } from "../../context";
import { IStaff } from "../IStaff";

export const resolvers = {
	Query: {
		getStaff: async (_: any, args: { id: string, isactive: boolean }, context: IAppContext) => {
			return await context.StaffService.getStaff(args.id, args.isactive);
		},
		getAllStaff: async (_: any, args: { pageNo: number, pageSize: number, sortCol: string, isAsc: string, isactive: boolean }, context: IAppContext) => {
			return await context.StaffService.getAllStaff(args.pageNo, args.pageSize, args.sortCol, args.isAsc, args.isactive);
		},
		getAllStaffDD: async (_: any, args: { isactive: boolean }, context: IAppContext) => {
			return await context.StaffService.getAllStaffDD(args.isactive);
		}
	},
	Mutation: {
		async addStaffProfile(root: any, args: { input: IStaff }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.StaffService.addStaffProfile(args.input, currentUser);
			return res;
		},
		async editStaffProfile(
			root: any,
			args: { id: string, input: IStaff },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.StaffService.editStaffProfile(args.id, args.input, currentUser);
			return res;
		},
		async delStaffProfile(root: any,
			args: { id: string },
			context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.StaffService.delStaffProfile(args.id, currentUser);
			return res;
		}
	}
};
