import { injectable } from "inversify";
import { getManager, getConnection } from "typeorm";
import { IStaff } from "./IStaff";
import { Staff } from "../core/entities/Staff/Staff";
import { BadRequest, BadMapping, InternalServerError, NotFound } from "../core/exceptions";
import { AcadYear } from "../core/entities/Master/AcadYear";

import { Length, Validator } from "class-validator";

@injectable()
export class StaffService {
	constructor() { }

	private errorArr = Array<string>();

	public async addStaffProfile(staff: IStaff, currentUser: string): Promise<any> {

		this.errorArr = [];
		const validateError = this.validateAll(staff);
		if (validateError.length) {
			this.errorArr = [];
			throw new BadRequest(`Please enter the mandatory fields. ${validateError}`);
		}
		try {
			const staffNo = await this.getNewStaffNo();

			const staffEntity = Object.assign(new Staff(), staff);
			staffEntity.staffno = staffNo.staffno;
			staffEntity.prefixyear = staffNo.prefixyear;
			staffEntity.createdby = currentUser;

			const res = await getManager()
				.getRepository(Staff)
				.save(staffEntity)
				.catch(error => {
					throw new BadRequest(`Staff data not saved ${error}`);
				});
			return res;

		} catch (error) {
			throw new InternalServerError("Unhandled Error: Unable to save", error);
		}
	}

	public async editStaffProfile(id: string, staff: IStaff, currentUser: string): Promise<any> {

		this.errorArr = [];
		const validateError = this.validateAll(staff);
		if (validateError.length) {
			this.errorArr = [];
			throw new BadRequest(`Please enter the mandatory fields. ${validateError}`);
		}
		try {

			const staffEntity = Object.assign(new Staff(), staff);
			staffEntity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(Staff)
				.update(id, staffEntity)
				.catch(error => {
					throw new BadRequest(`Staff data not saved ${error}`);
				});

			if (res.raw.affectedRows > 0) {
				return { Messages: "Updated successfully" };
			} else {
				return { Messages: "No Records Updated" };
			}

		} catch (error) {
			throw new InternalServerError("Unhandled Error: Unable to save", error);
		}
	}

	public async delStaffProfile(id: string, currentUser: string): Promise<any> {
		try {
			const staffEntity = new Staff();
			staffEntity.updatedby = currentUser;
			staffEntity.isactive = false;

			const res = await getManager()
				.getRepository(Staff)
				.update(id, staffEntity)
				.catch(error => {
					throw new BadRequest(`Staff data not deleted ${error}`);
				});

			if (res.raw.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getStaff(id: string, isactive: boolean): Promise<any> {
		return await this.findStaffById(id, isactive);
	}

	public async getAllStaff(pageNo: number,
		pageSize: number, sortCol: string, isAsc: string,
		isactive: boolean): Promise<any> {
		try {
			const currenPageNo = pageNo - 1;
			const orderBy = sortCol ? sortCol : "staff.firstname";
			const qb = getManager()
				.getRepository(Staff)
				.createQueryBuilder("staff")
				.where("staff.isactive = :value", { value: isactive })
				.orderBy(orderBy, isAsc === "ASC" ? "ASC" : "DESC")
				.skip(currenPageNo * pageSize)
				.take(pageSize);

			const staff = {
				rows: qb.getMany(),
				count: qb.getCount()
			};
			return staff;
		} catch (error) {
			throw new NotFound(`Staff not found. Please change the search criteria`);
		}
	}

	public async getAllStaffDD(isactive: boolean): Promise<any> {
		try {

			const qb = getManager()
				.getRepository(Staff)
				.createQueryBuilder("staff")
				.where("staff.isactive = :value", { value: true })
				.orderBy("staff.firstname", "ASC");

			const res = qb.getMany();

			return res;
		} catch (error) {
			throw new NotFound(`Staff not found. Please change the search criteria`);
		}
	}

	private async findStaffById(id: string, isactive: boolean): Promise<any> {
		try {
			const staff = await getManager()
				.getRepository(Staff)
				.createQueryBuilder("staff")
				.where("staff.id = :value", { value: id })
				.andWhere("staff.isactive = :isactive", { isactive: isactive })
				.getOne();
			return staff;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async getNewStaffNo(): Promise<any> {
		try {

			let { staffno } = await getManager()
				.getRepository(Staff)
				.createQueryBuilder("staff")
				.select("MAX(staff.staffno)", "staffno")
				.getRawOne();

			if (!staffno) {
				staffno = 0;
			}
			staffno = Number(staffno) + 1;

			let getPrefixYear = await getManager()
				.getRepository(AcadYear)
				.createQueryBuilder("acadyear")
				.select("acadyear.prefixyear", "prefixyear")
				.where("acadyear.isactive = :active", { active: true })
				.getRawOne();

			if (!getPrefixYear) {
				getPrefixYear = new Date().getFullYear().toString().substr(-2);
			}
			else {
				getPrefixYear = getPrefixYear.prefixyear;
			}
			// const prefixyear = getPrefixYear.prefixyear;

			return { staffno: staffno, prefixyear: getPrefixYear };
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private validateAll(staff: IStaff): Array<string> {
		this.validateStaff(staff);
		return this.errorArr;
	}

	private validateStaff(staff: IStaff): Array<string> {
		const validator = new Validator();
		if (validator.isEmpty(staff)) this.errorArr.push("Student profile can not be empty");
		if (validator.isEmpty(staff.firstname)) this.errorArr.push("First name can not be empty");
		if (validator.isEmpty(staff.lastname)) this.errorArr.push("Last name can not be empty");
		if (validator.isEmpty(staff.gender)) this.errorArr.push("Gender can not be empty");
		if (validator.isEmpty(staff.designation)) this.errorArr.push("Designation can not be empty");
		if (validator.isDate(staff.dob)) this.errorArr.push("Date of Birth can not be empty");
		if (validator.isDate(staff.doj)) this.errorArr.push("Date of Join can not be empty");

		return this.errorArr;
	}
}
