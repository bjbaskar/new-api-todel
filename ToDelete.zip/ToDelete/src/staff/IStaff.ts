import { ISubject } from "../master/subjects/ISubject";
import { IUser } from "../users/IUser";
import { IClass } from "../master/classsec/IClass";

export interface IStaff {
	id: string;
	staffno: string;
	aadhaarno: string;
	firstname: string;
	lastname: string;
	gender: string;
	designation: string;
	dob: Date;
	doj: Date;
	nationality: string;
	religion: string;
	castecategory: string;
	community: string;
	mothertongue: string;
	bloodgroup: string;
	identification: string;
	isactive: boolean;
	notes: string;
	photo: string;
	// class_section: IClass[];
	// subjects: Array<ISubject>;
	user: IUser;
}
