import { IAppContext } from "../../context";

export const resolvers = {
	Query: {
		async getLoginCount(_: any, args: { filter: string }, context: IAppContext) {
			const service = context.DashboardService;
			const res = await service.getLoginCount(args.filter);
			return res;
		},
		async getLoginCountChart(_: any, args: { filter: string }, context: IAppContext) {
			const service = context.DashboardService;
			const res = await service.getLoginCountChart(args.filter);
			return res;
		},
		async getStudentCount(_: any, args: { classId: string }, context: IAppContext) {
			const service = context.DashboardService;
			const res = await service.getStudentCount(args.classId);
			return res;
		}
	}
};
