import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const dashBoardTypeDef = typeDef;
const dashBoardResolver = resolvers;

export { dashBoardTypeDef, dashBoardResolver };
