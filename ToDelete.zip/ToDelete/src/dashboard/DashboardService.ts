import { injectable } from "inversify";
import { getManager, LessThanOrEqual, MoreThanOrEqual } from "typeorm";
import moment from "moment";
import { LoginHistory } from "../core/entities/Users/LoginHistory";
import { Students } from "../core/entities/Students/Student";
import { ClassSections } from "../core/entities/Master/ClassSections";

@injectable()
export class DashboardService {
	constructor() { }

	public async getLoginCount(filter: string): Promise<any> {
		try {
			const qb = getManager()
				.createQueryBuilder()
				.select("hres.*")
				.from(subQry => {
					const subQB = subQry
						.select(["hist.username as username",
							"hist.os as os",
							"hist.browser as browser",
							"hist.cpu as cpu",
							"hist.device as device",
							"hist.engine as engine",
							"DATE_FORMAT(hist.lastlogin, '%Y-%m-%d') as lastlogin"])
						.addSelect("COUNT(hist.username)", "count")
						.from(LoginHistory, "hist");

					if (filter === "TODAY") {
						const fRange = moment(new Date()).format("YYYY-MM-DD");
						subQB.where("DATE_FORMAT(hist.lastlogin, '%Y-%m-%d') = :lastlogin", {
							lastlogin: fRange
						});

					} else if (filter === "YESTERDAY") {
						const fRange = moment(new Date()).subtract(1, "days").format("YYYY-MM-DD");
						subQB.where("DATE_FORMAT(hist.lastlogin, '%Y-%m-%d') = :lastlogin", {
							lastlogin: fRange
						});

					} else {
						const todayDate = moment(new Date()).format("YYYY-MM-DD");
						const range7days = moment(new Date()).subtract(7, "days").format("YYYY-MM-DD");

						subQB.andWhere("DATE_FORMAT(hist.lastlogin, '%Y-%m-%d') BETWEEN :startDate AND :toDate", {
							startDate: range7days,
							toDate: todayDate
						});
					}

					subQB.groupBy("DATE_FORMAT(hist.lastlogin, '%Y-%m-%d')")
						.addGroupBy("hist.username")
						.addGroupBy("hist.os")
						.addGroupBy("hist.browser")
						.addGroupBy("hist.cpu")
						.addGroupBy("hist.device")
						.addGroupBy("hist.engine");
					return subQB;
				}, "hres")
				.orderBy("hres.lastlogin", "DESC");

			const result = await qb.getRawMany();

			return result;
		} catch (error) {
			throw new Error(`Error: Login History. Please change the search criteria`);
		}
	}

	public async getLoginCountChart(filter: string): Promise<any> {
		try {
			const qb = getManager()
				.getRepository(LoginHistory)
				.createQueryBuilder("his")
				.select("COUNT(his.username)", "count");
			if (filter === "TODAY") {
				qb.addSelect("DATE_FORMAT(his.lastlogin, '%Y-%m-%d %H') as lastlogin")
					.groupBy("DATE_FORMAT(his.lastlogin, '%Y-%m-%d %H')");

				const fRange = moment(new Date()).format("YYYY-MM-DD");
				qb.where("DATE_FORMAT(his.lastlogin, '%Y-%m-%d') = :lastlogin", {
					lastlogin: fRange
				});
			} else if (filter === "YESTERDAY") {
				qb.addSelect("DATE_FORMAT(his.lastlogin, '%Y-%m-%d %H') as lastlogin")
					.groupBy("DATE_FORMAT(his.lastlogin, '%Y-%m-%d %H')");

				const fRange = moment(new Date()).subtract(1, "days").format("YYYY-MM-DD");
				qb.where("DATE_FORMAT(his.lastlogin, '%Y-%m-%d') = :lastlogin", {
					lastlogin: fRange
				});
			} else {
				qb.addSelect("DATE_FORMAT(his.lastlogin, '%Y-%m-%d') as lastlogin")
					.groupBy("DATE_FORMAT(his.lastlogin, '%Y-%m-%d')");

				const todayDate = moment(new Date()).format("YYYY-MM-DD");
				const range7days = moment(new Date()).subtract(7, "days").format("YYYY-MM-DD");

				qb.andWhere("DATE_FORMAT(his.lastlogin, '%Y-%m-%d') BETWEEN :startDate AND :toDate", {
					startDate: range7days,
					toDate: todayDate
				});
			}
			const result = await qb.getRawMany();
			return result;
		} catch (error) {
			throw new Error(`Error: Login History Chart. Please change the search criteria`);
		}
	}

	public async getStudentCount(classId: string): Promise<any> {
		try {
			const qb = getManager()
				.createQueryBuilder()
				.select(["CONCAT(sq.name, ' ' ,sq.section) as name"])
				.addSelect(`SUM(CASE WHEN sq.gender = 'male' THEN sq.total ELSE 0 end) as boys`)
				.addSelect(`SUM(CASE WHEN sq.gender = 'female' THEN sq.total ELSE 0 end) as girls`)
				.from(subQry => {
					const subQB = subQry
						.select("COUNT(*)", "total")
						.addSelect([
							"cls.name as name",
							"cls.section as section",
							"stud.gender as gender"])
						.from(ClassSections, "cls")
						.leftJoin("cls.students", "stud");

					if (classId) {
						subQB.where("cls.id = :classId", { classId: classId });
					}
					subQB.groupBy("stud.gender")
						.addGroupBy("cls.name")
						.addGroupBy("cls.section");

					return subQB;
				}, "sq")
				.addGroupBy("sq.name")
				.addGroupBy("sq.section")
				.orderBy("sq.name", "ASC")
				.addOrderBy("sq.section", "ASC");

			const result = await qb.getRawMany();

			return result;
		} catch (error) {
			throw new Error(`Error: getStudentCount. Please change the search criteria`);
		}
	}

}
