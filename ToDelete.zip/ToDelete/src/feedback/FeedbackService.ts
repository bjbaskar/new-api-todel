import { injectable } from "inversify";
import { getManager, getConnection, EntityManager } from "typeorm";
import _ from "lodash";
import moment from "moment";
import { IFeedback } from "./IFeedback";
import { BadRequest, BadMapping, InternalServerError, NotFound } from "../core/exceptions";
import { Length, Validator } from "class-validator";
import { Attendance } from "../core/entities/Attendance/Attendance";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { Feedback } from "../core/entities/Feedback/Feedback";
import { Subject } from "../core/entities/Master/Subject";

@injectable()
export class FeedbackService {
	constructor() { }

	public async getFeedback(): Promise<any> {
		try {
			const qb = getManager()
				.getRepository(Feedback)
				.createQueryBuilder("fb");

			const result = await qb.getRawMany();
			return result;

		} catch (error) {
			throw new NotFound(`getFeedback Error: Please change the search criteria`);
		}
	}

	public async addFeedback(input: IFeedback, currentUser: string): Promise<any> {
		try {

			const entity = new Feedback();
			entity.createdby = currentUser;

			const res = await getManager()
				.getRepository(Feedback).save(entity);
			return res;
		} catch (error) {
			throw new InternalServerError("addFeedback", error);
		}
	}

	public async editFeedback(id: string, input: IFeedback, currentUser: string): Promise<any> {

		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const entity = new Feedback();
			entity.id = id;


			await queryRunner.commitTransaction();
			return entity;

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("editFeedback", error);
		} finally {
			await queryRunner.release();
		}
	}

	public async delFeedback(id: string): Promise<any> {
		try {
			await getManager()
				.createQueryBuilder()
				.delete()
				.from(Feedback)
				.where("id = :id", { id: id })
				.execute();
		} catch (error) {
			throw new InternalServerError("Feedback Delete Error:", error);
		}
	}
}