import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feedbackTypeDef = typeDef;
const feedbackResolver = resolvers;

export { feedbackTypeDef, feedbackResolver };