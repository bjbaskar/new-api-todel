import { IAppContext } from "../../context";
import { IFeedback } from "../IFeedback";

export const resolvers = {
	Query: {
		async getFeedback(_: any, args: {}, context: IAppContext) {
			const svr = context.FeedbackService;
			const res = await svr.getFeedback();
			return res;
		}
	},
	Mutation: {
		async addFeedback(root: any, args: { input: IFeedback }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeedbackService.addFeedback(args.input, currentUser);
			return res;
		},
		async editFeedback(
			root: any,
			args: { id: string, input: IFeedback },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeedbackService.editFeedback(args.id, args.input, currentUser);
			return res;
		},
		async delFeedback(
			root: any,
			args: { id: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeedbackService.delFeedback(args.id);
			return res;
		},

	}
};
