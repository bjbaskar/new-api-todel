
export interface IFeedback {
	id: string;
	rating: number;
	desc: string;
	qa: string;
	staff: string;
	student: string;
}