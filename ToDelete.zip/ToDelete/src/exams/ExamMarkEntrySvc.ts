import {
	getManager,
	MoreThanOrEqual,
	LessThanOrEqual,
	getConnection,
	EntityManager
} from "typeorm";
import _ from "lodash";

// import { IClass, IClassSubject, IClassStaff } from "../master/classsec/IClass";
import { IMarkRegister, IMarkRegisterData, IMarkRegisterSummary, IVerfiyMarkRegister } from "./IExam";
import { Exams } from "../core/entities/Exams/Exam";
import { MarkRegister } from "../core/entities/Exams/MarkRegister";
import { ExamGrades } from "../core/entities/Exams/Grades";

import { InternalServerError, NotFound } from "../core/exceptions";
import { Students } from "../core/entities/Students/Student";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { Subject } from "../core/entities/Master/Subject";
import { MarkRegisterSummary } from "../core/entities/Exams/MarkRegisterSum";

// import { ClassTeacher } from "../core/entities/Master/ClassTeacher";
// import { Subject } from "../core/entities/Master/Subject";

export class MarkEntryService {
	constructor() { }

	public async verifyMarkReg(input: IVerfiyMarkRegister): Promise<any> {
		try {
			const examName: string = input.examName;
			const classId: string = input.classId;
			const subjectId: string = input.subjectId;
			const res = await getManager()
				.getRepository(MarkRegister)
				.createQueryBuilder("reg")
				.leftJoin("reg.exam_class_sub", "exams")
				.leftJoin("exams.class", "class")
				.leftJoin("exams.subjects", "subjects")
				.where("exams.name = :examName", { examName: examName })
				.andWhere("class.id = :classId", { classId: classId })
				.andWhere("subjects.id = :subjectId", { subjectId: subjectId })
				.getCount();

			const resp = {
				count: res,
				isFound: res > 0 ? true : false
			};

			return resp;

		} catch (error) {
			throw new InternalServerError("verifyMarkReg Unhandled Error: ", error);
		}
	}

	public async createMarkRegister(
		input: IVerfiyMarkRegister,
		acadyear: string,
		currentUser: string): Promise<any> {

		try {
			const examName: string = input.examName;
			const classId: string = input.classId;
			const subjectId: string = input.subjectId;

			const res = await this.addMarkRegister(input, acadyear, currentUser);

			if (!res) {
				throw new InternalServerError("createMarkRegister Unhandled Error: ");
			}

			const result = await this.getMarkEntry(examName, classId, subjectId, acadyear);
			return result;

		} catch (error) {
			throw new InternalServerError("createMarkRegister Unhandled Error: ", error);
		}
	}

	private async addMarkRegister(
		input: IVerfiyMarkRegister,
		acadyear: string,
		currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();

		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const examName: string = input.examName;
			const classId: string = input.classId;
			const subjectId: string = input.subjectId;

			const hasData = await this.verifyMarkReg(input);

			if (hasData.count === 0) {
				// const oData: IMarkRegister[] = [];

				const oStudendID = await getManager()
					.getRepository(ClassSections)
					.createQueryBuilder("c")
					.select([
						"st.id AS studentId"
					])
					.leftJoin("c.students", "st")
					.where("c.id = :classId", { classId: classId })
					.andWhere("st.isactive = true")
					.orderBy("st.firstname", "ASC")
					.addOrderBy("st.gender", "DESC")
					.getRawMany<IMarkRegisterData>();

				const oExam = await getManager()
					.getRepository(Exams)
					.createQueryBuilder("exam")
					.where("exam.name = :examName", { examName: examName })
					.andWhere("exam.class = :classId", { classId: classId })
					.andWhere("exam.subjects = :subjectId", { subjectId: subjectId })
					.getOne();

				for (let i = 0; i <= oStudendID.length - 1; i++) {
					const entity = new MarkRegister();

					const oStudent = await queryRunner.manager.getRepository(Students)
						.findOne({ where: { id: oStudendID[i].studentId } });

					entity.marks_obtained = 0;
					entity.grade = "";
					entity.percentage = 0;
					entity.acad_year = acadyear;
					entity.notes = "";
					entity.createdby = currentUser;

					await queryRunner.manager
						.getRepository(MarkRegister)
						.createQueryBuilder()
						.insert()
						.into(MarkRegister)
						.values(entity)
						.execute()
						.then(async (r) => {
							await queryRunner.manager
								.getRepository(MarkRegister)
								.createQueryBuilder()
								.relation(MarkRegister, "students")
								.of(entity)
								.add(oStudent);

							await queryRunner.manager
								.getRepository(MarkRegister)
								.createQueryBuilder()
								.relation(MarkRegister, "exam_class_sub")
								.of(entity)
								.add(oExam);
						}
						);
				}

			}

			const res2 = await this.AddManyToMarkRegSummary(queryRunner.manager, examName, classId, currentUser);
			await queryRunner.commitTransaction();
			return true;

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addMarkRegister Unhandled Error: ", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async addStudentToRegister(
		studentId: string,
		input: IVerfiyMarkRegister,
		acadyear: string,
		currentUser: string): Promise<any> {

		try {
			const examName: string = input.examName;
			const classId: string = input.classId;
			const subjectId: string = input.subjectId;

			const res = await this.addStudentToMarkRegister(studentId, input, acadyear, currentUser);

			if (!res) {
				throw new InternalServerError("addStudentToRegister Unhandled Error: ");
			}

			const result = await this.getMarkEntry(examName, classId, subjectId, acadyear);
			return result;

		} catch (error) {
			throw new InternalServerError("addStudentToRegister Unhandled Error: ", error);
		}
	}

	private async addStudentToMarkRegister(
		studentId: string,
		input: IVerfiyMarkRegister,
		acadyear: string,
		currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();

		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const examName: string = input.examName;
			const classId: string = input.classId;
			const subjectId: string = input.subjectId;

			const hasData = await queryRunner.manager
				.getRepository(MarkRegister)
				.createQueryBuilder("reg")
				.leftJoin("reg.exam_class_sub", "exams")
				.leftJoin("exams.class", "class")
				.leftJoin("exams.subjects", "subjects")
				.leftJoin("reg.students", "students")
				.where("exams.name = :examName", { examName: examName })
				.andWhere("class.id = :classId", { classId: classId })
				.andWhere("subjects.id = :subjectId", { subjectId: subjectId })
				.andWhere("students.id = :studentId", { studentId: studentId })
				.getCount();

			if (hasData === 0) {
				const oExam = await queryRunner.manager
					.getRepository(Exams)
					.createQueryBuilder("exam")
					.where("exam.name = :examName", { examName: examName })
					.andWhere("exam.class = :classId", { classId: classId })
					.andWhere("exam.subjects = :subjectId", { subjectId: subjectId })
					.getOne();

				const oStudent = await queryRunner.manager.getRepository(Students)
					.findOne({ where: { id: studentId } });

				const entity = new MarkRegister();
				entity.marks_obtained = 0;
				entity.grade = "";
				entity.percentage = 0;
				entity.acad_year = acadyear;
				entity.notes = "";
				entity.createdby = currentUser;

				await queryRunner.manager
					.getRepository(MarkRegister)
					.createQueryBuilder()
					.insert()
					.into(MarkRegister)
					.values(entity)
					.execute()
					.then(async (r) => {
						await queryRunner.manager
							.getRepository(MarkRegister)
							.createQueryBuilder()
							.relation(MarkRegister, "students")
							.of(entity)
							.add(oStudent)
							.catch(error => {
								throw new InternalServerError("addStudentToMarkRegister Error: ", "Student already present in this class");
							});

						await queryRunner.manager
							.getRepository(MarkRegister)
							.createQueryBuilder()
							.relation(MarkRegister, "exam_class_sub")
							.of(entity)
							.add(oExam);

						await this.upsertMarkRegSummary(
							queryRunner.manager,
							examName,
							classId,
							studentId,
							currentUser);
					}
					).catch(error => {
						throw new InternalServerError("addStudentToMarkRegister Error: ", "Student already present in this class");
					});
			} else {
				throw new InternalServerError("Message: ", "Student already present in this class");
			}

			await queryRunner.commitTransaction();
			return true;

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addStudentToMarkRegister Error: ", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async getMarkEntry(
		examName: string,
		classId: string,
		subjectId: string,
		acadyear: string): Promise<any> {
		try {
			const q_reg = await getManager()
				.getRepository(MarkRegister)
				.createQueryBuilder("marks")
				.select([
					"marks.id AS id",
					"exams.name AS examName",
					"class.id AS classId",
					"class.name AS className",
					"class.section AS classSection",
					"subjects.id AS subjectId",
					"subjects.name AS subjectName",
					"students.id AS studentId",
					"students.firstname AS firstName",
					"students.lastname AS lastName",
					"exams.max_marks AS maxMarks",
					"marks.marks_obtained AS marksObtained",
					"marks.percentage AS perc",
					"marks.acad_year AS acad_year",
					"marks.notes AS notes"
				])
				.leftJoinAndSelect("marks.exam_class_sub", "exams")
				.leftJoinAndSelect("exams.class", "class")
				.leftJoinAndSelect("exams.subjects", "subjects")
				.leftJoinAndSelect("marks.students", "students")
				// .leftJoinAndSelect("marks.grade", "grade")
				// .leftJoin("marks.acad_year", "acdyr")
				.where("exams.name = :examName", { examName: examName })
				.andWhere("class.id = :classId", { classId: classId })
				.andWhere("subjects.id = :subjectId", { subjectId: subjectId })
				// .andWhere("acdyr.id = :acdyr", { acdyr: acadyear })
				.orderBy("students.firstname", "ASC")
				.addOrderBy("students.gender", "DESC")
				.getRawMany();

			return q_reg;

		} catch (error) {
			throw new InternalServerError("getAllMarkRegister Unhandled Error: ", error);
		}
	}

	public async editMarkRegister(
		id: string,
		marksObtained: number,
		maxMarks: number,
		examName: string,
		classId: string,
		studentId: string,
		currentUser: string): Promise<any> {

		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();

		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const perc = (marksObtained / maxMarks) * 100;

			const getGrade = await queryRunner.manager
				.createQueryBuilder()
				.select(["grd.id", "grd.min", "grd.max"])
				.from(subQry => {
					const qb = subQry
						.select([
							"g.id AS id", "g.min as min", "g.max as max",
						])
						.from(ExamGrades, "g")
						.orderBy("g.min", "ASC");
					return qb;
				}, "grd")
				.where("grd.min <= :markValue AND grd.max >= :markValue", { markValue: perc })
				.getRawOne();

			const gradeId = (getGrade && getGrade.id) ? getGrade.id : undefined;

			await queryRunner.manager
				.createQueryBuilder()
				.update(MarkRegister)
				.set({
					marks_obtained: Number(marksObtained),
					percentage: Number(perc),
					grade: gradeId,
					updatedby: currentUser
				})
				.where("id = :id", {
					id: id
				})
				.execute()
				.then(async (r) => {
					await this.upsertMarkRegSummary(
						queryRunner.manager,
						examName,
						classId,
						studentId,
						currentUser);
					await queryRunner.commitTransaction();
					return { Messages: "Updated successfully" };
				})
				.catch(async () => {
					await queryRunner.rollbackTransaction();
					return { Messages: "Unable to save" };
				});
			return { Messages: "Updated successfully" };

		} catch (error) {
			console.log("error=", error);
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("editMarkRegister Unhandled Error: ", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	private async upsertMarkRegSummary(
		queryRunner: EntityManager,
		examName: string,
		classId: string,
		studentId: string,
		currentUser: string): Promise<any> {
		try {
			let response = undefined;
			const getTotals: IMarkRegisterSummary = await queryRunner
				.getRepository(MarkRegister)
				.createQueryBuilder("marks")
				.select([
					"students.id AS studentId",
					"SUM(marks.marks_obtained) AS total_marks_obtained",
					"SUM(exams.max_marks) AS total_max_marks"])
				.leftJoin("marks.exam_class_sub", "exams")
				.leftJoin("exams.class", "class")
				.leftJoin("exams.subjects", "subjects")
				.leftJoin("marks.students", "students")
				.where("exams.name = :examName", { examName: examName })
				.andWhere("class.id = :classId", { classId: classId })
				.andWhere("students.id = :studentId", { studentId: studentId })
				.orderBy("students.firstname", "ASC")
				.groupBy("students.id")
				.getRawOne();

			const oSummary = await queryRunner
				.getRepository(MarkRegisterSummary)
				.createQueryBuilder("s")
				.where("s.exam_name = :examName", { examName: examName })
				.andWhere("s.class_id = :classId", { classId: classId })
				.andWhere("s.student_id = :studentId", { studentId: studentId })
				.getOne();

			const total_marks_obtained = getTotals.total_marks_obtained;
			const total_max_marks = getTotals.total_max_marks;
			const total_perc = (total_marks_obtained / total_max_marks) * 100;
			const totalGradeObj = await this.findGrade(total_perc);
			const total_grade = totalGradeObj.gradeName;
			const total_grade_color = totalGradeObj.gradeColor;

			const entity = new MarkRegisterSummary();
			entity.exam_name = examName;
			entity.class_id = classId;
			entity.student_id = studentId;
			entity.total_marks_obtained = total_marks_obtained;
			entity.total_max_marks = total_max_marks;
			entity.total_grade = total_grade;
			entity.total_percentage = total_perc;
			entity.total_grade_color = total_grade_color;

			if (oSummary && oSummary.id) {
				const reg_summary_id = oSummary.id;
				entity.updatedby = currentUser;

				response = await queryRunner
					.getRepository(MarkRegisterSummary)
					.update(reg_summary_id, entity)
					.catch(e => {

					});
			} else {
				entity.createdby = currentUser;

				response = await queryRunner
					.getRepository(MarkRegisterSummary)
					.save(entity);
			}
			return response;
		} catch (error) {
			throw new InternalServerError("upsertMarkRegSummary Error: ", error);
		}
	}

	private async AddManyToMarkRegSummary(
		queryRunner: EntityManager,
		examName: string,
		classId: string,
		currentUser: string): Promise<any> {
		try {
			let response = undefined;

			const oSummary = await queryRunner
				.getRepository(MarkRegisterSummary)
				.createQueryBuilder("s")
				.where("s.exam_name = :examName", { examName: examName })
				.andWhere("s.class_id = :classId", { classId: classId })
				.getCount();

			if (oSummary === 0) {

				const oStudendID = await getManager()
					.getRepository(ClassSections)
					.createQueryBuilder("c")
					.select([
						"st.id AS studentId"
					])
					.leftJoin("c.students", "st")
					.where("c.id = :classId", { classId: classId })
					.andWhere("st.isactive = true")
					.orderBy("st.firstname", "ASC")
					.addOrderBy("st.gender", "DESC")
					.getRawMany<IMarkRegisterData>();

				for (let i = 0; i <= oStudendID.length - 1; i++) {
					const entity = new MarkRegisterSummary();
					entity.exam_name = examName;
					entity.class_id = classId;
					entity.student_id = oStudendID[i].studentId;
					entity.total_marks_obtained = 0;
					entity.total_max_marks = 0;
					entity.total_grade = "";
					entity.total_percentage = 0;
					entity.total_grade_color = "";
					entity.createdby = currentUser;

					response = await queryRunner
						.getRepository(MarkRegisterSummary)
						.save(entity);
				}
			}

			return response;
		} catch (error) {
			throw new InternalServerError("AddMarkRegisterSummary Error: ", error);
		}
	}

	private async findGrade(marks: number): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ExamGrades)
				.createQueryBuilder("g")
				.select(["g.name AS gradeName", "g.color as gradeColor"])
				.where("g.min <= :markValue AND g.max >= :markValue", { markValue: marks })
				.getRawOne();

			const result = res ? {
				gradeName: res.gradeName,
				gradeColor: res.gradeColor
			} : undefined;
			return result;
		} catch (error) {
			throw new InternalServerError("FindGrade Unhandled Error: ", error);
		}
	}

	private async findPercentage(examId: string, marks: number): Promise<any> {
		try {
			let perc = 0;
			const res = await getManager()
				.getRepository(Exams)
				.createQueryBuilder("exams")
				.where("exams = :id", { id: examId })
				.getOne();
			if (res) {
				const max_marks = Number(res.max_marks);
				const t_marks = Number(marks);
				perc = ((max_marks / t_marks) * 100);
			}
			return perc;
		} catch (error) {
			throw new InternalServerError("FindGrade Unhandled Error: ", error);
		}
	}
}
