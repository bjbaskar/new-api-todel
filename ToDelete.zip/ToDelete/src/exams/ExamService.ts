import { injectable } from "inversify";

import { InternalServerError } from "../core/exceptions";
import { IExam, IMarkRegister, IExamGrade, IVerfiyMarkRegister } from "./IExam";
import { ExamMasterService } from "./ExamMasterSvc";
import { MarkEntryService } from "./ExamMarkEntrySvc";
import { ExamGradeService } from "./ExamGradeSvc";
import { MarkRegisterService } from "./ExamMarkRegisterSvc";
import { PromotionService } from "./PromotionSvc";
import { IPromotionInput } from "./interfaces/IPromotionInput";

@injectable()
export class ExamService {
	constructor() { }

	/**
	 * Exam Master Service
	 */

	public async addExamMaster(input: IExam, currentUser: string): Promise<any> {
		try {
			const obj = new ExamMasterService();
			const res = obj.addExamMaster(input, currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("addExamMaster Unhandled Error: Unable to delete", error);
		}
	}

	public async editExamMaster(id: string, input: IExam, currentUser: string): Promise<any> {
		try {
			const obj = new ExamMasterService();
			const res = obj.editExamMaster(id, input, currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("editExamMaster Unhandled Error: Unable to save", error);
		}
	}

	public async delExamMaster(id: string): Promise<any> {
		try {
			const obj = new ExamMasterService();
			const res = obj.delExamMaster(id);
			return res;

		} catch (error) {
			throw new InternalServerError("delExamMaster Unhandled Error: Unable to delete", error);
		}
	}

	public async getAllExamMaster(pageNo: number, pageSize: number, examName: string, classId: string): Promise<any> {
		try {
			const obj = new ExamMasterService();
			const res = obj.getAll(pageNo, pageSize, examName, classId);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getOneExamMaster(id: string): Promise<any> {
		try {
			const obj = new ExamMasterService();
			const res = obj.getOne(id);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	/**
	 *  MarkRegister Service
	 */

	public async verifyMarkRegister(input: IVerfiyMarkRegister): Promise<any> {
		try {
			const obj = new MarkEntryService();
			const res = obj.verifyMarkReg(input);
			return res;

		} catch (error) {
			throw new InternalServerError("addMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async createMarkRegister(input: IVerfiyMarkRegister, acadyear: string, currentUser: string): Promise<any> {
		try {
			const obj = new MarkEntryService();
			const res = obj.createMarkRegister(input, acadyear, currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("createMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async addStudentToRegister(studentId: string, input: IVerfiyMarkRegister, acadyear: string, currentUser: string): Promise<any> {
		try {
			const obj = new MarkEntryService();
			const res = obj.addStudentToRegister(studentId, input, acadyear, currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("createMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async editMarkRegister(
		id: string,
		marksObtained: number,
		maxMarks: number,
		examName: string,
		classId: string,
		studentId: string,
		currentUser: string): Promise<any> {
		try {
			const obj = new MarkEntryService();
			const res = obj.editMarkRegister(
				id,
				marksObtained,
				maxMarks,
				examName,
				classId,
				studentId,
				currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getMarkEntry(input: IVerfiyMarkRegister, acadyear: string): Promise<any> {
		try {
			const examName: string = input.examName;
			const classId: string = input.classId;
			const subjectId: string = input.subjectId;

			const obj = new MarkEntryService();
			const res = obj.getMarkEntry(examName, classId, subjectId, acadyear);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getClassMarkRegister(examName: string, classId: string, acadyear: string): Promise<any> {
		try {
			const obj = new MarkRegisterService();
			const res = obj.getClassMarkRegister(examName, classId, acadyear);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getStudentMarks(
		examName: string,
		classId: string,
		studentId: string,
		acadyear: string
	): Promise<any> {
		try {
			const obj = new MarkRegisterService();
			const res = obj.getStudentMarks(examName, classId, studentId, acadyear);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getStudentsForPromotion(examName: [string], classId: string, acadyear: string): Promise<any> {
		try {
			const inputParams: IPromotionInput = undefined;
			const obj = new PromotionService(inputParams);
			const res = obj.getStudentsForPromotion(examName, classId, acadyear);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async doPromotion(
		input: IPromotionInput,
		currentUser: string
	): Promise<any> {
		try {
			input.currentUser = currentUser;
			const obj = new PromotionService(input);
			const res = obj.doPromotion();
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getPromotionHistory(classId: string, acadyear: string): Promise<any> {
		try {
			const inputParams: IPromotionInput = undefined;
			const obj = new PromotionService(inputParams);
			const res = obj.getPromotionHistory(classId, acadyear);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	/**
	 *  Exam Grade Service
	 */

	public async addMarkGrade(input: IExamGrade, currentUser: string): Promise<any> {
		try {
			const obj = new ExamGradeService();
			const res = obj.addGrade(input, currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("addMarkGrade Unhandled Error: Unable to delete", error);
		}
	}

	public async editMarkGrade(id: string, input: IExamGrade, currentUser: string): Promise<any> {
		try {
			const obj = new ExamGradeService();
			const res = obj.editGrade(id, input, currentUser);
			return res;

		} catch (error) {
			throw new InternalServerError("editMarkGrade Unhandled Error: Unable to delete", error);
		}
	}

	public async delMarkGrade(id: string): Promise<any> {
		try {
			const obj = new ExamGradeService();
			const res = obj.delGrade(id);
			return res;

		} catch (error) {
			throw new InternalServerError("delMarkGrade Unhandled Error: Unable to delete", error);
		}
	}

	public async getExamGrade(id: string): Promise<any> {
		try {
			const obj = new ExamGradeService();
			const res = obj.getGrade(id);
			return res;
		} catch (error) {
			throw new InternalServerError("getExamGrade: Unhandled Error", error);
		}
	}

	public async getAllExamGrade(): Promise<any> {
		try {
			const obj = new ExamGradeService();
			const res = obj.getAllGrade();
			return res;
		} catch (error) {
			throw new InternalServerError("getAllMarkRegister: Unhandled Error", error);
		}
	}

}