import { getManager, getConnection, In, QueryRunner, EntityManager } from "typeorm";
import _ from "lodash";

import { IClass, IClassSubject, IClassStaff } from "../master/classsec/IClass";
import { IExam } from "./IExam";
import { Exams } from "../core/entities/Exams/Exam";
import { BadRequest, BadMapping, InternalServerError } from "../core/exceptions";
import { ClassTeacher } from "../core/entities/Master/ClassTeacher";
import { Subject } from "../core/entities/Master/Subject";

export class ExamMasterService {
	constructor() { }

	public async addExamMaster(input: IExam, currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const entity = Object.assign(new Exams(), input);
			entity.createdby = currentUser;

			const result = await queryRunner.manager
				.getRepository(Exams)
				.save(entity);
			await queryRunner.commitTransaction();

			return result;

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addExamMaster Unhandled Error: Unable to save", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async editExamMaster(id: string, input: IExam, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new Exams(), input);
			entity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(Exams)
				.update(id, entity);
			return res;

		} catch (error) {
			throw new InternalServerError("editExamMaster Unhandled Error: Unable to save", error);
		}
	}

	public async delExamMaster(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(Exams)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}

		} catch (error) {
			throw new InternalServerError("delExamMaster Unhandled Error: Unable to delete", error);
		}
	}

	public async getAll(pageNo: number, pageSize: number, examName: string, classId: string): Promise<any> {
		try {

			const currenPageNo = pageNo - 1;

			const res = getManager()
				.getRepository(Exams)
				.createQueryBuilder("exam")
				.select([
					"exam.id AS id",
					"exam.name AS examName",
					"exam.min_marks AS minMarks",
					"exam.max_marks AS maxMarks",
					"exam.orderby AS orderby",
					"exam.notes AS notes",
					"exam.is_final_exam AS is_final_exam",
					"exam.createdby AS createdby",
					"exam.createdon AS createdon",
					"exam.updatedby AS updatedby",
					"exam.updatedon AS updatedon",
					"class.id AS classId",
					"class.name AS className",
					"class.section AS classSection",
					"subjects.id AS subjectId",
					"subjects.name AS subjectName",
					"subjects.subcode AS subjectSubcode",
					"subjects.color AS subjectColor"])
				.leftJoin("exam.class", "class")
				.leftJoin("exam.subjects", "subjects");

			if (classId && classId !== "ALL") {
				res.where("class.id = :classId", { classId: classId });
			}
			if (examName && examName !== "ALL") {
				res.andWhere("exam.name = :examName", { examName: examName });
			}
			res.orderBy("exam.orderby", "ASC")
				.addOrderBy("class.name", "ASC");

			res.offset(currenPageNo * pageSize);
			res.limit(pageSize);

			const examMasterRes = {
				rows: await res.getRawMany(),
				count: await res.getCount()
			};
			return examMasterRes;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getOne(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Exams)
				.createQueryBuilder("exams")
				.select([
					"exam.id",
					"exam.name",
					"exam.min_marks",
					"exam.max_marks",
					"exam.orderby",
					"exam.notes",
					"exam.is_final_exam",
					"exam.createdby",
					"exam.createdon",
					"exam.updatedby",
					"exam.updatedon",
					"class.id",
					"class.name",
					"class.section",
					"subjects.id",
					"subjects.name",
					"subjects.subcode",
					"subjects.color"
				])
				.leftJoin("exam.class", "class")
				.leftJoin("exam.subjects", "subjects")
				.where("exams.id = :examId", { examId: id })
				.getRawOne();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}