
export interface IExam {
	id: string;
	name: string;
	class: string;
	subjects: string;
	min_marks: number;
	max_marks: number;
	orderby: number;
	notes: string;
	is_final_exam: boolean;
}

export interface IVerfiyMarkRegister {
	examName: string;
	classId: string;
	subjectId: string;
}

export interface IMarkRegisterData {
	examId: string;
	studentId: string;
}

export interface IMarkRegister {
	id: string;
	studentId: string;
	studentName: string;
	gender: string;
	examName: string;
	className: string;
	classSection: string;
	maxMarks: number;
	subjectName: string;
	subjectColor: string;
	firstName: string;
	lastName: string;
	marksObtained: number;
	notes: string;
	perc: number;
	gradeName: string;
	gradePoint: string;
	gradeColor: string;
	totalMarksObtained: number;
	totalMaxMarks: number;
	totalGrade: string;
	totalPercentage: number;
	acad_year: string;
}

export interface IMarkRegisterResult00 {
	id: string;
	studentId: string;
	studentName: string;
	gender: string;
	examName: string;
	className: string;
	classSection: string;
	maxMarks: number;
	marks: IMarkRegisterResult2[];
	subjectName: string;
	subjectColor: string;
	firstName: string;
	lastName: string;
	marksObtained: number;
	notes: string;
	perc: number;
	gradeName: string;
	gradePoint: string;
	gradeColor: string;
	totalMarksObtained: number;
	totalMaxMarks: number;
	totalGrade: string;
	totalPercentage: number;
	acad_year: string;
	createdby: string;
	// createdon: DateTimeType
	updatedby: string;
	// updatedon: DateTimeType
}

export interface IMarkRegisterResult2 {
	subjectName: string;
	subjectColor: string;
	marksObtained: number;
	perc: number;
	gradeName: string;
	gradePoint: string;
	gradeColor: string;
}

export interface IMarkRegisterSummary {
	studentId: string;
	total_marks_obtained: number;
	total_max_marks: number;
	total_perc: number;
}

export interface IExamGrade {
	id: string;
	name: string;
	description: string;
	color: string;
	grade_point: string;
	min: number;
	max: number;
	orderby: number;
	acad_year: string;
	notes: string;
}

export interface IExamTimeTable {
	id: string;
	exam_name: string;
	class_name: string;
	subjects: string;
	examdate: Date;
	start_time: Date;
	end_time: Date;
	noofhours: number;
	notes: string;
}

// export interface IPromotion {
// 	id: string;
// 	student: string;
// 	class_from: string;
// 	class_to: string;
// 	promotion_date: Date;
// 	graduated: string;
// 	acd_year_from: string;
// 	acd_year_to: string;
// }