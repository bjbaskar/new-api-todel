export interface IPromotionInput {
	classIdFrom: string;
	classIdTo: string;
	acadYearFrom: string;
	acadYearTo: string;
	studentId: [string];
	detainedStudentIds: [string];
	currentUser: string;
	examName: string;
	isFinalYear: boolean;
	promoteReason: string;
}