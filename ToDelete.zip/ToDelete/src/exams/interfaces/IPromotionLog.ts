export interface IPromotionLog {
	getexamname: string;
	ispromotetonewclass: boolean;
	noofstudentspromoted: string;

	updateacdyear: boolean;
	noofupdateacdyear: string;

	detainedstudents: string;
	noofdetained: string;

	addmarkstoarchieved: boolean;
	noofaddmarksarchieved: string;

	hasdeletedmarkregister: boolean;
	noofdelmarkregister: string;

	hasdeletedmarkregistersum: boolean;
	noofdelmarkregistersum: string;

	hasattendancearchieved: boolean;
	noofattendancearchieved: string;

	hasdeletedattendance: boolean;
	noofattendancedeleted: string;

	hasupdatepromotionstatus: boolean;

	hasupdatedtoalumni: boolean;
	noofalumni: string;
}

