export interface IStudentPromotion {
	id: string;
	studentId: string;
	studentName: string;
	gender: string;
	examName: string;
	className: string;
	classSection: string;
	totalPercentage: number;
	totalGrade: string;
	totalGradeColor: string;
	acadYear: string;
}