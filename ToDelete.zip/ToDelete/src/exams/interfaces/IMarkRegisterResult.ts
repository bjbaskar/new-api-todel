export interface IMarkRegisterResult {
	studentId: string;
	marks: IMarkRegisterSubjectResult[];
	profile: IMarkRegisterProfileResult;
	acad_year: string;
}

export interface IMarkRegisterSubjectResult {
	subjectName: string;
	subjectColor: string;
	subjectOrderby: number;
	marksObtained: number;
	maxMarks: number;
	perc: number;
	gradeName: string;
	gradePoint: string;
	gradeColor: string;
}

export interface IMarkRegisterProfileResult {
	firstName: string;
	lastName: string;
	gender: string;
	examName: string;
	className: string;
	classSection: string;
	totalMarksObtained: string;
	totalMaxMarks: string;
	totalGrade: string;
	totalGradeColor: string;
	totalPercentage: string;
	notes: string;
}