import { IParents } from "../../students/IStudent";
import { IStudent } from "../../students/IStudent";

export interface IStudentArchieve {
	student_id: string;

	promoted_to: string;

	promote_reason: string;

	classsec: string;

	profile: IStudent;

	parents: IParents;

	// profile1: {
	// 	id: string;

	// 	studentno: number;

	// 	prefixyear: number;

	// 	aadhaarno: string;

	// 	emisno: string;

	// 	udiseno: string;

	// 	firstname: string;

	// 	lastname: string;

	// 	gender: string;

	// 	dob: Date;

	// 	doj: Date;

	// 	nationality: string;

	// 	religion: string;

	// 	castecategory: string;

	// 	community: string;

	// 	mothertongue: string;

	// 	bloodgroup: string;

	// 	identification: string;

	// 	isactive: boolean;

	// 	disability: string;

	// 	notes: string;

	// 	photo: string;
	// };

	// parents1: [{
	// 	fathername: string;
	// 	fatherdob: Date;
	// 	fathergraduation: string;
	// 	fatheroccupation: string;
	// 	fathercompanyname: string;
	// 	fatherincome: number;
	// 	fatheraadhaarno: string;
	// 	mothername: string;
	// 	motherdob: Date;
	// 	mothergraduation: string;
	// 	motheroccupation: string;
	// 	mothercompanyname: string;
	// 	motherincome: number;
	// 	motheraadhaarno: string;
	// 	guardianname: string;
	// 	guardianoccupation: string;
	// 	notes: string;
	// 	address: [{
	// 		type: string;
	// 		address1: string;
	// 		address2: string;
	// 		city: string;
	// 		district: string;
	// 		state: string;
	// 		country: string;
	// 		postalcode: number;
	// 		mobile: string;
	// 		homephone: string;
	// 		email: string;
	// 		notes: string;
	// 	}]
	// }];

	documents: string;

	govtrte: [{
		CWSN: Array<string>;
		amountreceived: number;
		amountdate: Date;
		facilitiesprovided: Array<string>;
		uniformsets: string;
		freetextbook: string;
		freetransport: string;
		notes: string;
	}];

	acadyear: string;

	school_id: {
		id: string,
		name: string
	};

	user: string;

	createdby: string;

	createdon: Date;
}