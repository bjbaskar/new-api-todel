export interface IPromotionStatus {
	status: string;
	class_id: string;
	acad_year: string;
	school_id: string;
	createdby: string;
}