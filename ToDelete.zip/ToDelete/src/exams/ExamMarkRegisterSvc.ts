import {
	getManager,
	MoreThanOrEqual,
	LessThanOrEqual,
	getConnection
} from "typeorm";
import _ from "lodash";

// import { IClass, IClassSubject, IClassStaff } from "../master/classsec/IClass";
import { IMarkRegister, IMarkRegisterData, IMarkRegisterResult2, IVerfiyMarkRegister } from "./IExam";
import { Exams } from "../core/entities/Exams/Exam";
import { MarkRegister } from "../core/entities/Exams/MarkRegister";
import { ExamGrades } from "../core/entities/Exams/Grades";

import { InternalServerError, NotFound } from "../core/exceptions";
import { Students } from "../core/entities/Students/Student";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { MarkRegisterSummary } from "../core/entities/Exams/MarkRegisterSum";
import { IMarkRegisterResult } from "./interfaces/IMarkRegisterResult";

export class MarkRegisterService {
	constructor() { }

	public async getClassMarkRegister(
		examName: string,
		classId: string,
		acadyear: string): Promise<IMarkRegisterResult[]> {
		try {

			const q_reg_data = await getManager()
				.getRepository(MarkRegister)
				.createQueryBuilder("marks")
				.select([
					"marks.id AS id",
					"exams.name AS examName",
					"class.name AS className",
					"class.section AS classSection",
					"subjects.name AS subjectName",
					"subjects.color AS subjectColor",
					"subjects.subcode AS subjectCode",
					"subjects.orderby AS subjectOrderby",
					"students.id AS studentId",
					"students.firstname AS firstName",
					"students.lastname AS lastName",
					"students.gender AS gender",
					"exams.min_marks AS minMarks",
					"exams.max_marks AS maxMarks",
					"marks.marks_obtained AS marksObtained",
					"marks.percentage AS perc",
					"marks.acad_year AS acad_year",
					"marks.notes AS notes",
					"grade.name AS gradeName",
					"grade.color AS gradeColor",
					"grade.grade_point AS gradePoint",
					"total.total_marks_obtained AS totalMarksObtained",
					"total.total_max_marks AS totalMaxMarks",
					"total.total_grade AS totalGrade",
					"total.total_grade_color as totalGradeColor",
					"total.total_percentage AS totalPercentage"
				])
				.leftJoin("marks.exam_class_sub", "exams")
				.leftJoin("exams.class", "class")
				.leftJoin("exams.subjects", "subjects")
				.leftJoin("marks.students", "students")
				.leftJoin(ExamGrades, "grade", "grade.id = marks.grade")
				.leftJoin(subQry => {
					const qb = subQry
						.select([
							"s.*",
						])
						.from(MarkRegisterSummary, "s")
						.where("s.exam_name = :examName", { examName: examName })
						.andWhere("s.class_id = :classId", { classId: classId });
					// .andWhere("s.student_id = :studentId", { studentId: studentId })

					return qb;
				}, "total",
					`total.exam_name = exams.name
					AND total.class_id = class.id
					AND total.student_id = students.id`)
				// .leftJoin("marks.acad_year", "acdyr")
				.where("exams.name = :examName", { examName: examName })
				.andWhere("class.id = :classId", { classId: classId })
				// .andWhere("acdyr.id = :acdyr", { acdyr: acadyear })
				.orderBy("students.firstname", "ASC")
				.addOrderBy("students.gender", "DESC")
				.addOrderBy("subjects.orderby", "ASC")
				.getRawMany();

			const q_subj = await this.getSubjectsByClass(classId);

			const result: IMarkRegisterResult[] = await _.chain(q_reg_data)
				.groupBy("studentId")
				.map((value, key) => {

					let keyValue: string = undefined;
					const marksArr: any = [];
					let profile: any = {};

					_.map(value, o => {

						const marks = _.pick(o, [
							"subjectName",
							"subjectColor",
							"subjectOrderby",
							"marksObtained",
							"maxMarks",
							"perc",
							"gradeName",
							"gradePoint",
							"gradeColor"
						]);

						marksArr.push(marks);

						if (key !== keyValue) {
							keyValue = o.studentId;
							profile = _.pick(o, [
								"firstName",
								"lastName",
								"gender",
								"examName",
								"className",
								"classSection",
								"totalMarksObtained",
								"totalMaxMarks",
								"totalGrade",
								"totalGradeColor",
								"totalPercentage",
								"notes"
							]);
						}

					});

					const unionSubj = [...marksArr, ...q_subj];
					const distinctSubjects = unionSubj.filter(
						(thing, i, arr) => arr.findIndex(t => t.subjectName === thing.subjectName) === i
					);
					const finalSubj = _.orderBy(distinctSubjects, ["subjectOrderby"], ["asc"]);

					const oResult: IMarkRegisterResult = {
						studentId: (key),
						profile: profile,
						marks: finalSubj,
						acad_year: acadyear
					};
					return oResult;
				})
				.value();

			return result;

		} catch (error) {
			throw new InternalServerError("getClassMarkRegister Unhandled Error: ", error);
		}
	}

	public async getStudentMarks(
		examName: string,
		classId: string,
		studentId: string,
		acadyear: string): Promise<any> {
		try {

			const q_data = getManager()
				.getRepository(MarkRegister)
				.createQueryBuilder("marks")
				.select([
					"marks.id AS id",
					"exams.name AS examName",
					"class.name AS className",
					"class.section AS classSection",
					"subjects.name AS subjectName",
					"subjects.color AS subjectColor",
					"subjects.subcode AS subjectCode",
					"subjects.orderby AS subjectOrderby",
					"students.id AS studentId",
					"students.firstname AS firstName",
					"students.lastname AS lastName",
					"students.gender AS gender",
					"exams.min_marks AS minMarks",
					"exams.max_marks AS maxMarks",
					"marks.marks_obtained AS marksObtained",
					"marks.percentage AS perc",
					"marks.acad_year AS acad_year",
					"marks.notes AS notes",
					"grade.name AS gradeName",
					"grade.color AS gradeColor",
					"grade.grade_point AS gradePoint",
					"total.total_marks_obtained AS totalMarksObtained",
					"total.total_max_marks AS totalMaxMarks",
					"total.total_grade AS totalGrade",
					"total.total_grade_color as totalGradeColor",
					"total.total_percentage AS totalPercentage"
				])
				.leftJoin("marks.exam_class_sub", "exams")
				.leftJoin("exams.class", "class")
				.leftJoin("exams.subjects", "subjects")
				.leftJoin("marks.students", "students")
				.leftJoin(ExamGrades, "grade", "grade.id = marks.grade")
				.leftJoin(subQry => {
					const qb = subQry
						.select([
							"s.*",
						])
						.from(MarkRegisterSummary, "s");
					if (examName !== "Show All") {
						qb.where("s.exam_name = :examName", { examName: examName });
					}
					qb.andWhere("s.class_id = :classId", { classId: classId })
						.andWhere("s.student_id = :studentId", { studentId: studentId });

					return qb;
				}, "total",
					`total.exam_name = exams.name
					AND total.class_id = class.id
					AND total.student_id = students.id`);
			// .leftJoin("marks.acad_year", "acdyr")
			if (examName !== "Show All") {
				q_data.where("exams.name = :examName", { examName: examName });
			}
			q_data.andWhere("class.id = :classId", { classId: classId })
				.andWhere("students.id = :studentId", { studentId: studentId })
				// .andWhere("acdyr.id = :acdyr", { acdyr: acadyear })
				.orderBy("students.firstname", "ASC")
				.addOrderBy("students.gender", "DESC")
				.addOrderBy("subjects.orderby", "ASC");

			const q_data_Result = await q_data.getRawMany();

			const q_subj = await this.getSubjectsByClass(classId);

			const result = await _.chain(q_data_Result)
				.groupBy("examName")
				.map((value, key) => {

					let keyValue: string = undefined;
					const marksArr: any = [];
					let profile: any = {};

					_.map(value, o => {

						const marks = _.pick(o, [
							"subjectName",
							"subjectColor",
							"subjectOrderby",
							"marksObtained",
							"perc",
							"gradeName",
							"gradePoint",
							"gradeColor"
						]);

						marksArr.push(marks);

						if (key !== keyValue) {
							keyValue = o.examName;
							profile = _.pick(o, [
								"studentId",
								"firstName",
								"lastName",
								"gender",
								"examName",
								"className",
								"classSection",
								"maxMarks",
								"totalMarksObtained",
								"totalMaxMarks",
								"totalGrade",
								"totalGradeColor",
								"totalPercentage",
								"notes"
							]);
						}

					});

					const unionSubj = [...marksArr, ...q_subj];
					const distinctSubjects = unionSubj.filter(
						(thing, i, arr) => arr.findIndex(t => t.subjectName === thing.subjectName) === i
					);
					const finalSubj = _.orderBy(distinctSubjects, ["subjectOrderby"], ["asc"]);

					return {
						examName: (key),
						profile: profile,
						marks: finalSubj
					};
				})
				.value();

			// console.log("result = ", JSON.stringify(result, undefined, 2));
			return result;

		} catch (error) {
			throw new InternalServerError("getStudentMarks Unhandled Error: ", error);
		}
	}

	private async getSubjectsByClass(classId: string): Promise<any> {
		try {
			const result = await getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("cls")
				.select([`s.name as subjectName,
				s.color as subjectColor,
				s.orderby as subjectOrderby,
				0 as marksObtained,
				0 as perc,
				'' as gradeName,
				'' as gradePoint,
				'' as gradeColor`])
				.leftJoin("cls.classteachersub", "ct")
				.leftJoin("ct.subject", "s")
				.where("cls.id = :id", { id: classId })
				.orderBy("s.orderby")
				.getRawMany();

			return result;
		} catch (error) {
			throw new InternalServerError("FindGrade Unhandled Error: ", error);
		}
	}

}