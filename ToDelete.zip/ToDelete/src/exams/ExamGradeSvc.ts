import { getManager } from "typeorm";
import _ from "lodash";

// import { IClass, IClassSubject, IClassStaff } from "../master/classsec/IClass";
import { IExamGrade } from "./IExam";
import { ExamGrades } from "../core/entities/Exams/Grades";

import { InternalServerError } from "../core/exceptions";
// import { ClassTeacher } from "../core/entities/Master/ClassTeacher";
// import { Subject } from "../core/entities/Master/Subject";

export class ExamGradeService {
	constructor() { }

	public async addGrade(input: IExamGrade, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new ExamGrades(), input);
			entity.createdby = currentUser;

			const result = await getManager()
				.getRepository(ExamGrades)
				.save(entity);

			return result;

		} catch (error) {
			throw new InternalServerError("addGrade Unhandled Error: Unable to save", error);
		}
	}

	public async editGrade(id: string, input: IExamGrade, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new ExamGrades(), input);
			entity.createdby = currentUser;

			const result = await getManager()
				.getRepository(ExamGrades)
				.update(id, entity);

			return result;

		} catch (error) {
			throw new InternalServerError("editGrade Unhandled Error: Unable to save", error);
		}
	}

	public async delGrade(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(ExamGrades)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}

		} catch (error) {
			throw new InternalServerError("delMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getGrade(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ExamGrades)
				.createQueryBuilder("g")
				.leftJoinAndSelect("g.exam_class_sub", "exams")
				.leftJoinAndSelect("exams.class", "class")
				.leftJoinAndSelect("exams.subjects", "subjects")
				.leftJoinAndSelect("g.acad_year", "acdyr")
				.where("g.id = :id", { id: id })
				.orderBy("g.name", "DESC")
				.getOne();
			return res;
		} catch (error) {
			throw new InternalServerError("getGrade Unhandled Error: ", error);
		}
	}

	public async getAllGrade(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ExamGrades)
				.createQueryBuilder("g")
				.orderBy("g.name", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("getAllGrade Unhandled Error: ", error);
		}
	}
}
