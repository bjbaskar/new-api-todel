import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const examTypeDef = typeDef;
const examResolver = resolvers;

export { examTypeDef, examResolver };
