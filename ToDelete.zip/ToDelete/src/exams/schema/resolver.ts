import { IAppContext } from "../../context";
import { IExam, IMarkRegister, IExamGrade, IVerfiyMarkRegister } from "../IExam";
import { IPromotionInput } from "../interfaces/IPromotionInput";

export const resolvers = {
	Query: {
		async getAllExamMaster(_: any, args: {
			pageNo: number, pageSize: number,
			examName: string, classId: string
		}, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getAllExamMaster(args.pageNo, args.pageSize, args.examName, args.classId);
			return res;
		},
		async getOneExamMaster(_: any, args: { id: string }, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getOneExamMaster(args.id);
			return res;
		},

		async verifyMarkRegister(_: any, args: { input: IVerfiyMarkRegister }, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.verifyMarkRegister(args.input);
			return res;
		},

		async getMarkEntry(root: any, args: { input: IVerfiyMarkRegister, acadyear: string }, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getMarkEntry(args.input, args.acadyear);
			return res;
		},

		async getClassMarkRegister(root: any, args: {
			examName: string,
			classId: string,
			acadyear: string
		}, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getClassMarkRegister(args.examName, args.classId, args.acadyear);
			return res;
		},

		async getStudentMarks(root: any, args:
			{ examName: string, classId: string, studentId: string, acadyear: string },
			context: IAppContext
		) {
			const svr = context.ExamService;
			const res = await svr.getStudentMarks(
				args.examName,
				args.classId,
				args.studentId,
				args.acadyear);
			return res;
		},

		async getStudentsForPromotion(root: any, args: {
			examName: [string],
			classId: string,
			acadyear: string
		}, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getStudentsForPromotion(args.examName, args.classId, args.acadyear);
			return res;
		},

		async getPromotionHistory(root: any, args: {
			classId: string,
			acadyear: string
		}, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getPromotionHistory(args.classId, args.acadyear);
			return res;
		},

		// async getExamGrade(_: any, args: { id: string }, context: IAppContext) {
		// 	const svr = context.ExamService;
		// 	const res = await svr.getExamGrade(args.id);
		// 	return res;
		// },
		async getAllExamGrade(_: any, args: any, context: IAppContext) {
			const svr = context.ExamService;
			const res = await svr.getAllExamGrade();
			return res;
		}
	},
	Mutation: {
		async addExamMaster(root: any, args: { input: IExam }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ExamService.addExamMaster(args.input, currentUser);
			return res;
		},
		async editExamMaster(root: any, args: { id: string, input: IExam }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ExamService.editExamMaster(args.id, args.input, currentUser);
			return res;
		},
		async delExamMaster(root: any, args: { id: string }, context: IAppContext) {
			const res = await context.ExamService.delExamMaster(args.id);
			return res;
		},

		async createMarkRegister(root: any, args: { input: IVerfiyMarkRegister, acadyear: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const svr = context.ExamService;
			const res = await svr.createMarkRegister(args.input, args.acadyear, currentUser);
			return res;
		},
		async editMarkRegister(root: any, args: {
			id: string,
			marksObtained: number,
			maxMarks: number
			examName: string,
			classId: string,
			studentId: string,
		}, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const svr = context.ExamService;
			const res = await svr.editMarkRegister(
				args.id,
				args.marksObtained,
				args.maxMarks,
				args.examName,
				args.classId,
				args.studentId,
				currentUser);
			return res;
		},
		async addStudentToRegister(root: any, args: { studentId: string, input: IVerfiyMarkRegister, acadyear: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const svr = context.ExamService;
			const res = await svr.addStudentToRegister(args.studentId, args.input, args.acadyear, currentUser);
			return res;
		},

		async doPromotion(root: any, args: { input: IPromotionInput }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const svr = context.ExamService;
			const res = await svr.doPromotion(args.input, currentUser);
			return res;
		},

		async addMarkGrade(root: any, args: { input: IExamGrade }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ExamService.addMarkGrade(args.input, currentUser);
			return res;
		},
		async editMarkGrade(root: any, args: { id: string, input: IExamGrade }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ExamService.editMarkGrade(args.id, args.input, currentUser);
			return res;
		},
		async delMarkGrade(root: any, args: { id: string }, context: IAppContext) {
			const res = await context.ExamService.delMarkGrade(args.id);
			return res;
		},
	}
};
