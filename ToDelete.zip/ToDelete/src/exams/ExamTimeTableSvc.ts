import { getManager } from "typeorm";
import _ from "lodash";

import { IExamTimeTable } from "./IExam";
import { InternalServerError } from "../core/exceptions";
import { ExamTimeTable } from "../core/entities/Exams/ExamTimeTable";

export class ExamTimeTableService {
	constructor() { }

	public async addExamTimeTable(input: IExamTimeTable, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new ExamTimeTable(), input);
			entity.createdby = currentUser;

			const result = await getManager()
				.getRepository(ExamTimeTable)
				.save(entity);

			return result;

		} catch (error) {
			throw new InternalServerError("addExamTimeTable Unhandled Error: Unable to save", error);
		}
	}

	public async editExamTimeTable(id: string, input: IExamTimeTable, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new ExamTimeTable(), input);
			entity.createdby = currentUser;

			const result = await getManager()
				.getRepository(ExamTimeTable)
				.update(id, entity);

			return result;

		} catch (error) {
			throw new InternalServerError("editExamTimeTable Unhandled Error: Unable to save", error);
		}
	}

	public async delExamTimeTable(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(ExamTimeTable)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}

		} catch (error) {
			throw new InternalServerError("delMarkReg Unhandled Error: Unable to delete", error);
		}
	}

	public async getExamTimeTable(classId: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ExamTimeTable)
				.createQueryBuilder("tt")
				.leftJoinAndSelect("tt.exam_class_sub", "exams")
				.leftJoinAndSelect("exams.class", "class")
				.leftJoinAndSelect("exams.subjects", "subjects")
				.where("g.id = :id", { id: classId })
				.orderBy("g.examdate", "ASC")
				.getOne();
			return res;
		} catch (error) {
			throw new InternalServerError("getMarkRegister Unhandled Error: ", error);
		}
	}

	public async getAllClassExamTimeTable(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ExamTimeTable)
				.createQueryBuilder("g")
				.leftJoinAndSelect("g.exam_class_sub", "exams")
				.leftJoinAndSelect("exams.class", "class")
				.leftJoinAndSelect("exams.subjects", "subjects")
				.orderBy("g.examdate", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("getAllMarkRegister Unhandled Error: ", error);
		}
	}
}
