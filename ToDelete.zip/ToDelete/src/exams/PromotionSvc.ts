import {
	getManager,
	getConnection,
	EntityManager,
	QueryRunner,
} from "typeorm";
import _ from "lodash";

import { Exams } from "../core/entities/Exams/Exam";
import { MarkRegister } from "../core/entities/Exams/MarkRegister";
import { ExamGrades } from "../core/entities/Exams/Grades";
import { MarkRegisterSummary } from "../core/entities/Exams/MarkRegisterSum";
import { Students } from "../core/entities/Students/Student";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { InternalServerError, NotFound } from "../core/exceptions";
import { IStudentPromotion } from "./interfaces/IStudentPromotion";
import { IPromotionInput } from "./interfaces/IPromotionInput";
import { PromotionServiceBase } from "./PromotionSvcBase";
import { PromotionStatus } from "../core/entities/Exams/PromotionStatus";

export class PromotionService extends PromotionServiceBase {

	private IN_PARAMS: IPromotionInput;
	constructor(params: IPromotionInput) {
		super(params);
		this.IN_PARAMS = params;
	}

	public async getStudentsForPromotion(
		examName: [string],
		classId: string,
		acadyear: string): Promise<any> {
		try {

			let result: any = {
				promotionData: [],
				status: undefined
			};

			if (await this.verifyPromotion(classId) > 0) {
				result = {
					promotionData: [],
					status: "COMPLETED"
				};
			}
			else {
				const q_reg_data = await getManager()
					.getRepository(MarkRegisterSummary)
					.createQueryBuilder("mrs")
					.select([
						"DISTINCT CONCAT(students.firstname, ' ', students.lastname) AS studentName",
						"CONCAT(class.name, ' ', class.section) AS classNameSection",
						"students.id AS studentId",
						"students.gender AS gender",
						"'' AS totalGrade",
						"'' AS totalGradeColor",
						"FORMAT((total.total_percentage/total.examCount),2) AS totalPercentage",
						"mrs.acad_year AS acadYear"
					])
					.leftJoin(Exams, "exams", "mrs.exam_name = exams.name")
					.leftJoin(ClassSections, "class", "mrs.class_id = class.id")
					.leftJoin(Students, "students", "mrs.student_id = students.id")
					// .leftJoin(ExamGrades, "grade", "grade.id = marks.grade")
					.leftJoin(subQry => {
						const qb = subQry
							.select([
								"SUM(s.total_percentage) AS total_percentage",
								"COUNT(s.exam_name) AS examCount",
								"s.class_id AS class_id",
								"s.student_id AS student_id"
							])
							.from(MarkRegisterSummary, "s")
							.where("s.exam_name IN (:examName)", { examName: examName })
							.andWhere("s.class_id = :classId", { classId: classId })
							.groupBy("s.student_id")
							.addGroupBy("s.class_id");
						return qb;
					}, "total",
						"total.class_id = mrs.class_id AND total.student_id = mrs.student_id")
					// .leftJoin("marks.acad_year", "acdyr")
					.where("exams.name IN (:examName)", { examName: examName })
					.andWhere("class.id = :classId", { classId: classId })
					// .andWhere("acdyr.id = :acdyr", { acdyr: acadyear })
					.orderBy("studentName", "ASC")
					.addOrderBy("gender", "DESC")
					.getRawMany();

				const gRes = _.map(q_reg_data, async (d: IStudentPromotion) => {
					const gradeObj = await this.findGrade(d.totalPercentage);
					if (gradeObj) {
						const total_grade = gradeObj.gradeName;
						const total_grade_color = gradeObj.gradeColor;
						const grade = {
							totalGrade: total_grade,
							totalGradeColor: total_grade_color
						};
						const res = { ...d, ...grade };

						return res;
					}
				});
				result = {
					status: undefined,
					promotionData: gRes
				};
			}

			return result;

		} catch (error) {
			throw new InternalServerError("getStudentsForPromotion: ", error);
		}
	}

	private async findGrade(marks: number): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(ExamGrades)
				.createQueryBuilder("g")
				.select(["g.name AS gradeName", "g.color as gradeColor"])
				.where("g.min <= :markValue AND g.max >= :markValue", { markValue: marks })
				.getRawOne();

			const result = res ? {
				gradeName: res.gradeName,
				gradeColor: res.gradeColor
			} : undefined;
			return result;
		} catch (error) {
			throw new InternalServerError("FindGrade Unhandled Error: ", error);
		}
	}

	private async verifyPromotion(classId: string): Promise<any> {
		try {
			const result = await getManager()
				.getRepository(PromotionStatus)
				.createQueryBuilder("ps")
				.where("class_id = :classId", { classId: classId })
				.andWhere("status = 'COMPLETED'")
				.getCount();
			return result;
		} catch (error) {
			throw new InternalServerError("verifyPromotion: ", error);
		}
	}

	public async doPromotion(): Promise<any> {
		try {

			if (this.IN_PARAMS.isFinalYear) {
				const final = await this.doPromotionFinalYear();
			} else {
				const inter = await this.doPromotionInternal();
			}

			await this.updatePromotionHistory();
			const histAtt = {
				classFrom: this.PARAMS.classIdFrom,
				classTo: this.PARAMS.classIdTo,
				acadFrom: this.PARAMS.acadYearFrom,
				acadTo: this.PARAMS.acadYearTo
			};
			const finalResult = { ...this.PR_LOG, ...histAtt };
			return finalResult;

		} catch (error) {
			console.log("error=", error);
			throw new InternalServerError("doPromotion: ", error);
		}
	}

	private async doPromotionInternal(): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();

		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const addToNewClass = await this.addToNewClass(queryRunner.manager);

			const updateAcadYear = await this.updateAcadYear(queryRunner.manager);

			const updateDetainedStudents = await this.updateDetainedStudents(queryRunner.manager);

			const addMarksToArchieve = await this.addMarksToArchieve(queryRunner.manager);

			const delMarkRegister = await this.deleteMarkRegister(queryRunner.manager);

			const delMarkRegisterSum = await this.deleteMarkRegisterSummary(queryRunner.manager);

			const addAttendanceTpArchieve = await this.addAttendanceToArchieve(queryRunner.manager);

			const deleteAttendanceToArchieve = await this.deleteAttendance(queryRunner.manager);

			const updPromotionStatus = await this.updatePromotionStatus(queryRunner.manager);

			// assignment archieve and delete, fee_balance archieve
			// await queryRunner.commitTransaction();
			await queryRunner.rollbackTransaction();

		} catch (error) {
			console.log("error=", error);
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("doPromotionInternal: ", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	private async doPromotionFinalYear(): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();

		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const addToAlumni = await this.addToAlumni(queryRunner.manager);

			const updateDetainedStudents = await this.updateDetainedStudents(queryRunner.manager);

			const addMarksToArchieve = await this.addMarksToArchieve(queryRunner.manager);

			const delMarkRegister = await this.deleteMarkRegister(queryRunner.manager);

			const delMarkRegisterSum = await this.deleteMarkRegisterSummary(queryRunner.manager);

			const addAttendanceToArchieve = await this.addAttendanceToArchieve(queryRunner.manager);

			const deleteAttendance = await this.deleteAttendance(queryRunner.manager);

			const updPromotionStatus = await this.updatePromotionStatus(queryRunner.manager);

			// update TC
			// await queryRunner.commitTransaction();
			await queryRunner.rollbackTransaction();

		} catch (error) {
			console.log("error=", error);
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("doPromotionFinalYear: ", error);
		}
		finally {
			await queryRunner.release();
		}
	}
}