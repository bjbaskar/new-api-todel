import {
	getManager,
	EntityManager
} from "typeorm";
import _ from "lodash";

import { MarkRegister } from "../core/entities/Exams/MarkRegister";
import { MarkRegisterSummary } from "../core/entities/Exams/MarkRegisterSum";
import { Students } from "../core/entities/Students/Student";
import { ClassSections } from "../core/entities/Master/ClassSections";
import { PromotionStatus } from "../core/entities/Exams/PromotionStatus";
import { StudentsAlumni } from "../core/entities/Alumni/StudentAlumni";
import { MarkRegisterArchieve } from "../core/entities/Archieve/MarkRegisterArchieve";
import { PromotionHistory } from "../core/entities/Exams/PromotionHistory";
import { InternalServerError, NotFound } from "../core/exceptions";
import { MarkRegisterService } from "./ExamMarkRegisterSvc";
import { IPromotionStatus } from "./interfaces/IPromotionStatus";
import { IPromotionLog } from "./interfaces/IPromotionLog";
import { AcadYear } from "../core/entities/Master/AcadYear";
import { IPromotionInput } from "./interfaces/IPromotionInput";
import { Attendance } from "../core/entities/Attendance/Attendance";
import { AttendanceArchieve } from "../core/entities/Archieve/AttendanceArchieve";
import { Exams } from "../core/entities/Exams/Exam";
import { IStudentArchieve } from "./interfaces/IStudentArchieve";
import { IStudent } from "../students/IStudent";
import { IParents } from "../students/IStudent";
import { IAddress } from "../students/IStudent";

// import { IStudentPromotion } from "./interfaces/IStudentPromotion";
// import { IMarkRegisterResult } from "./interfaces/IMarkRegisterResult";
// import { Exams } from "../core/entities/Exams/Exam";
// import { ExamGrades } from "../core/entities/Exams/Grades";

export class PromotionServiceBase {

	protected PR_LOG: IPromotionLog;
	protected PARAMS: IPromotionInput;

	constructor(params: IPromotionInput) {
		this.PR_LOG = {
			getexamname: "",
			ispromotetonewclass: false,
			noofstudentspromoted: "",

			updateacdyear: false,
			noofupdateacdyear: "",

			detainedstudents: "",
			noofdetained: "",

			addmarkstoarchieved: false,
			noofaddmarksarchieved: "",

			hasdeletedmarkregister: false,
			noofdelmarkregister: "",

			hasdeletedmarkregistersum: false,
			noofdelmarkregistersum: "",

			hasattendancearchieved: false,
			noofattendancearchieved: "",

			hasdeletedattendance: false,
			noofattendancedeleted: "",

			hasupdatepromotionstatus: false,

			hasupdatedtoalumni: false,
			noofalumni: ""
		};
		this.PARAMS = params;
	}

	protected async addToNewClass(queryRunner: EntityManager): Promise<boolean> {
		try {
			let blnResult: boolean = false;
			await queryRunner
				.getRepository(Students)
				.createQueryBuilder()
				.relation(Students, "classsec")
				.of(this.PARAMS.studentId)
				.addAndRemove(this.PARAMS.classIdTo, this.PARAMS.classIdFrom)
				.then((r) => {
					blnResult = true;
					this.PR_LOG.ispromotetonewclass = true;
					this.PR_LOG.noofstudentspromoted = this.PARAMS.studentId.length + "";
				});

			return blnResult;

		} catch (error) {
			throw new InternalServerError("addToNewClass: ", error);
		}
	}

	protected async updateAcadYear(queryRunner: EntityManager): Promise<boolean> {
		try {
			let blnResult: boolean = false;
			await queryRunner
				.createQueryBuilder()
				.update(Students)
				.set({
					acad_year: this.PARAMS.acadYearTo,
					updatedby: this.PARAMS.currentUser
				})
				.where("id IN (:id)", {
					id: this.PARAMS.studentId
				})
				.execute()
				.then((r) => {
					blnResult = true;
					this.PR_LOG.updateacdyear = true;
					this.PR_LOG.noofupdateacdyear = r.raw.affectedRows;
				});
			return blnResult;

		} catch (error) {
			throw new InternalServerError("addToNewClass: ", error);
		}
	}

	protected async updateDetainedStudents(queryRunner: EntityManager): Promise<boolean> {
		try {
			let blnResult: boolean = false;
			if (this.PARAMS.detainedStudentIds.length) {
				await queryRunner
					.createQueryBuilder()
					.update(Students)
					.set({
						acad_year: this.PARAMS.acadYearTo,
						updatedby: this.PARAMS.currentUser
					})
					.where("id IN (:ids)", {
						ids: this.PARAMS.detainedStudentIds
					})
					.execute()
					.then((r) => {
						this.PR_LOG.detainedstudents = this.PARAMS.detainedStudentIds.length ? "Yes" : "No";
						this.PR_LOG.noofdetained = r.raw.affectedRows;
					});
			} else {
				blnResult = true;
				this.PR_LOG.detainedstudents = "No";
				this.PR_LOG.noofdetained = "0";
			}
			return blnResult;

		} catch (error) {
			throw new InternalServerError("addToNewClass: ", error);
		}
	}

	protected async addMarksToArchieve(queryRunner: EntityManager): Promise<boolean> {
		try {
			let blnResult: boolean = false;

			let EXAM_NAME: string = "";
			const exam = await queryRunner
				.getRepository(Exams)
				.createQueryBuilder("exam")
				.where("is_final_exam = true")
				.getOne();
			EXAM_NAME = exam.name;
			this.PR_LOG.getexamname = EXAM_NAME;

			const reg_svc = new MarkRegisterService();
			await reg_svc.getClassMarkRegister(
				EXAM_NAME,
				this.PARAMS.classIdFrom,
				this.PARAMS.acadYearFrom)
				.then(async (r) => {

					const entity = r;
					const reformedData = entity.map(d => {
						return {
							acad_year: this.PARAMS.acadYearFrom,
							student_id: d.studentId,
							profile: JSON.parse(JSON.stringify(d.profile)),
							marks: JSON.parse(JSON.stringify(d.marks)),
							createdby: this.PARAMS.currentUser
						};
					});

					if (reformedData && reformedData.length > 0) {
						const res = await queryRunner
							.createQueryBuilder()
							.insert()
							.into(MarkRegisterArchieve)
							.values(
								reformedData
							).execute()
							.then((r) => {
								blnResult = true;
								this.PR_LOG.addmarkstoarchieved = true;
								this.PR_LOG.noofaddmarksarchieved = r.raw.affectedRows;
							})
							.catch((error) => {
								blnResult = false;
								throw new NotFound("Unable to save", error);
							});
					}
				});

			return blnResult;

		} catch (error) {
			throw new InternalServerError("addMarksToArchieve: ", error);
		}
	}

	protected async deleteMarkRegister(queryRunner: EntityManager): Promise<any> {
		try {

			let blnResult: boolean = false;
			await queryRunner
				.getRepository(MarkRegister)
				.createQueryBuilder("marks")
				.leftJoin("marks.exam_class_sub", "exams")
				.leftJoin("exams.class", "class")
				.where("class.id = :classId", { classId: this.PARAMS.classIdFrom })
				.getMany()
				.then(async (d) => {
					const ids = d.map(d => d.id);
					await queryRunner
						.createQueryBuilder()
						.delete()
						.from(MarkRegister)
						.where("id IN (:id)", { id: ids })
						.execute()
						.then((r) => {
							blnResult = true;
							this.PR_LOG.hasdeletedmarkregister = true;
							this.PR_LOG.noofdelmarkregister = r.raw.affectedRows;
						})
						.catch(() => {
							blnResult = false;
						});
				})
				.catch((e) => {
					blnResult = false;
				});

			return blnResult;
		} catch (error) {
			throw new InternalServerError("deleteMarkRegister Error: ", error);
		}
	}

	protected async deleteMarkRegisterSummary(queryRunner: EntityManager): Promise<any> {
		try {

			let blnResult: boolean = false;
			await queryRunner
				.getRepository(MarkRegisterSummary)
				.createQueryBuilder("marks")
				.leftJoin(ClassSections, "cls", "marks.class_id = cls.id")
				.where("marks.class_id = :classId", {
					classId: this.PARAMS.classIdFrom
				})
				.getMany()
				.then(async (d) => {
					const ids = d.map(d => d.id);
					await queryRunner
						.createQueryBuilder()
						.delete()
						.from(MarkRegisterSummary)
						.where("id IN (:id)", { id: ids })
						.execute()
						.then((r) => {
							blnResult = true;
							this.PR_LOG.hasdeletedmarkregistersum = true;
							this.PR_LOG.noofdelmarkregistersum = r.raw.affectedRows;
						})
						.catch(() => {
							blnResult = false;
						});
				})
				.catch((e) => {
					blnResult = false;
				});

			return blnResult;
		} catch (error) {
			throw new InternalServerError("deleteMarkRegisterSummary Error: ", error);
		}
	}

	protected async addAttendanceToArchieve(queryRunner: EntityManager): Promise<boolean> {
		try {
			let blnResult: boolean = false;

			const getTotalDaysInYear = await queryRunner
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.select("COUNT(DISTINCT a.attdate) as count")
				.where("a.classid = :classid", {
					classid: this.PARAMS.classIdFrom
				})
				.getRawOne();

			const totalDaysInYear = Number(getTotalDaysInYear.count);

			const calcualteAtt = await queryRunner
				.getRepository(Attendance)
				.createQueryBuilder("a")
				.select([
					"st.id AS student_id",
					`"${this.PARAMS.classIdFrom}" AS class_id`,
					`"${totalDaysInYear}" AS total_working_days`,
					"COUNT(*) AS days_absent",
					"(" + totalDaysInYear + " - COUNT(*)) AS days_present",
					"((" + totalDaysInYear + " - COUNT(*))/" + totalDaysInYear + ") * 100 AS perc"
				])
				.leftJoin("a.studentid", "st")
				.where("a.classid = :classid", {
					classid: this.PARAMS.classIdFrom
				})
				.andWhere("allpresent = false")
				.groupBy("st.id")
				.getRawMany()
				.then(async (d) => {
					const inValue = d.map(r => {
						return { ...r, createdby: this.PARAMS.currentUser };
					});

					if (inValue && inValue.length > 0) {
						const res = await queryRunner
							.createQueryBuilder()
							.insert()
							.into(AttendanceArchieve)
							.values(inValue).execute()
							.then((r) => {
								blnResult = true;
								this.PR_LOG.hasattendancearchieved = true;
								this.PR_LOG.noofattendancearchieved = r.raw.affectedRows;
							})
							.catch((error) => {
								blnResult = false;
								throw new NotFound("Unable to save", error);
							});
					}
				});

			blnResult = true;

			return blnResult;

		} catch (error) {
			throw new InternalServerError("addMarksToArchieve: ", error);
		}
	}

	protected async deleteAttendance(queryRunner: EntityManager): Promise<boolean> {
		try {
			let blnResult: boolean = false;

			await queryRunner
				.createQueryBuilder()
				.delete()
				.from(Attendance)
				.where("classid = :classId", { classId: this.PARAMS.classIdFrom })
				.execute()
				.then((r) => {
					blnResult = true;
					this.PR_LOG.hasdeletedattendance = true;
					this.PR_LOG.noofattendancedeleted = r.raw.affectedRows;
				})
				.catch((error) => {
					blnResult = false;
				});

			return blnResult;

		} catch (error) {
			throw new InternalServerError("addMarksToArchieve: ", error);
		}
	}

	protected async updatePromotionStatus(queryRunner: EntityManager): Promise<any> {
		try {
			let blnResult: boolean = false;

			const pStatus: IPromotionStatus = {
				status: "COMPLETED",
				class_id: this.PARAMS.classIdFrom,
				acad_year: this.PARAMS.acadYearFrom,
				school_id: "",
				createdby: this.PARAMS.currentUser
			};
			const entity = Object.assign(new PromotionStatus(), pStatus);
			entity.updatedby = this.PARAMS.currentUser;

			const res = await queryRunner
				.getRepository(PromotionStatus)
				.save(entity)
				.then((r) => {
					blnResult = true;
					this.PR_LOG.hasupdatepromotionstatus = true;
				})
				.catch((e) => {
					blnResult = false;
				});

			return blnResult;
		} catch (error) {
			throw new InternalServerError("updatePromotionStatus Error: ", error);
		}
	}

	protected async updatePromotionHistory(): Promise<any> {
		try {
			let blnResult: boolean = false;

			const pStatus = {
				class_id_from: this.PARAMS.classIdFrom,
				class_id_to: this.PARAMS.classIdTo,
				acad_year_from: this.PARAMS.acadYearFrom,
				acad_year_to: this.PARAMS.acadYearTo,
				school_id: "",
				createdby: this.PARAMS.currentUser
			};
			const logHistory = { ...this.PR_LOG, ...pStatus };
			const entity = Object.assign(new PromotionHistory(), logHistory);

			const res = await getManager()
				.getRepository(PromotionHistory)
				.save(entity)
				.then((r) => {
					blnResult = true;
				})
				.catch((e) => {
					blnResult = false;
				});

			return blnResult;
		} catch (error) {
			throw new InternalServerError("updatePromotionHistory Error: ", error);
		}
	}

	protected async addToAlumni(queryRunner: EntityManager): Promise<any> {
		try {
			let blnResult: boolean = false;
			const oArchieves: IStudentArchieve[] = [] as any;

			const oStudents = await queryRunner
				.getRepository(Students)
				.createQueryBuilder("stud")
				.leftJoinAndSelect("stud.parents", "parents")
				.leftJoinAndSelect("parents.address", "address")
				.leftJoinAndSelect("stud.classsec", "classsec")
				.where("stud.id IN (:value)", { value: this.PARAMS.studentId })
				.getMany();

			oStudents.map((d) => {
				const oSA: IStudentArchieve = {} as any;
				oSA.student_id = d.id;
				oSA.promoted_to = this.PARAMS.classIdTo;
				oSA.promote_reason = this.PARAMS.promoteReason;
				oSA.acadyear = d.acad_year;

				const profileD: IStudent = {
					id: d.id,
					studentno: d.studentno,
					prefixyear: d.prefixyear,
					aadhaarno: d.aadhaarno,
					emisno: d.emisno,
					udiseno: d.udiseno,
					firstname: d.firstname,
					lastname: d.lastname,
					gender: d.gender,
					dob: d.dob,
					doj: d.doj,
					nationality: d.nationality,
					religion: d.religion,
					castecategory: d.castecategory,
					community: d.community,
					mothertongue: d.mothertongue,
					bloodgroup: d.bloodgroup,
					identification: d.identification,
					isactive: d.isactive,
					disability: d.disability,
					notes: d.notes,
					parents: undefined
				};
				oSA.profile = profileD;

				d.parents.map((p) => {
					// const parentsD: IParents = {
					// 	id: p.id,
					// 	fathername: p.fathername,
					// 	fatherdob: p.fatherdob,
					// 	fathergraduation: p.fathergraduation,
					// 	fatheroccupation: p.fatheroccupation,
					// 	fathercompanyname: p.fathercompanyname,
					// 	fatherincome: p.fatherincome,
					// 	fatheraadhaarno: p.fatheraadhaarno,
					// 	mothername: p.mothername,
					// 	motherdob: p.motherdob,
					// 	mothergraduation: p.mothergraduation,
					// 	motheroccupation: p.motheroccupation,
					// 	mothercompanyname: p.mothercompanyname,
					// 	motherincome: p.motherincome,
					// 	motheraadhaarno: p.motheraadhaarno,
					// 	guardianname: p.guardianname,
					// 	guardianoccupation: p.guardianoccupation,
					// 	notes: p.notes,
					// 	address: p.address
					// };
					oSA.parents = p;
				});

				d.classsec.map((c) => {
					oSA.classsec = `${c.name} - ${c.section}`;
				});

				oSA.govtrte = undefined;
				oSA.school_id = undefined;
				oSA.user = undefined;
				oSA.createdby = this.PARAMS.currentUser;

				oArchieves.push(oSA);
			});

			const reformedData = JSON.parse(JSON.stringify(oArchieves));

			if (reformedData) {
				await queryRunner
					.createQueryBuilder()
					.insert()
					.into(StudentsAlumni)
					.values(reformedData).execute()
					.then((r) => {
						blnResult = true;
						this.PR_LOG.hasupdatedtoalumni = true;
						this.PR_LOG.noofalumni = r.raw.affectedRows;
					})
					.catch((error) => {
						blnResult = false;
						throw new InternalServerError("Unable to save", error);
					});
			}

			return blnResult;
		} catch (error) {
			throw new InternalServerError("addToAlumni Error: ", error);
		}
	}

	protected async addToTC(queryRunner: EntityManager): Promise<any> {
		try {
			let blnResult: boolean = false;



			blnResult = true;
			return blnResult;
		} catch (error) {
			throw new InternalServerError("deleteAllMedia Error: ", error);
		}
	}

	protected async deleteAllMedia(queryRunner: EntityManager): Promise<any> {
		try {
			let blnResult: boolean = false;
			blnResult = true;
			return blnResult;
		} catch (error) {
			throw new InternalServerError("deleteAllMedia Error: ", error);
		}
	}

	public async getPromotionHistory(
		classId: string,
		acadyear: string): Promise<any> {
		try {
			const qb = getManager()
				.getRepository(PromotionHistory)
				.createQueryBuilder("h")
				.select([
					"h.*",
					"clsF.name AS classFrom",
					"clsT.name AS classTo",
					"aF.displayname AS acadFrom",
					"aT.displayname AS acadTo",
				])
				.leftJoin(ClassSections, "clsF", "h.class_id_from = clsF.id")
				.leftJoin(ClassSections, "clsT", "h.class_id_To = clsT.id")
				.leftJoin(AcadYear, "aF", "h.acad_year_from = aF.id")
				.leftJoin(AcadYear, "aT", "h.acad_year_to = aT.id");

			if (classId) {
				qb.where("h.class_id_from = :classId", { classId: classId });
			}
			if (acadyear) {
				qb.andWhere("h.acad_year_from = :acad_year", { acad_year: acadyear });
			}

			const res = await qb.getRawMany();

			return res;
		} catch (error) {
			throw new InternalServerError("getPromotionHistory Error: ", error);
		}
	}
}