import express from "express";
// import bodyParser from "body-parser";
import { ApolloServer, AuthenticationError } from "apollo-server-express";
import cors from "cors";
import { createServer } from "http";
import { createConnection } from "typeorm";
import { injectable, inject } from "inversify";

import { AbstractSetting } from "./core/config/AbstractSetting";
import { AbstractLogger } from "./core/logger/AbstractLogger";
// import schema from "./core/config/Schema";
import schema from "./resolvers";
import { IAppContext } from "./context";
import { getContext } from "./context";

import { TYPES } from "./core/config/InversifyTypes";
import { GraphQLError } from "graphql";
// import { AuthService } from "./common/AuthService";
import { NotFound, Unauthorized } from "./core/exceptions";
// import Database from "./core/repository/Database";
import { IUser } from "./users/IUser";


import path from "path";

@injectable()
export class Server {
	private app: express.Express;
	private apolloServer: ApolloServer;
	private port: number;

	constructor(
		@inject(TYPES.Logger) private logger: AbstractLogger,
		@inject(TYPES.Setting) private setting: AbstractSetting
	) { }

	public startServer() {
		try {
			this.logger.info("🚀 Starting API server...");
			this.port = parseInt(this.setting.config.server.port, 10);
			this.logger.info(`Running on PORT : ${this.port}`);

			createConnection({
				type: "mysql",
				host: this.setting.config.database.host,
				port: this.setting.config.database.port,
				synchronize: this.setting.config.database.synchronize,
				logging: this.setting.config.database.logging,
				dropSchema: this.setting.config.database.dropSchema,

				username: this.setting.config.database.username,
				password: this.setting.config.database.password,
				database: this.setting.config.database.databasename,

				// entities: [__dirname + "/core/entities/Master/*{.ts,.js}"]

				entities: [__dirname + "/core/entities/**/*{.ts,.js}"]
			})
				.then(() => {
					this.logger.info(`Successfully connected to database. ${this.setting.config.database.host}`);

					this.app = express().use("*", cors());

					try {
						const context: IAppContext = getContext();
						this.initServer(context);
					} catch (error) {
						this.logger.error(`Failure to connect to HTTP Server: ${error}`);
					}
				})
				.catch((error) => {
					console.log(error);
					const { code, sqlMessage } = error;
					if (code === "PROTOCOL_CONNECTION_LOST") {
						setTimeout(this.startServer, 2000);
					}
					this.logger.error(
						`Failure to connect to database: ${error} ${sqlMessage}`
					);
				});
		} catch (error) {
			this.logger.info(`Error on start API server...${error}`);
		}

	}

	private async initServer(contextAPI: IAppContext) {
		this.apolloServer = new ApolloServer({
			schema,
			context: async ({ req }) => {

				try {
					const userInfo = await contextAPI.AuthService.getAuthUser(req);

					if (!userInfo || userInfo.UserType === "" || userInfo.UserType === undefined) {
						throw new AuthenticationError("UserType is empty. You must be logged in!");
					}

					contextAPI.CurrentUser = Object.assign({}, userInfo);
					contextAPI.ReqUserAgent = req.headers["user-agent"];
					const contexts = Object.assign({}, contextAPI);

					// this.app.get("/download", async function (req, res) {
					// 	return await contexts.UploadService.downloadFile(req, res);
					// });

					return contexts;
				} catch (error) {
					throw new AuthenticationError(`initServer Err: You must be logged in! ${error}`);
				}
			},
			formatError: error => {
				this.logger.error(`Error: ${error.message} - Trace: ${error}`);
				return new GraphQLError(error.message);
				// Or, you can delete the exception information
				// delete error.extensions.exception;
				// return error;
			}
		});
		this.apolloServer.applyMiddleware({ app: this.app });

		const httpServer = createServer(this.app);
		this.apolloServer.installSubscriptionHandlers(httpServer);

		// console.log(path.join(__dirname, "../upload_folder"));

		this.app.use("/downloads", express.static(path.join(__dirname, "../upload_folder")));
		// this.app.get("/download", async function (req, res) {
		// 	return await contextAPI.UploadService.downloadFile(req, res);
		// });

		httpServer.listen({ port: this.port }, () => {
			this.logger.info(
				`🔥 Server is ready at http://localhost:${this.port}${
				this.apolloServer.graphqlPath
				}`
			);
			this.logger.info(
				`🔥 Playground is ready at http://localhost:${this.port}${
				this.apolloServer.graphqlPath
				}`
			);
			this.logger.info(
				`🔥 Subscriptions is ready at ws://localhost:${this.port}${
				this.apolloServer.subscriptionsPath
				}`
			);
		});
	}
}
