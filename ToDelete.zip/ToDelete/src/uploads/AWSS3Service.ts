import * as aws from "aws-sdk";
import shortid from "shortid";
import { getManager } from "typeorm";
import { DocsPhotos } from "../core/entities/DocsPhotos/DocsPhotos";
import { Staff } from "../core/entities/Staff/Staff";
import { IDocsPhotos } from "./IUpload";
import { NotFound, InternalServerError } from "../core/exceptions";
import { IStaff } from "../staff/IStaff";
import { Students } from "../core/entities/Students/Student";

export class AWSS3Service {
	private dbInData: IDocsPhotos;
	private uploadUser: string;
	private _filePath: string;
	private _bucket: string;
	// private _endPoint: string;
	private _region: string;
	private _accessKeyId: string;
	private _secretAccessKey: string;

	constructor() {
		// const endPoint = process.env.SPACES_END_POINT;
		const region = process.env.AWS_REGION;
		const bucket = process.env.AWS_BUCKET;
		const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
		const secretAccessKey = process.env.AWS_ACCESS_KEY;

		// this._endPoint = endPoint;
		this._region = region;
		this._bucket = bucket;
		this._accessKeyId = accessKeyId;
		this._secretAccessKey = secretAccessKey;
	}

	public async uploadFile(oFile: any,
		filePath: string,
		inData: IDocsPhotos,
		currentUser: string): Promise<any> {
		try {
			this.dbInData = inData;
			this.uploadUser = currentUser;
			this._filePath = filePath;

			let fileStatus = "ERROR";

			aws.config.update({
				region: this._region,
				accessKeyId: this._accessKeyId,
				secretAccessKey: this._secretAccessKey
			});

			const s3 = new aws.S3();

			const { createReadStream, filename, mimetype } = await oFile;
			const crStream = createReadStream();
			const ext = filename.substr(filename.lastIndexOf(".") + 1);
			const id = shortid.generate();

			const params = {
				Body: crStream,
				Bucket: this._bucket,
				Key: `${filePath}/${id}.${ext}`,
				ACL: "public-read"
			};

			const uploadRes = () => {
				return s3.upload(params).promise();
			};

			const result = (await uploadRes()
				.then(async (res) => {
					if (res.ETag) {
						const saveRes = await this.saveDB(id, ext);
						fileStatus = "Uploaded successfully";
						return { Messages: fileStatus };
					} else {
						fileStatus = "No Files Uploaded";
						return { Messages: fileStatus };
					}
				})
				.catch(error => {
					console.log(error);
					return { Messages: fileStatus };
				}));

		} catch (error) {
			console.log(error);
		}
	}

	public async deleteFile(id: string, docs: IDocsPhotos, filePath: string) {
		try {
			let fileStatus = "ERROR";

			aws.config.update({
				region: this._region,
				accessKeyId: this._accessKeyId,
				secretAccessKey: this._secretAccessKey
			});

			const s3 = new aws.S3();

			const params = {
				Bucket: this._bucket,
				Key: `${filePath}/${docs.docid}`,
			};

			const delRes = () => {
				return s3.deleteObject(params).promise();
			};

			const delResult = (await delRes()).$response;

			if (delResult.error) {
				console.log(delResult.error);
				fileStatus = "No Files Deleted";
				return { Messages: fileStatus };
			} else {
				if (this.delDocsDB(id)) {
					fileStatus = "Deleted successfully";
				} else {
					fileStatus = "No Records Deleted";
				}
				return { Messages: fileStatus };
			}

		} catch (error) {
			console.log(error);
		}
	}

	private async saveDB(id: any, ext: string): Promise<any> {
		try {
			const dbIn = this.dbInData;
			const fileName = `${id}.${ext}`;
			const photoPath = `https://${this._bucket}.${"s3"}.${this._region}.${"amazonaws.com"}/${this._filePath}/${fileName}`;

			const entity = Object.assign(new DocsPhotos(), dbIn);
			entity.docid = `${id}.${ext}`;
			entity.createdby = this.uploadUser;
			entity.mediaurl = photoPath;

			if (entity.doctype === "PHOTOS") {
				this.updatePhotoURL(photoPath);

				const getPhotosEntity = await this.findDocsPhotos(entity);
				if (getPhotosEntity && getPhotosEntity.id) {
					const upRes = await getManager()
						.getRepository(DocsPhotos)
						.update(getPhotosEntity.id, entity)
						.catch(err => {
							throw new InternalServerError("saveDB:getPhotosEntity Error");
						});
				}
			} else {
				const saveRes = await getManager()
					.getRepository(DocsPhotos)
					.save(entity);
			}
			return true;

		} catch (error) {
			throw new NotFound(`SaveDB Error. Please change the search criteria`);
		}
	}

	private async updatePhotoURL(photoPath: string): Promise<any> {
		try {
			const dbIn = this.dbInData;
			const entity = new Staff();
			entity.updatedby = this.uploadUser;

			if (dbIn.modulename === "STAFF") {
				const staffEntity = {
					id: dbIn.staff,
					photo: photoPath
				};
				const profileUpd = await getManager()
					.getRepository(Staff)
					.update(dbIn.staff, staffEntity)
					.catch(error => {
						throw new NotFound(`Staff data not saved ${error}`);
					});
			}
			else if (dbIn.modulename === "STUDENT") {
				const studentEntity = {
					id: dbIn.student,
					photo: photoPath
				};
				const profileUpd = await getManager()
					.getRepository(Students)
					.update(dbIn.student, studentEntity)
					.catch(error => {
						throw new NotFound(`Student data not saved ${error}`);
					});
			}
			return true;

		} catch (error) {
			throw new NotFound(`SaveDB Error. Please change the search criteria`);
		}
	}

	private async findDocsPhotos(entity: IDocsPhotos | DocsPhotos) {
		try {
			const res = getManager()
				.getRepository(DocsPhotos)
				.createQueryBuilder("d")
				.where("d.name = :name")
				.andWhere("d.modulename = :modulename")
				.andWhere("d.doctype = :doctype");
			if (entity.modulename === "STAFF") {
				res.andWhere("d.staff = :staff")
					.setParameter("staff", entity.staff);
			}
			if (entity.modulename === "STUDENT") {
				res.andWhere("d.student = :student")
					.setParameter("student", entity.student);
			}
			const result = res.setParameter("name", entity.name)
				.setParameter("modulename", entity.modulename)
				.setParameter("doctype", entity.doctype)
				.getOne();
			return await result;
		} catch (error) {
			throw new NotFound(`addUpdateDocsPhotos Error. Please change the search criteria`);
		}
	}

	private async delDocsDB(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(DocsPhotos)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return true;
			} else {
				return false;
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}