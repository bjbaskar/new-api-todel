import { injectable } from "inversify";
import { getManager, getConnection, In, QueryRunner, EntityManager } from "typeorm";
import shortid from "shortid";
import { IDocsPhotos } from "./IUpload";
import { BadRequest, BadMapping, InternalServerError, NotFound } from "../core/exceptions";

import _ from "lodash";
import mkdirp from "mkdirp";
import fs, { createWriteStream, unlink } from "fs";
import path from "path";
import { DocsPhotos } from "../core/entities/DocsPhotos/DocsPhotos";

import { UploadS3Service } from "./UploadS3Service";
import { AWSS3Service } from "./AWSS3Service";
import { stringType } from "aws-sdk/clients/iam";

@injectable()
export class UploadService {
	private dbInData: IDocsPhotos;
	private uploadUser: string;
	constructor() { }

	/**
	 * Upload File or Photo to S3 spaces
	 * @param oFile
	 * @param inData
	 * @param photopath
	 * @param currentUser
	 */
	public async uploadFile(oFile: any, inData: IDocsPhotos, filePath: string, currentUser: string): Promise<any> {
		try {
			this.dbInData = inData;
			this.uploadUser = currentUser;
			const uploadInSpace = new AWSS3Service();

			const result = await uploadInSpace.uploadFile(oFile, filePath, inData, currentUser);
			return result;

		} catch (error) {
			console.log(error);
			return error;
		}
	}

	/**
	 * Not in use
	 */
	public async uploadPhoto_OLD(oFile: any, inData: IDocsPhotos, photopath: string, currentUser: string): Promise<any> {
		try {
			this.dbInData = inData;
			this.uploadUser = currentUser;
			await mkdirp.sync(photopath);
			const res = await this.processUpload(oFile, photopath);

			if (res) {
				return { Messages: "Uploaded successfully" };
			} else {
				return { Messages: "No Files Uploaded" };
			}
		} catch (error) {
			console.log(error);
			return error;
		}
	}

	private async processUpload(upload: any, photopath: string): Promise<any> {
		const { createReadStream, filename, mimetype } = await upload;
		const crStream = createReadStream();
		const { id, ext, path } = await this.saveFS(crStream, filename, photopath);
		const res = await this.saveDB(id, ext);
		return res;
	}

	private saveFS(crStream: any, filename: string, photopath: string): Promise<any> {
		const id = shortid.generate();
		const ext = filename.substr(filename.lastIndexOf(".") + 1);
		// const path = `${photopath}/${id}.${ext}`;

		let savePath = `../../${photopath}/${id}.${ext}`;
		savePath = path.join(__dirname, savePath);

		return new Promise((resolve, reject) => {
			const writeStream = createWriteStream(savePath);
			writeStream.on("finish", () => resolve({ id, ext, path }));

			writeStream.on("error", (error) => {
				unlink(savePath, () => {
					reject(error);
				});
			});

			crStream.on("error", (error: any) => writeStream.destroy(error));
			crStream.pipe(writeStream);
		});
	}

	private async saveDB(id: any, ext: string): Promise<any> {
		try {
			const dbIn = this.dbInData;
			const entity = Object.assign(new DocsPhotos(), dbIn);
			entity.docid = `${id}.${ext}`;
			entity.createdby = this.uploadUser;

			const res = await getManager()
				.getRepository(DocsPhotos)
				.save(entity);
			return res;

		} catch (error) {
			throw new NotFound(`SaveDB Error. Please change the search criteria`);
		}
	}

	public async getDocuments(id: string, searchfor: string): Promise<any> {
		try {
			const query = getManager()
				.getRepository(DocsPhotos)
				.createQueryBuilder("docs")
				.where("docs.doctype = :value", { value: "DOCS" });
			if (searchfor === "STAFF") {
				query.andWhere("docs.staff = :staffId", { staffId: id });
			}
			if (searchfor === "STUDENT") {
				query.andWhere("docs.student = :studentId", { studentId: id });
			}
			const res = await query.getMany();
			return res;
		} catch (error) {
			throw new NotFound(`Documents not found. Please change the search criteria`);
		}
	}

	public async delDocuments(id: string, docs: IDocsPhotos, filePath: string): Promise<any> {
		try {
			const delS3 = new UploadS3Service();
			return await delS3.deleteFile(id, docs, filePath);
		} catch (error) {
			throw new NotFound(`Documents not found. Please change the search criteria`);
		}
	}

	public async delDocuments_OLD(id: string, docs: IDocsPhotos, photopath: string): Promise<any> {
		try {
			let delPath = `../../${photopath}/${docs.docid}`;
			delPath = path.join(__dirname, delPath);

			const promiseObj = new Promise((resolve, reject) => {
				fs.unlink(delPath, async function (err) {
					if (err) {
						reject(err);
					}
					// resolve();
				});
			});
			promiseObj.then(res => {
				return this.delDocsDB(id);
			}).catch(err => {
				return new NotFound(`Documents not found. ${err}`);
			});
		} catch (error) {
			throw new NotFound(`Documents not found. Please change the search criteria`);
		}
	}

	private async delDocsDB(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(DocsPhotos)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async downloadFile(req: any, res: any): Promise<any> {
		try {
			const p = path.join(__dirname, "../../");
			const file = `${p}upload_folder/87O7yzuEZ.jpg`;

			// const buffer = new Buffer(file.toString(), "binary").toString("base64");
			// const data = "data:image/jpeg" + ";base64," + buffer;
			// res.writeHead(200, {
			// 	"Content-Type": "image/jpeg",
			// 	"Content-Length": buffer.length
			// });
			// res.end(data);

			const s = fs.createReadStream(file);
			s.on("open", function () {
				res.set("Content-Type", "image/jpeg");
				s.pipe(res);
			});
			s.on("error", function (err) {
				console.log(err);
				res.set("Content-Type", "text/plain");
				res.status(404).end("Not found");
			});

		} catch (error) {
			console.log(error);

		}
	}

	public async downloadFile1(docs: IDocsPhotos, photopath: string): Promise<any> {
		try {
			// https://gist.github.com/eveporcello/12c0f5070fd1c0bc3d9f02906f7743a8
			return new Promise((resolve, reject) => {
				let filePath = `../../${photopath}/${docs.docid}`;
				filePath = path.join(__dirname, filePath);
				const res = this.base64_encode(filePath);

				return resolve({
					name: docs.name,
					docid: docs.docid,
					file: res
				});


			});

		} catch (error) {
			throw new InternalServerError("Download Error", error);
		}
		// 	function base64ToArrayBuffer(base64) {
		// 		var binaryString =  window.atob(base64);
		// 		var binaryLen = binaryString.length;
		// 		var bytes = new Uint8Array(binaryLen);
		// 		for (var i = 0; i < binaryLen; i++)        {
		// 			 var ascii = binaryString.charCodeAt(i);
		// 			 bytes[i] = ascii;
		// 		}
		// 		return bytes;
		//   }

		//   var saveByteArray = (function () {
		// 		var a = document.createElement("a");
		// 		document.body.appendChild(a);
		// 		a.style = "display: none";
		// 		return function (data, name) {
		// 			 var blob = new Blob(data, {type: "octet/stream"}),
		// 				  url = window.URL.createObjectURL(blob);
		// 			 a.href = url;
		// 			 a.download = name;
		// 			 a.click();
		// 			 window.URL.revokeObjectURL(url);
		// 		};
		//   }());


		//   var sampleBytes = base64ToArrayBuffer('R0lGODlhAQABAIAAAAUEBAAAACwAAAAAAQABAAACAkQBADs');
		//   saveByteArray([sampleBytes], 'black1x1.gif');
	}

	private async base64ToArrayBuffer(base64: any) {
		const binaryString = window.atob(base64);
		const binaryLen = binaryString.length;
		const bytes = new Uint8Array(binaryLen);
		for (let i = 0; i < binaryLen; i++) {
			const ascii = binaryString.charCodeAt(i);
			bytes[i] = ascii;
		}
		return bytes;
	}

	private async base64_encode(file: string): Promise<any> {
		// read binary data
		const bitmap = fs.readFileSync(file);
		// convert binary data to base64 encoded string
		return new Buffer(bitmap).toString("base64");
	}

}