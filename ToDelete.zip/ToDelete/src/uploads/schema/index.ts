import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const uploadTypeDef = typeDef;
const uploadResolver = resolvers;

export { uploadTypeDef, uploadResolver };
