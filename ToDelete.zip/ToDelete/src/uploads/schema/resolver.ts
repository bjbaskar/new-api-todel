import { IAppContext } from "../../context";
import { IDocsPhotos } from "../IUpload";

export const resolvers = {
	Query: {
		getDocuments: async (_: any, args: {
			id: string,
			searchfor: string
		}, context: IAppContext) => {
			return await context.UploadService.getDocuments(args.id, args.searchfor);
		},
		downloadFile: async (_: any, args: any, context: IAppContext) => {
			// var files = fs.createReadStream("demo.pdf");
			// res.writeHead(200, {'Content-disposition': 'attachment; filename=demo.pdf'}); //here you can add more headers
			// files.pipe(res)
			const moduleName = args.input.modulename;
			const docType = args.input.doctype;

			let photopath = context.Setting.config.upload.schooldocspath;

			if (moduleName === "SCHOOL" && docType === "DOCS") {
				photopath = context.Setting.config.upload.schooldocspath;
			}
			if (moduleName === "SCHOOL" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.schoolphotopath;
			}

			if (moduleName === "STAFF" && docType === "DOCS") {
				photopath = context.Setting.config.upload.staffdocspath;
			}
			if (moduleName === "STAFF" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.staffphotopath;
			}

			if (moduleName === "STUDENT" && docType === "DOCS") {
				photopath = context.Setting.config.upload.studentdocspath;
			}
			if (moduleName === "STUDENT" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.schoolphotopath;
			}
			const res = await context.UploadService.downloadFile(args.input, photopath);
			return res;
		}

	},
	Mutation: {
		uploadSingleFile: async (root: any, args: any, context: IAppContext) => {
			const currentUser = context.CurrentUser.UserName;
			// const { stream, filename, mimetype, encoding } = await args.file;

			const oFile = await args.input.file;
			const inData = args.input as IDocsPhotos;
			const moduleName = inData.modulename;
			const docType = inData.doctype;
			inData.file = undefined;

			let photopath = context.Setting.config.upload.schooldocspath;

			if (moduleName === "SCHOOL" && docType === "DOCS") {
				photopath = context.Setting.config.upload.schooldocspath;
			}
			if (moduleName === "SCHOOL" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.schoolphotopath;
			}

			if (moduleName === "STAFF" && docType === "DOCS") {
				photopath = context.Setting.config.upload.staffdocspath;
			}
			if (moduleName === "STAFF" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.staffphotopath;
			}

			if (moduleName === "STUDENT" && docType === "DOCS") {
				photopath = context.Setting.config.upload.studentdocspath;
			}
			if (moduleName === "STUDENT" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.studentphotopath;
			}

			if (moduleName === "ASGN" && docType === "DOCS") {
				photopath = context.Setting.config.upload.asgndocspath;
			}
			if (moduleName === "ASGN" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.asgnphotopath;
			}

			const res = await context.UploadService.uploadFile(oFile, inData, photopath, currentUser);
			return res;
			// Now use stream to either write file at local disk or CDN

			// return { filename, mimetype, encoding };
		},
		delDocuments: async (
			root: any,
			args: any,
			context: IAppContext
		) => {
			const moduleName = args.input.modulename;
			const docType = args.input.doctype;

			let photopath = context.Setting.config.upload.schooldocspath;

			if (moduleName === "SCHOOL" && docType === "DOCS") {
				photopath = context.Setting.config.upload.schooldocspath;
			}
			if (moduleName === "SCHOOL" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.schoolphotopath;
			}

			if (moduleName === "STAFF" && docType === "DOCS") {
				photopath = context.Setting.config.upload.staffdocspath;
			}
			if (moduleName === "STAFF" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.staffphotopath;
			}

			if (moduleName === "STUDENT" && docType === "DOCS") {
				photopath = context.Setting.config.upload.studentdocspath;
			}
			if (moduleName === "STUDENT" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.studentphotopath;
			}

			if (moduleName === "ASGN" && docType === "DOCS") {
				photopath = context.Setting.config.upload.asgndocspath;
			}
			if (moduleName === "ASGN" && docType === "PHOTOS") {
				photopath = context.Setting.config.upload.asgnphotopath;
			}

			const res = await context.UploadService.delDocuments(args.id, args.input, photopath);
			return res;
		}
	}
};