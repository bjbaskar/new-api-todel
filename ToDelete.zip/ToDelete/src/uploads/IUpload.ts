
export interface IDocsPhotos {
	id: string;
	file: any;
	name: string;
	modulename: string;
	doctype: string;
	docid: string;
	filesize: string;
	filetype: string;
	mediaurl: string;
	staff?: string;
	student?: string;
	school?: string;
	assignment?: string;
}

// path: string;
// filename: string;
// 	mimetype: string;
// 	encoding: string;
// 	stream: any;

