export interface IBaseModel {
	createdby: number;
	createdon: Date;
	updatedby: number;
	updatedon: Date;
	// notes: string;
}
