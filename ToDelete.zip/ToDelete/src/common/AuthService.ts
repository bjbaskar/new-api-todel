import jwt from "jsonwebtoken";
import { getManager } from "typeorm";
import { injectable, inject } from "inversify";

import { TYPES } from "../core/config/InversifyTypes";
import { AbstractSetting } from "../core/config/AbstractSetting";
import { IUser, TokenData, DataStoredInToken, ICurrentUser } from "../users/IUser";
import { Users } from "../core/entities/Users/Users";
import { Unauthorized } from "../core/exceptions";
import { IRole } from "../userroles/IRole";

@injectable()
export class AuthService {
	constructor(@inject(TYPES.Setting) private setting: AbstractSetting) { }

	public getAuthUser = async (req: any): Promise<ICurrentUser> => {
		const token = req.headers["authorization"] || "";
		const secret = this.setting.config.server.jwt_secret;

		let userType = "";
		let userFound = undefined;

		if (token) {
			try {
				if (token === "LOGIN") {
					const currentUser: ICurrentUser = {
						UserId: undefined,
						UserName: undefined,
						UserType: "LOGIN",
						Student: undefined,
						Staff: undefined,
						Roles: undefined
					};
					return currentUser;
				}

				const tokenValue = token.replace("Bearer ", "");
				const verificationRes = (await jwt.verify(
					tokenValue,
					secret
				)) as DataStoredInToken;

				// const id = verificationRes.id;
				const userName = verificationRes.username;
				// const usertype = verificationRes.usertype;

				const checkUser = await getManager()
					.getRepository(Users)
					.findOne({ where: { username: userName } });

				if (checkUser) {
					userType = checkUser.usertype;
					if (userType.toUpperCase() === "STUDENT") {
						userFound = await getManager()
							.getRepository(Users)
							.createQueryBuilder("user")
							.leftJoinAndSelect("user.students", "students")
							.leftJoinAndSelect("user.roles", "roles")
							.leftJoinAndSelect("roles.permissions", "permissions")
							.where("user.username = :username", { username: userName })
							.andWhere("user.isactive = true")
							.getOne();
					}
					else {
						userFound = await getManager()
							.getRepository(Users)
							.createQueryBuilder("user")
							.leftJoinAndSelect("user.staff", "staff")
							.leftJoinAndSelect("user.roles", "roles")
							.leftJoinAndSelect("roles.permissions", "permissions")
							.where("user.username = :username", { username: userName })
							.andWhere("user.isactive = true")
							.getOne();
					}
				}

				if (!userFound) {
					throw new Unauthorized(`User not found`);
				}

				const currentUser: ICurrentUser = {
					UserId: userFound.id,
					UserName: userFound.username,
					UserType: userFound.usertype,
					Student: userFound.students,
					Staff: userFound.staff,
					Roles: Object.assign([], userFound.roles)
				};

				return currentUser;
			} catch (error) {
				throw new Unauthorized(`Your session expired. Sign in again. ${error}`);
			}
		} else {
			throw new Unauthorized(`User token not found.`);
		}
	};

	public getAuthorize = (Roles: Array<IRole>, moduleName: string, title: string, key: string) => {
		let verifyPerm = false;
		Roles.map(async p => {
			return p.permissions.filter(pp => {
				if (pp.module === moduleName &&
					pp.title === title &&
					pp.key === key) {
					verifyPerm = true;
				}
			});
		});
		return verifyPerm;
	}

}