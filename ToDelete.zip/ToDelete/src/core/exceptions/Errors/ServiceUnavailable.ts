import { Exception } from "../Exceptions";

export class ServiceUnavailable extends Exception {
	static readonly STATUS = 503;
	name: string = "SERVICE_UNVAILABLE";

	constructor(message: string, origin?: Error | string | any) {
		super(ServiceUnavailable.STATUS, message, origin);
	}
}
