import { injectable, inject } from "inversify";
@injectable()
export abstract class AbstractSetting {
	public abstract get config(): IConfig;
}

export interface IConfig {
	server: IServerConfig;
	log: ILoggerConfig;
	database: IDatabaseConfig;
	upload: IUploadConfig;
}

interface IServerConfig {
	port: string;
	max_login_attempts: number;
	lock_time: number;
	jwt_secret: string;
	token_expires_in: number;
}

interface ILoggerConfig {
	filename: string;
	filedir: string;
}

interface IDatabaseConfig {
	host: string;
	port: number;
	synchronize: boolean;
	logging: boolean;
	dropSchema: boolean;

	username: string;
	password: string;
	databasename: string;
}

interface IUploadConfig {
	schoolphotopath: string;
	schooldocspath: string;
	staffphotopath: string;
	staffdocspath: string;
	studentphotopath: string;
	studentdocspath: string;
	asgnphotopath: string;
	asgndocspath: string;
}