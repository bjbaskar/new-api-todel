const TYPES = {
	Server: Symbol.for("Server"),
	Setting: Symbol.for("Setting"),
	Logger: Symbol.for("Logger"),
	UserService: Symbol.for("UserService"),
	UserRoleService: Symbol.for("UserRoleService"),
	AuthService: Symbol.for("AuthService"),

	StudentService: Symbol.for("StudentService"),
	StaffService: Symbol.for("StaffService"),

	SchoolProfileService: Symbol.for("SchoolProfileService"),
	AcadYearService: Symbol.for("AcadYearService"),
	EduSystemService: Symbol.for("EduSystemService"),
	SubjectService: Symbol.for("SubjectService"),
	ClassService: Symbol.for("ClassService"),
	TextBookService: Symbol.for("TextBookService"),
	DataConfigService: Symbol.for("DataConfigService"),
	HolidayService: Symbol.for("HolidayService"),
	CalendarService: Symbol.for("CalendarService"),

	UploadService: Symbol.for("UploadService"),

	DashboardService: Symbol.for("DashboardService"),
	AttendanceService: Symbol.for("AttendanceService"),
	AssignmentService: Symbol.for("AssignmentService"),

	ExamService: Symbol.for("ExamService"),

	FeedbackService: Symbol.for("FeedbackService"),

	FeeParticularService: Symbol.for("FeeParticularService"),
	FeeInstallmentService: Symbol.for("FeeInstallmentService"),
	FeeMasterService: Symbol.for("FeeMasterService"),
	FeeStudentConfigService: Symbol.for("FeeStudentConfigService"),
	FeeTransactionService: Symbol.for("FeeTransactionService"),
	FeeDiscountService: Symbol.for("FeeDiscountService"),

};

export { TYPES }; // SERVICE_IDENTIFIER
