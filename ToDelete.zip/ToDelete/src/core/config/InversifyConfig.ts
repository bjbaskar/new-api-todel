import "reflect-metadata";
import { Container } from "inversify";
import { TYPES } from "./InversifyTypes";
import { Server } from "../../server";
import { AbstractSetting } from "./AbstractSetting";
import { Setting } from "./Setting";
import { AbstractLogger } from "../logger/AbstractLogger";
import { Logger } from "../logger/Logger";
import { UserService } from "../../users/UserService";
import { UserRoleService } from "../../userroles/UserRoleService";
import { AuthService } from "../../common/AuthService";

import { DataConfigService } from "../../master/dataconfig/DataConfigService";

import { StudentService } from "../../students/StudentService";

import { SchoolProfileService } from "../../master/schoolprofile/SchoolProfileService";
import { AcadYearService } from "../../master/academicyear/AcadYearService";
import { EduSystemService } from "../../master/edusystems/EduSystemService";
import { SubjectService } from "../../master/subjects/SubjectService";
import { ClassService } from "../../master/classsec/ClassService";
import { TextBookService } from "../../master/textbooks/TextBookService";
import { HolidayService } from "../../master/holidays/HolidayService";
import { CalendarService } from "../../master/calendar/CalendarService";

import { StaffService } from "../../staff/StaffService";

import { UploadService } from "../../uploads/UploadService";

import { DashboardService } from "../../dashboard/DashboardService";
import { AttendanceService } from "../../attendance/AttendanceService";
import { AssignmentService } from "../../assignment/AssignmentService";

import { ExamService } from "../../exams/ExamService";

import { FeedbackService } from "../../feedback/FeedbackService";
import { FeeParticularService } from "../../fee/feeparticulars/FeeParticularService";
import { FeeInstallmentService } from "../../fee/feeinstallments/FeeInstallmentService";
import { FeeMasterService } from "../../fee/feemaster/FeeMasterService";
import { FeeStudentConfigService } from "../../fee/feestudentconfig/FeeStudentConfigSvc";
import { FeeTransactionService } from "../../fee/feetransaction/FeeTransactionSvc";
import { FeeDiscountService } from "../../fee/feediscount/FeeDiscountSvc";

const ContainerMain = new Container();
ContainerMain.bind<Server>(TYPES.Server).to(Server);

ContainerMain.bind<AbstractSetting>(TYPES.Setting).to(Setting);
ContainerMain.bind<AbstractLogger>(TYPES.Logger).to(Logger);

ContainerMain.bind<AuthService>(TYPES.AuthService).to(AuthService);

ContainerMain.bind<UserService>(TYPES.UserService).to(UserService);
ContainerMain.bind<UserRoleService>(TYPES.UserRoleService).to(UserRoleService);

ContainerMain.bind<SchoolProfileService>(TYPES.SchoolProfileService).to(SchoolProfileService);
ContainerMain.bind<AcadYearService>(TYPES.AcadYearService).to(AcadYearService);
ContainerMain.bind<EduSystemService>(TYPES.EduSystemService).to(EduSystemService);
ContainerMain.bind<SubjectService>(TYPES.SubjectService).to(SubjectService);
ContainerMain.bind<ClassService>(TYPES.ClassService).to(ClassService);
ContainerMain.bind<TextBookService>(TYPES.TextBookService).to(TextBookService);
ContainerMain.bind<DataConfigService>(TYPES.DataConfigService).to(
	DataConfigService
);
ContainerMain.bind<HolidayService>(TYPES.HolidayService).to(HolidayService);
ContainerMain.bind<CalendarService>(TYPES.CalendarService).to(CalendarService);

ContainerMain.bind<StudentService>(TYPES.StudentService).to(StudentService);
ContainerMain.bind<StaffService>(TYPES.StaffService).to(StaffService);

ContainerMain.bind<UploadService>(TYPES.UploadService).to(UploadService);

ContainerMain.bind<DashboardService>(TYPES.DashboardService).to(DashboardService);
ContainerMain.bind<AttendanceService>(TYPES.AttendanceService).to(AttendanceService);
ContainerMain.bind<AssignmentService>(TYPES.AssignmentService).to(AssignmentService);

ContainerMain.bind<ExamService>(TYPES.ExamService).to(ExamService);

ContainerMain.bind<FeedbackService>(TYPES.FeedbackService).to(FeedbackService);

ContainerMain.bind<FeeParticularService>(TYPES.FeeParticularService).to(FeeParticularService);
ContainerMain.bind<FeeInstallmentService>(TYPES.FeeInstallmentService).to(FeeInstallmentService);
ContainerMain.bind<FeeMasterService>(TYPES.FeeMasterService).to(FeeMasterService);
ContainerMain.bind<FeeStudentConfigService>(TYPES.FeeStudentConfigService).to(FeeStudentConfigService);
ContainerMain.bind<FeeTransactionService>(TYPES.FeeTransactionService).to(FeeTransactionService);
ContainerMain.bind<FeeDiscountService>(TYPES.FeeDiscountService).to(FeeDiscountService);

export { ContainerMain };
