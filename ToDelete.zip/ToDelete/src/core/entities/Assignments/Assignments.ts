import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToOne,
	OneToMany,
	ManyToOne,
	JoinColumn,
	ManyToMany,
	JoinTable
} from "typeorm";
import { ClassSections } from "../Master/ClassSections";
import { Subject } from "../Master/Subject";
import { DocsPhotos } from "../DocsPhotos/DocsPhotos";

@Entity("t_assignment")
export class Assignment {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	taskname: string;

	@Column("timestamp", {
		nullable: false,
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	duedate: Date;

	@ManyToMany(type => ClassSections)
	@JoinTable({ name: "t_j_asgn_class" })
	classsec: ClassSections[];

	@ManyToMany(type => Subject)
	@JoinTable({ name: "t_j_asgn_subject" })
	subject: Subject[];

	@Column("varchar", { length: 12, nullable: false })
	priority: string;

	@Column("varchar", { length: 25, nullable: true })
	tag: string;

	@Column("varchar", { length: 2500, nullable: true })
	notes: string;

	@OneToMany(type => DocsPhotos, docs => docs.assignment)
	documents: DocsPhotos[];

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
