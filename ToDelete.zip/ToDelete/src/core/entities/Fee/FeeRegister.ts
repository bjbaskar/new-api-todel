import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToMany, JoinTable
} from "typeorm";
// import { FeeClass } from "./FeeClass";
import { FeeMaster } from "./FeeMaster";
import { FeeRegisterDetails } from "./FeeRegisterDetails";

@Entity("fee_register")
export class FeeRegister {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", { nullable: false })
	paydate: Date;

	@Column("varchar", { length: 50, nullable: false })
	class_id: string;

	@Column("varchar", { length: 50, nullable: false })
	student_id: string;

	@Column("timestamp", { nullable: true })
	effective_from: Date;

	@OneToMany(type => FeeRegisterDetails, c => c.fee_register_id)
	fee_reg_details: FeeRegisterDetails[];

	@Column("double", { nullable: false })
	total_amount_payable: number;

	@Column("double", { nullable: false })
	total_amount_discount: number;

	@Column("double", { nullable: false })
	total_amount_paid: number;

	@Column("double", { nullable: false })
	total_amount_balance: number;

	@Column("varchar", { length: 50, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 50, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
