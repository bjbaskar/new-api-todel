import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToMany
} from "typeorm";

@Entity("fee_studtransport")
export class FeeStudentTransport {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 250, nullable: true })
	class_sec: string;

	@Column("boolean", { nullable: false })
	student_id: string;

	@Column("varchar", { nullable: false })
	fee_class: string;

	@Column("varchar", { nullable: false })
	amount_payable: string;

	@Column("varchar", { nullable: false })
	amount_discount: boolean;

	@Column("varchar", { nullable: false })
	amount_paid: boolean;

	@Column("varchar", { nullable: false })
	amount_balance: boolean;

	@Column("varchar", { nullable: false })
	receipt_given: boolean;

	@Column("varchar", { nullable: false })
	receipt_duplicate: boolean;

	@Column("varchar", { nullable: false })
	iscancel: boolean;

	@Column("varchar", { nullable: false })
	cancel_reason: boolean;

	@Column("varchar", { nullable: false })
	acad_year: boolean;

	@Column("varchar", { nullable: false })
	school_id: boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
