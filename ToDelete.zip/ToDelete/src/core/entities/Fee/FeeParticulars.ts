import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique
} from "typeorm";

@Entity("fee_particulars")
@Unique(["name"])
export class FeeParticulars {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	name: string;

	@Column("varchar", { length: 250, nullable: true })
	description: string;

	@Column("varchar", { nullable: false })
	acad_year: string;

	@Column("varchar", { nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
// 'Admission Fee', 'The fee to be paid for admission.',



// CREATE TABLE`invoices`(
// 	`INVOICE_ID` int(11) NOT NULL,
// 	`CLASS_SESSION_ID` int(11) NOT NULL,
// 	`STUDENT_ID` int(11) NOT NULL,
// 	`STATIC_HEADS` varchar(200) NOT NULL,
// 	`FLEXIBLE_HEADS` varchar(200) NOT NULL,
// 	`STATIC_SPLIT_AMOUNT` int(11) NOT NULL,
// 	`FLEXIBLE_SPLIT_AMOUNT` int(11) NOT NULL,
// 	`ACTUAL_AMOUNT` int(11) NOT NULL,
// 	`PREVIOUS_DUES` int(11) NOT NULL,
// 	`MONTH_FROM` varchar(20) NOT NULL,
// 	`YEAR_FROM` varchar(4) NOT NULL,
// 	`MONTH_TO` varchar(20) NOT NULL,
// 	`YEAR_TO` varchar(4) NOT NULL,
// 	`NUMBER_OF_MONTHS` int(2) NOT NULL,
// 	`DESCRIPTION` varchar(100) DEFAULT NULL,
// 	`USER_ID` varchar(50) NOT NULL,
// 	`DATE_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
// 	`STATUS` tinyint(1) NOT NULL
// ) ENGINE = InnoDB DEFAULT CHARSET = utf8;

// CREATE TABLE `flexible_to_students` (
// 	`ID` int(11) NOT NULL,
// 	`STUDENT_ID` int(11) NOT NULL,
// 	`CLASS_SESSION_ID` int(11) NOT NULL,
// 	`FLEXIBLE_HEAD_ID` int(11) NOT NULL,
// 	`FLEXIBLE_HEAD_AMOUNT` int(11) NOT NULL,
// 	`USER_ID` varchar(50) NOT NULL,
// 	`DATE_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
// 	`STATUS` tinyint(1) NOT NULL
//  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;



// CREATE TABLE `receipts` (
// 	`RECEIPT_ID` int(11) NOT NULL,
// 	`INVOICE_ID` int(11) NOT NULL,
// 	`STUDENT_ID` int(11) NOT NULL,
// 	`CLASS_SESSION_ID` int(11) NOT NULL,
// 	`STATIC_HEADS` varchar(200) NOT NULL,
// 	`FLEXIBLE_HEADS` varchar(200) NOT NULL,
// 	`DISCOUNT` varchar(10) NOT NULL,
// 	`DISCOUNT_AMOUNT` int(11) NOT NULL,
// 	`FINE` varchar(10) NOT NULL,
// 	`FINE_AMOUNT` int(11) NOT NULL,
// 	`ACTUAL_PAID_AMOUNT` int(11) NOT NULL,
// 	`MODE_OF_PAYMENT` varchar(20) NOT NULL,
// 	`DD_CHEQUE_NUMBER` varchar(20) NOT NULL,
// 	`DD_CHEQUE_DATE` varchar(10) NOT NULL,
// 	`DESCRIPTION` varchar(100) DEFAULT NULL,
// 	`USER_ID` varchar(50) NOT NULL,
// 	`DATE_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
// 	`STATUS` tinyint(1) NOT NULL
//  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;