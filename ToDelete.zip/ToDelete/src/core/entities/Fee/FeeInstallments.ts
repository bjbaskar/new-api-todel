import {
	Entity,
	PrimaryGeneratedColumn,
	Column
} from "typeorm";

@Entity("fee_installments")
export class FeeInstallments {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: false })
	fee_period: string;

	@Column("varchar", { length: 100, nullable: true })
	term_name: string;

	// @Column("boolean", { nullable: false })
	// is_monthly_fee: boolean;

	// @Column("boolean", { nullable: false })
	// is_one_time_fee: boolean;

	// @Column("varchar", { nullable: true })
	// monthly_month_name: string;

	@Column("simple-array", { nullable: true })
	term_month_names: [string];

	@Column("int", { nullable: false })
	no_of_months: number;

	@Column("timestamp", { precision: 2, nullable: false })
	from_date: Date;

	@Column("timestamp", { precision: 2, nullable: false })
	to_date: Date;

	@Column("varchar", { length: 50, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 50, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}