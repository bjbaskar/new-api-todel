import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToMany, JoinTable, OneToOne
} from "typeorm";

@Entity("fee_master")
export class FeeMaster {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	class_id: string;

	@Column("varchar", { length: 50, nullable: false })
	fee_particulars_id: string;

	@Column("varchar", { length: 50, nullable: false })
	fee_installments_id: string;
	// fee_period, from_date, to_date, range_name: string[]; refer FeeInstallments

	@Column("timestamp", { nullable: true })
	effective_from: Date;

	@Column("timestamp", { nullable: false })
	due_date: Date;

	@Column("double", { nullable: false })
	amount: number;

	@Column("boolean", { nullable: true })
	is_required_to_all: boolean;

	@Column("boolean", { nullable: true })
	is_refundable: boolean;

	@Column("boolean", { nullable: false, default: true })
	isactive: boolean;

	@Column("varchar", { length: 50, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 50, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}