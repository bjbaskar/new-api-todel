import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToMany
} from "typeorm";

@Entity("fee_studentconfig")
export class FeeStudentConfig {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	class_sec: string;

	@Column("varchar", { length: 50, nullable: false })
	student_id: string;

	@Column("varchar", { length: 50, nullable: false })
	fee_class: string;

	@Column("boolean", { nullable: false })
	isactive: boolean;

	@Column("varchar", { length: 50, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 50, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
