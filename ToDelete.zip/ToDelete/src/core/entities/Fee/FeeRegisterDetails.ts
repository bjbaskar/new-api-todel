import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToOne, JoinTable, JoinColumn, OneToMany
} from "typeorm";
// import { FeeClass } from "./FeeClass";
import { FeeMaster } from "./FeeMaster";
import { FeeRegister } from "./FeeRegister";

@Entity("fee_register_details")
export class FeeRegisterDetails {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", { nullable: false })
	paydate: Date;

	@ManyToOne(type => FeeRegister, c => c.fee_reg_details)
	@JoinColumn({ name: "fee_register_id" })
	fee_register_id: FeeRegister;

	@Column("varchar", { length: 50, nullable: false })
	fee_master_id: string;

	@Column("varchar", { length: 50, nullable: false })
	pay_mode: string;

	@Column("double", { nullable: false })
	amount_payable: number;

	@Column("double", { nullable: false })
	amount_discount: number;

	@Column("double", { nullable: false })
	amount_paid: number;

	@Column("double", { nullable: false })
	amount_balance: number;

	@Column("boolean", { nullable: false })
	is_paid_fully: boolean;

	@Column("int", { nullable: false })
	receipt_no: number;

	@Column("varchar", { length: 100, nullable: false })
	fee_trans_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
// iscancel: Boolean
// cancel_reason: String