import {
	Entity,
	PrimaryGeneratedColumn,
	Column
} from "typeorm";

@Entity("fee_discount")
export class FeeDiscount {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: true })
	class_id: string;

	@Column("varchar", { length: 50, nullable: false })
	student_id: string;

	@Column("varchar", { length: 50, nullable: false })
	fee_master_id: string;

	@Column("varchar", { length: 250, nullable: false })
	discount_reason: string;

	@Column("double", { nullable: false })
	discount_perc: number;

	@Column("double", { nullable: false })
	discount_amount: number;

	@Column("varchar", { length: 50, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 50, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}