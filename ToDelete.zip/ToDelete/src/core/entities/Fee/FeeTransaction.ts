import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToMany, JoinTable
} from "typeorm";
// import { FeeClass } from "./FeeClass";
import { FeeMaster } from "./FeeMaster";

@Entity("fee_transaction")
export class FeeTransaction {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", { nullable: false })
	paydate: Date;

	@Column("varchar", { length: 50, nullable: false })
	class_id: string;

	@Column("varchar", { length: 50, nullable: false })
	student_id: string;

	@Column("varchar", { length: 50, nullable: false })
	fee_master_id: string;

	@Column("varchar", { nullable: false })
	pay_mode: string;

	@Column("double", { nullable: false })
	amount_paid: number;

	@Column("double", { nullable: false })
	amount_balance: number;

	@Column("int", { nullable: false })
	receipt_no: number;

	@Column("int", { nullable: false })
	receipt_duplicate: number;

	@Column("boolean", { nullable: false })
	iscancel: boolean;

	@Column("varchar", { length: 250, nullable: false })
	cancel_reason: string;

	@Column("varchar", { length: 100, nullable: false })
	fee_trans_id: string;

	@Column("varchar", { length: 50, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 50, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
