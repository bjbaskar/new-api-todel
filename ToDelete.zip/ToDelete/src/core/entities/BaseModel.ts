import { Column, Entity } from "typeorm";

export abstract class BaseModel {
	@Column("int", { nullable: true })
	createdby: number;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("int", { nullable: true })
	updatedby: number;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;
}
