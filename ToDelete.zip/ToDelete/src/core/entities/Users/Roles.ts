import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable, ManyToOne } from "typeorm";
import { Users } from "./Users";
import { Permissions } from "./Permissions";

@Entity("m_roles")
export class Roles {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 20, nullable: false })
	rolename: string;

	@ManyToMany(type => Permissions, perm => perm.roles)
	@JoinTable({
		name: "m_j_role_permission"
	})
	permissions: Permissions[];

	@ManyToMany(type => Users, userroles => userroles.roles, {
		cascade: true
	})
	user: Users[];

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
