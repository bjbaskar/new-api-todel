import {
	Entity, Column, PrimaryGeneratedColumn
} from "typeorm";

@Entity("m_loginhistory")
export class LoginHistory {

	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 20, nullable: false })
	username: string;

	@Column("varchar", { length: 100, nullable: true })
	browser: string;

	@Column("varchar", { length: 100, nullable: true })
	cpu: string;

	@Column("varchar", { length: 100, nullable: true })
	device: string;

	@Column("varchar", { length: 100, nullable: true })
	engine: string;

	@Column("varchar", { length: 100, nullable: true })
	os: string;

	@Column("varchar", { length: 50, nullable: true })
	sessionid: string;

	@Column("timestamp", {
		nullable: true,
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	lastlogin: Date;

	@Column("timestamp", {
		nullable: true,
		precision: 2,
	})
	lastlogout: Date;
}

// https://stackoverflow.com/questions/6163350/server-side-browser-detection-node-js

// https://github.com/etienne-martin/device-detector-js/blob/master/src/parsers/client/browser.ts