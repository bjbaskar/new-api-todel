import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable, ManyToOne } from "typeorm";
import { Roles } from "./Roles";
import { Users } from "./Users";

@Entity("m_permissions")
export class Permissions {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 20, nullable: false })
	module: string;

	@Column("varchar", { length: 20, nullable: false })
	title: string;

	@Column("varchar", { length: 20, nullable: false })
	key: string;

	@ManyToMany(type => Roles, roles => roles.permissions, {
		cascade: true
	})
	roles: Roles[];

	@ManyToOne(type => Users, userroles => userroles.permissions)
	user: Users;

	@Column("varchar", {
		nullable: false,
		default: "SYSTEM"
	})
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
