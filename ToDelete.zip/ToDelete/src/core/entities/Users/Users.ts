import {
	Entity, PrimaryGeneratedColumn, Column, Unique,
	OneToMany, ManyToMany, JoinTable, OneToOne, JoinColumn
} from "typeorm";
import { Roles } from "./Roles";
import { Permissions } from "./Permissions";
import { Staff } from "../Staff/Staff";
import { Students } from "../Students/Student";

@Entity("m_users")
@Unique(["username"])
export class Users {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 20, nullable: false })
	username: string;

	@Column("varchar", { length: 255, nullable: true })
	email: string;

	@Column("text", { nullable: false })
	password: string;

	@Column("boolean", { nullable: false, default: true })
	isactive: boolean;

	@Column("boolean", { nullable: false, default: false })
	isadmin: boolean;

	@Column("int", { nullable: false, default: 0 })
	loginattempts: number;

	@Column("varchar", { nullable: false, default: 0 })
	lockuntil: number;

	@Column("int", { nullable: true, default: 0 })
	passwordexpires: number;

	@ManyToMany(type => Roles, roles => roles.user)
	@JoinTable({
		name: "m_j_user_roles"
	})
	roles: Roles[];

	@OneToMany(type => Permissions, perm => perm.user)
	permissions: Permissions[];

	@Column("varchar", { length: 15, nullable: false })
	usertype: string;

	@OneToOne(type => Staff, staff => staff.user)
	@JoinColumn()
	staff: Staff;

	@OneToOne(type => Students, stud => stud.user)
	@JoinColumn()
	students: Students;

	@Column("varchar", { length: 500, nullable: true, })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		nullable: false,
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		nullable: true,
		precision: 2,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
