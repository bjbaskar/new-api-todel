import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToMany,
	ManyToOne
} from "typeorm";

@Entity("archieve_m_attendance")
export class AttendanceArchieve {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: false })
	class_id: string;

	@Column("varchar", { length: 100, nullable: false })
	student_id: string;

	@Column("varchar", { length: 5, nullable: false })
	total_working_days: string;

	@Column("varchar", { length: 10, nullable: false })
	days_absent: string;

	@Column("varchar", { length: 10, nullable: false })
	days_present: string;

	@Column("varchar", { length: 50, nullable: false })
	perc: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;
}