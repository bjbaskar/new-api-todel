import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
} from "typeorm";

@Entity("archieve_exam_markregister")
export class MarkRegisterArchieve {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 100, nullable: false })
	student_id: string;

	@Column("simple-json", { nullable: true })
	profile: {
		firstName: string,
		lastName: string,
		gender: string,
		examName: string,
		className: string,
		classSection: string,
		totalMarksObtained: string,
		totalMaxMarks: string,
		totalGrade: string,
		totalGradeColor: string,
		totalPercentage: string,
		notes: string
	};

	@Column("simple-json", { nullable: true })
	marks: [{
		subjectName: string,
		subjectColor: string,
		subjectOrderby: string,
		marksObtained: string,
		maxMarks: string,
		perc: string,
		gradeName: string,
		gradePoint: string,
		gradeColor: string
	}];

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
	})
	createdon: Date;

}