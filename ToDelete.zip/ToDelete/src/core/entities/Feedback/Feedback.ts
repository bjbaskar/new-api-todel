import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";

@Entity("c_feedback")
export class Feedback {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("int", { nullable: true })
	rating: number;

	@Column("text", { nullable: false })
	desc: string;

	@Column("text", { nullable: true })
	qa: string;

	@Column("varchar", { length: 50, nullable: true })
	staff: string;

	@Column("varchar", { length: 50, nullable: true })
	student: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

}
