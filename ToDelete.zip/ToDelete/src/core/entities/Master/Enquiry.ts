import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { BaseModel } from "../BaseModel";

@Entity("enquiry")
export class Enquiry extends BaseModel {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("timestamp", { nullable: false })
	inquirydate: Date;

	classsec: string; // IClassSecModel; // Pre KG
	studentid: string;

	@Column("varchar", { length: 30, nullable: false })
	reportername: string; // parents name

	@Column("varchar", { length: 30, nullable: false })
	receivername: string; // teacher1

	@Column("varchar", { length: 30, nullable: false })
	response: string; // bjbaskar

	@Column("timestamp", { nullable: false })
	nextfollowup: Date;

	@Column("varchar", { length: 30, nullable: false })
	modeofinquiry: string; // phone email inperson
}
