import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";

@Entity("m_calendar")
export class Calendar {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	title: string; // bday, competition, project work

	@Column("varchar", { length: 1000, nullable: true })
	description: string;

	@Column("varchar", { length: 20, nullable: true })
	eventstype: string;

	@Column("timestamp", { nullable: false, precision: 2 })
	start: Date;

	@Column("timestamp", { nullable: false, precision: 2 })
	end: Date;

	@Column("boolean", { nullable: false })
	allDay: Boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
