import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { ClassSections } from "./ClassSections";

@Entity("m_acadyear")
export class AcadYear {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", { nullable: false })
	fromdate: Date;

	@Column("timestamp", { nullable: false })
	todate: Date;

	@Column("varchar", { length: 20, nullable: false })
	displayname: string;

	@Column("int", { nullable: false })
	prefixyear: number;

	@Column("boolean", { nullable: false })
	is_current: Boolean;

	@Column("boolean", { nullable: false })
	is_next: Boolean;

	@OneToMany(type => ClassSections, cls => cls.academicyear)
	classsec: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
