import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { BaseModel } from "../BaseModel";

@Entity("stationary")
export class Stationary extends BaseModel {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("varchar", { length: 50, nullable: false })
	item: string;

	@Column("varchar", { length: 100, nullable: false })
	company: string;

	@Column("int", { nullable: false })
	price: string;

	@Column("boolean", { nullable: false })
	isactive: Boolean;
}

// pencil eraser
// company a, sivakasi
