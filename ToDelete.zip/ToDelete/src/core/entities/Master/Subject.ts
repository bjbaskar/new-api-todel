import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	Unique,
	ManyToMany,
	ManyToOne,
	OneToMany
} from "typeorm";
import { Staff } from "../../entities/Staff/Staff";
import { ClassSections } from "./ClassSections";
import { TextBooks } from "./TextBooks";
import { ClassTeacher } from "./ClassTeacher";
import { Assignment } from "../Assignments/Assignments";

@Entity("m_subjects")
@Unique(["subcode"])
export class Subject {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	name: string;

	@Column("varchar", { length: 20, nullable: false })
	subcode: string;

	@Column("varchar", { length: 10 })
	color: string;

	@Column("int", { nullable: false })
	orderby: number;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;

	// @ManyToMany(type => ClassSections, clsSec => clsSec.subjects, {
	// 	cascade: true
	// })
	// classSections: ClassSections[];

	@ManyToOne(type => TextBooks, book => book.subject)
	textbook: string;

	// @ManyToOne(type => Staff, teacher => teacher.subjects)
	// teacher: Staff;

	@OneToMany(type => ClassTeacher, st => st.subject)
	classteacher: ClassTeacher[];

	// @ManyToOne(type => Assignment, agn => agn.subject)
	// assignment: Assignment;
}
