import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { HolidayNotifications } from "../Notifications/Notification";

@Entity("m_holidays")
export class Holiday {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	occasion: string;

	@Column("varchar", { length: 250, nullable: false })
	description: string;

	@Column("varchar", { length: 25, nullable: false })
	holidaytype: string;

	@Column("timestamp", { nullable: false })
	fromdate: Date;

	@Column("varchar", { length: 10, nullable: false })
	fdayofweek: string;

	@Column("timestamp", { nullable: false })
	todate: Date;

	@Column("varchar", { length: 10, nullable: false })
	tdayofweek: string;

	@Column("varchar", { length: 250, nullable: true })
	comments: string;

	@Column("boolean", { nullable: false })
	status: boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;

	@OneToMany(type => HolidayNotifications, holi => holi.holiday)
	notification: string;

}
