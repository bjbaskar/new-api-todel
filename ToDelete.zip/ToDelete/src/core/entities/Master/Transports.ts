import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { BaseModel } from "../BaseModel";

@Entity("m_transports")
export class Transports extends BaseModel {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("varchar", { length: 50, nullable: false })
	transportname: string;

	@Column("varchar", { length: 100, nullable: false })
	typeofvehicle: string;

	@Column("varchar", { length: 20, nullable: false })
	vehicleno: string;

	@Column("varchar", { length: 20, nullable: false })
	insurancetakenon: Date;

	@Column("varchar", { length: 20, nullable: false })
	insurancevalidtill: Date;

	@Column("int", { nullable: false })
	capacity: number;

	@Column("varchar", { length: 50, nullable: true })
	photo: string;

	@Column("varchar", { length: 100, nullable: false })
	route: Array<string>;

	@Column("boolean", { nullable: false })
	isactive: Boolean;
}
