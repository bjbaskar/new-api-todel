import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity("m_dataconfigs")
export class DataConfig {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("varchar", { length: 20, nullable: false })
	name: string;

	@Column("varchar", { length: 50, nullable: false })
	value: string;
}

// sports
// extra curicular
// staff designation => teacher faculty attender driver
// Staff leave type => ChildCare Maternity Parental Leave Sick Leave public holiday Time Off In Lieu

