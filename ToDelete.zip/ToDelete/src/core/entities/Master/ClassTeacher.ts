import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	JoinColumn,
	ManyToOne
} from "typeorm";
import { ClassSections } from "./ClassSections";
import { Subject } from "./Subject";
import { Staff } from "../Staff/Staff";

@Entity("m_classteacher")
export class ClassTeacher {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@ManyToOne(type => ClassSections, cls => cls.classteachersub)
	@JoinColumn({ name: "class_id" })
	classes!: string;

	@ManyToOne(type => Subject, sub => sub.classteacher)
	@JoinColumn({ name: "subject_id" })
	subject!: string;

	@ManyToOne(type => Staff, st => st.classteacher)
	@JoinColumn({ name: "staff_id" })
	staff!: string;
}