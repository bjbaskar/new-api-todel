import {
	Entity,
	PrimaryGeneratedColumn,
	Column
} from "typeorm";

@Entity("m_rules")
export class RulesRegulations {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 500, nullable: false })
	title: string;

	@Column("varchar", { length: 1024, nullable: false })
	entext: string;

	@Column("varchar", { length: 1024, nullable: false })
	tamiltext: string;

	@Column("int", { nullable: false })
	orderby: number;

}