import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity("notebooks")
export class NoteBooks {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("varchar", { length: 50, nullable: false })
	notebook: string;

	@Column("varchar", { length: 100, nullable: false })
	company: string;

	@Column("int", { nullable: false })
	price: string;

	@Column("varchar", { length: 250, nullable: false })
	notes: string;

	@Column("boolean", { nullable: false })
	isactive: Boolean;
}

// Four line note
// company a, sivakasi
