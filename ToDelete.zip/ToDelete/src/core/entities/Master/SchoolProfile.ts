import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToMany
} from "typeorm";
import { DocsPhotos } from "../DocsPhotos/DocsPhotos";

@Entity("m_schoolprofile")
export class SchoolProfile {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	name: string;

	@Column("varchar", { length: 50, nullable: false })
	surname: string;

	@Column("varchar", { length: 50, nullable: true })
	logo: string;

	@Column("varchar", { length: 30, nullable: false })
	sector: string; // private, public, govt aided

	@Column("varchar", { length: 50, nullable: false })
	provider: string; // religious, commnity, corporate, edu trust

	@Column("varchar", { length: 50, nullable: false })
	type: string; // pre-primay, primary ,secondary

	@Column("timestamp", { precision: 2, nullable: true })
	dateopened: Date;

	@Column("timestamp", { precision: 2, nullable: true })
	recognitiondate: Date;

	@Column("varchar", { length: 250, nullable: false })
	address: string;

	@Column("varchar", { length: 10, nullable: false })
	postalcode: string;

	@Column("varchar", { length: 30, nullable: false })
	district: string;

	@Column("varchar", { length: 30, nullable: true })
	taluk: string;

	@Column("varchar", { length: 25, nullable: true })
	phone: string;

	@Column("varchar", { length: 25, nullable: true })
	mobile: string;

	@Column("varchar", { length: 100, nullable: false })
	locality: string; // urban, rural

	@Column("varchar", { length: 150, nullable: false })
	latitude: string;

	@Column("varchar", { length: 150, nullable: false })
	longitude: string;

	@OneToMany(type => DocsPhotos, docs => docs.school)
	documents: DocsPhotos[];

	@Column("boolean", { nullable: false })
	isactive: boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
