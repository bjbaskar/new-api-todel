import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { EduSystems } from "./EduSystems";
import { AcadYear } from "./AcadYear";
import { ClassSections } from "./ClassSections";
import { Subject } from "./Subject";

@Entity("m_textbooks")
export class TextBooks {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: false })
	academicyear: string;

	@Column("varchar", { length: 100, nullable: false })
	edusystem: string;

	@ManyToOne(type => ClassSections, cls => cls.textbook)
	class_section: string;

	@ManyToOne(type => Subject, subj => subj.textbook)
	subject: string;

	@Column("varchar", { length: 50, nullable: false })
	bookname: string;

	@Column("varchar", { length: 100, nullable: false })
	publisher: string;

	@Column("varchar", { length: 100, nullable: false })
	author: string;

	@Column("int", { nullable: false })
	price: number;

	@Column("boolean", { nullable: false })
	isactive: Boolean;

	@Column("varchar", { length: 50, nullable: false })
	booktype: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
