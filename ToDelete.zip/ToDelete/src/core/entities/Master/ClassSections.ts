import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	ManyToMany,
	JoinTable,
	OneToMany,
	ManyToOne,
	OneToOne,
	JoinColumn
} from "typeorm";
import { AcadYear } from "./AcadYear";
import { EduSystems } from "./EduSystems";
import { Subject } from "./Subject";
import { Staff } from "../Staff/Staff";
import { Students } from "../Students/Student";
import { TextBooks } from "./TextBooks";
import { ClassTeacher } from "./ClassTeacher";
import { Assignment } from "../Assignments/Assignments";

@Entity("m_classsection")
export class ClassSections {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 30, nullable: false })
	name: string;

	@Column("varchar", { length: 10, nullable: false })
	section: string;

	@Column("int", { nullable: true })
	orderby: number;

	@Column("boolean", { default: true })
	isactive: Boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;

	@ManyToOne(type => AcadYear, ayr => ayr.classsec)
	academicyear: string;

	@ManyToOne(type => EduSystems, edu => edu.classsec)
	edusystem: string;

	@OneToOne(type => Staff, st => st.classtr)
	@JoinColumn()
	classteacher: string;

	@ManyToOne(type => Staff, st => st.asstclasstr)
	@JoinColumn()
	asstclassteacher: string;

	@ManyToOne(type => TextBooks, book => book.class_section)
	textbook: string;

	@OneToMany(type => ClassTeacher, tr => tr.classes)
	@JoinTable({
		name: "m_classteacher"
	})
	classteachersub: ClassTeacher[];

	@ManyToMany(type => Students, stud => stud.classsec)
	students: Students[];

	@Column("boolean", { nullable: false })
	is_final_year: boolean;
}
