import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity("m_caste")
export class Caste {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("varchar", { length: 500, nullable: false })
	name: string;
}
