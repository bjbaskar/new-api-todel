import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Exams } from "./Exam";

@Entity("exam_timetable")
export class ExamTimeTable {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@OneToMany(type => Exams, exams => exams.id)
	exam_class_sub: string;

	@Column("timestamp", {
		precision: 2
	})
	examdate: Date;

	@Column("varchar", { length: 10 })
	start_time: string;

	@Column("varchar", { length: 10 })
	end_time: string;

	@Column("int", { nullable: false })
	noofhours: number;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
