import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity("exam_markregister_sum")
export class MarkRegisterSummary {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: false })
	exam_name: string;

	@Column("varchar", { length: 100, nullable: false })
	class_id: string;

	@Column("varchar", { length: 100, nullable: false })
	student_id: string;

	@Column("int", { nullable: false })
	total_marks_obtained: number;

	@Column("int", { nullable: false })
	total_max_marks: number;

	@Column("varchar", { length: 100, nullable: true })
	total_grade: string;

	@Column("varchar", { length: 10, nullable: true })
	total_grade_color: string;

	@Column("int", { nullable: false })
	total_percentage: number;

	@Column("varchar", { length: 100, nullable: true })
	acad_year: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
