import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Students } from "../Students/Student";
import { ClassSections } from "../Master/ClassSections";
import { AcadYear } from "../Master/AcadYear";

@Entity("exam_promotions")
export class Promotions {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@OneToMany(type => Students, student => student.id)
	student: string;

	@OneToMany(type => ClassSections, c_from => c_from.id)
	class_from: string;

	@OneToMany(type => ClassSections, c_to => c_to.id)
	class_to: string;

	@Column("timestamp", { nullable: false })
	promotion_date: Date;

	@Column("varchar", { length: 10, nullable: false })
	graduated: string;

	@OneToMany(type => AcadYear, acd_from => acd_from.id)
	acd_year_from: string;

	@OneToMany(type => AcadYear, acd_to => acd_to.id)
	acd_year_to: string;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
// update to main STUDENT Collection
