import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToOne, OneToMany, JoinColumn, ManyToMany, JoinTable, Unique } from "typeorm";
import { Exams } from "./Exam";
import { Students } from "../Students/Student";
import { ExamGrades } from "./Grades";
import { AcadYear } from "../Master/AcadYear";

@Entity("exam_markregister")
export class MarkRegister {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@ManyToMany(type => Exams, {
		cascade: true
	})
	@JoinTable({ name: "exam_j_reg_exam" })
	exam_class_sub: Exams[];

	@ManyToMany(type => Students, {
		cascade: true
	})
	@JoinTable({ name: "exam_j_reg_students" })
	students: Students[];

	@Column("int", { nullable: false })
	marks_obtained: number;

	@Column("varchar", { length: 100, nullable: true })
	grade: string;

	@Column("int", { nullable: false })
	percentage: number;

	// @OneToMany(type => AcadYear, acd => acd.id)
	@Column("varchar", { length: 100, nullable: true })
	acad_year: string;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}

// calculate the grade based on the marks_obtained entry.
