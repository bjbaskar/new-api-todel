import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { ClassSections } from "../Master/ClassSections";
import { Subject } from "../Master/Subject";
import { MarkRegister } from "./MarkRegister";

@Entity("exams")
export class Exams {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: false })
	name: string;

	@ManyToOne(type => ClassSections, cls => cls.id)
	class: string;

	@ManyToOne(type => Subject, subj => subj.id)
	subjects: string;

	@Column("int", { nullable: false })
	min_marks: number;

	@Column("int", { nullable: false })
	max_marks: number;

	@Column("int", { nullable: false })
	orderby: number;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("boolean", { nullable: false })
	is_final_exam: boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
