import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
} from "typeorm";

@Entity("exam_promotion_history")
export class PromotionHistory {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
	})
	promotion_date: Date;

	@Column("varchar", { length: 100, nullable: false })
	class_id_from: string;

	@Column("varchar", { length: 100, nullable: false })
	class_id_to: string;

	@Column("varchar", { length: 100, nullable: false })
	acad_year_from: string;

	@Column("varchar", { length: 100, nullable: false })
	acad_year_to: string;

	@Column("varchar", { length: 100, nullable: false })
	school_id: string;

	@Column("boolean", { nullable: true })
	addmarkstoarchieved: boolean;

	@Column("varchar", { length: 5, nullable: true })
	detainedstudents: string;

	@Column("varchar", { length: 1024, nullable: true })
	getexamname: string;

	@Column("boolean", { nullable: true })
	hasattendancearchieved: boolean;

	@Column("boolean", { nullable: true })
	hasdeletedattendance: boolean;

	@Column("boolean", { nullable: true })
	hasdeletedmarkregister: boolean;

	@Column("boolean", { nullable: true })
	hasdeletedmarkregistersum: boolean;

	@Column("boolean", { nullable: true })
	hasupdatepromotionstatus: boolean;

	@Column("boolean", { nullable: true })
	ispromotetonewclass: boolean;

	@Column("varchar", { length: 10, nullable: true })
	noofaddmarksarchieved: string;

	@Column("varchar", { length: 10, nullable: true })
	noofattendancearchieved: string;

	@Column("varchar", { length: 10, nullable: true })
	noofattendancedeleted: string;

	@Column("varchar", { length: 10, nullable: true })
	noofdelmarkregister: string;

	@Column("varchar", { length: 10, nullable: true })
	noofdelmarkregistersum: string;

	@Column("varchar", { length: 10, nullable: true })
	noofdetained: string;

	@Column("varchar", { length: 10, nullable: true })
	noofstudentspromoted: string;

	@Column("varchar", { length: 10, nullable: true })
	noofupdateacdyear: string;

	@Column("boolean", { nullable: true })
	updateacdyear: boolean;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)",
	})
	updatedon: Date;
}