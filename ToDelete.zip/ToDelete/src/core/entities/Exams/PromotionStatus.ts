import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
} from "typeorm";

@Entity("exam_promotion_status")
export class PromotionStatus {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
	})
	promotion_date: Date;

	@Column("varchar", { length: 30, nullable: false })
	status: string;

	@Column("varchar", { length: 100, nullable: false })
	class_id: string;

	@Column("varchar", { length: 100, nullable: false })
	acad_year: string;

	@Column("varchar", { length: 100, nullable: false })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)",
	})
	updatedon: Date;
}