import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity("exam_grades")
export class ExamGrades {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	name: string;

	@Column("varchar", { length: 255, nullable: false })
	description: string;

	@Column("varchar", { length: 10, nullable: false })
	color: string;

	@Column("int", { nullable: false })
	grade_point: number;

	@Column("int", { nullable: false })
	min: number;

	@Column("int", { nullable: false })
	max: number;

	@Column("int", { nullable: false })
	orderby: number;

	// @OneToMany(type => AcadYear, acd => acd.id)
	// acad_year: string;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}

// A+	A+ #e5e5e5	10	91 -> 100 notes upduser
// A	A  #e7e7e7	09	81 -> 90.99 notes upduser
