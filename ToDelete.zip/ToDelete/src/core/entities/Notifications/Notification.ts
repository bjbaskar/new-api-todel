import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { Holiday } from "../Master/Holiday";

@Entity("m_hnotifications")
export class HolidayNotifications {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 250, nullable: false })
	notifytext: string;

	@Column("int", { nullable: true })
	notifysend: number;

	@Column("varchar", { length: 250, nullable: false })
	notifyby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	notifyon: Date;

	@ManyToOne(type => Holiday, edu => edu.notification)
	holiday: string;
}
