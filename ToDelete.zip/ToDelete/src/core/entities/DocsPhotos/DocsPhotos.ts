import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { Staff } from "../Staff/Staff";
import { Students } from "../Students/Student";
import { SchoolProfile } from "../Master/SchoolProfile";
import { Assignment } from "../Assignments/Assignments";

@Entity("c_docsphotos")
export class DocsPhotos {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	name: string;

	@Column("varchar", { length: 20, nullable: false })
	modulename: string;

	@Column("varchar", { length: 20, nullable: false })
	doctype: string;

	@Column("varchar", { length: 50, nullable: false })
	docid: string;

	@Column("varchar", { length: 50, nullable: true })
	filesize: string;

	@Column("varchar", { length: 150, nullable: true })
	filetype: string;

	@Column("varchar", { length: 1024, nullable: true })
	mediaurl: string;

	@ManyToOne(type => Staff, staff => staff.documents, { nullable: true })
	staff: string;

	@ManyToOne(type => Students, student => student.documents, { nullable: true })
	student: string;

	@ManyToOne(type => SchoolProfile, school => school.documents, { nullable: true })
	school: string;

	@ManyToOne(type => Assignment, asgn => asgn.documents, { nullable: true })
	assignment: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

}
