import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToOne,
	JoinColumn,
	ManyToMany,
	JoinTable,
	OneToMany,
	ManyToOne
} from "typeorm";

import { Students } from "./Student";

@Entity("s_students_tc")
export class StudentTC {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@OneToOne(type => Students)
	@JoinColumn({ referencedColumnName: "id" })
	student: Students;

	@Column("varchar", { length: 250, nullable: true })
	identifications: string;

	@Column("varchar", { length: 250, nullable: true })
	scholarship: string;
	// Details of Scholarship or Educational Concession Received *

	@Column("varchar", { length: 250, nullable: true })
	rte: string;
	// Details of RTE Received *

	@Column("timestamp", { nullable: false })
	medicalinspection: Date;
	// Date of Medical inspection during the last academic year *

	@Column("varchar", { length: 250, nullable: true })
	conductcharacter: string;
	// Student's conduct and character *

	@Column("varchar", { length: 100, nullable: true })
	class_studied: string;
	// Student studying in the school from lkg - 5th std

	@Column("varchar", { length: 100, nullable: true })
	period_of_study: string;

	@Column("timestamp", { nullable: false })
	doj: Date;
	// Date of Joining*

	@Column("varchar", { length: 100, nullable: true })
	leaving_class: string;

	@Column("varchar", { length: 250, nullable: true })
	promoted: string; //  yes, no, no-discontinued, refer marksheet
	// Student is Promoted to the Next class *

	@Column("timestamp", { nullable: false })
	lastdate: Date;
	// Last date on which Student attended school

	@Column("varchar", { length: 20, nullable: true })
	firstlanguage: string;

	@Column("varchar", { length: 100, nullable: true })
	medium_of_instruct: string;

	@Column("varchar", { length: 30, nullable: true })
	schoolrecogno: string;
	// School Recognition Number *

	@Column("timestamp", { nullable: false })
	tcappdate: Date;
	// TC application Date *

	@Column("timestamp", { nullable: false })
	tcissuedate: Date;
	// TC Issue Date *

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}