import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable } from "typeorm";

import { Students } from "./Student";
import { Address } from "./Address";

@Entity("s_parents")
export class Parents {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	fathername: string;

	@Column("timestamp", { nullable: true })
	fatherdob: Date;

	@Column("varchar", { length: 50, nullable: false })
	fathergraduation: string;

	@Column("varchar", { length: 50, nullable: false })
	fatheroccupation: string;

	@Column("varchar", { length: 150, nullable: true })
	fathercompanyname: string;

	@Column("int", { nullable: false })
	fatherincome: number;

	@Column("varchar", { length: 50, nullable: true })
	fatheraadhaarno: string;

	@Column("varchar", { length: 50, nullable: true })
	mothername: string;

	@Column("timestamp", { nullable: true })
	motherdob: Date;

	@Column("varchar", { length: 50, nullable: true })
	mothergraduation: string;

	@Column("varchar", { length: 50, nullable: true })
	motheroccupation: string;

	@Column("varchar", { length: 150, nullable: true })
	mothercompanyname: string;

	@Column("int", { nullable: true })
	motherincome: number;

	@Column("varchar", { length: 50, nullable: true })
	motheraadhaarno: string;

	@Column("varchar", { length: 50, nullable: true })
	guardianname: string;

	@Column("varchar", { length: 50, nullable: true })
	guardianoccupation: string;

	@Column("boolean", {
		nullable: false,
		default: () => true
	})
	isactive: Boolean;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@ManyToMany(type => Students, stud => stud.parents, {
		cascade: true
	})
	students: Students[];

	@ManyToMany(type => Address, addr => addr.parents)
	@JoinTable({
		name: "s_j_parent_address"
	})
	address: Address[];

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}
