import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToOne,
	JoinColumn,
	ManyToMany,
	JoinTable,
	OneToMany,
	ManyToOne
} from "typeorm";

import { Parents } from "./Parents";
import { DocsPhotos } from "../DocsPhotos/DocsPhotos";
import { GovtRTE } from "./GovtRTE";
import { ClassSections } from "../Master/ClassSections";
import { AcadYear } from "../Master/AcadYear";
import { Users } from "../Users/Users";
import { MarkRegister } from "../Exams/MarkRegister";

@Entity("s_students")
export class Students {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("int", { nullable: false })
	studentno: number;

	@Column("int", { nullable: false })
	prefixyear: number;

	@Column("varchar", { length: 50, nullable: true })
	aadhaarno: string;

	@Column("varchar", { length: 50, nullable: true })
	emisno: string;

	@Column("varchar", { length: 50, nullable: true })
	udiseno: string;

	@Column("varchar", { length: 50, nullable: false })
	firstname: string;

	@Column("varchar", { length: 50, nullable: false })
	lastname: string;

	@Column("varchar", { length: 6, nullable: false })
	gender: string;

	@Column("timestamp", { nullable: false })
	dob: Date;

	@Column("timestamp", {
		nullable: false,
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	doj: Date;

	@Column("varchar", {
		length: 25,
		nullable: false
	})
	nationality: string;

	@Column("varchar", { length: 50, nullable: false })
	religion: string;

	@Column("varchar", { length: 50, nullable: false })
	castecategory: string;

	@Column("varchar", { length: 50, nullable: false })
	community: string;

	@Column("varchar", { length: 50, nullable: false, default: "Tamil" })
	mothertongue: string;

	@Column("varchar", { length: 50, nullable: true })
	bloodgroup: string;

	@Column("varchar", { length: 255, nullable: true })
	identification: string;

	@Column("boolean", {
		nullable: false,
		default: () => true
	})
	isactive: boolean;

	@Column("varchar", { length: 100, nullable: true })
	disability: string;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@Column("varchar", { length: 1024, nullable: true })
	photo: string;

	@ManyToMany(type => ClassSections, cls => cls.students)
	@JoinTable({
		name: "s_j_student_classsec"
	})
	classsec: ClassSections[];

	@ManyToMany(type => Parents, par => par.students)
	@JoinTable({
		name: "s_j_student_parents"
	})
	parents: Parents[];

	@OneToMany(type => DocsPhotos, docs => docs.student)
	documents: DocsPhotos[];

	@OneToMany(type => GovtRTE, rte => rte.student)
	govtrte: GovtRTE[];

	// @ManyToOne(type => AcadYear, acyear => acyear.students)
	// acadyear: AcadYear;

	@OneToOne(type => Users, user => user.students)
	user: Users;

	@Column("varchar", { length: 100, nullable: true })
	acad_year: string;

	@Column("varchar", { length: 100, nullable: true })
	school_id: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}