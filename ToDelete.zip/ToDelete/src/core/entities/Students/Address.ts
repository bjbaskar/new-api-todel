import { Entity, PrimaryGeneratedColumn, Column, ManyToMany } from "typeorm";

import { Parents } from "./Parents";

@Entity("s_address")
export class Address {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 50, nullable: false })
	type: string;

	@Column("varchar", { length: 255, nullable: false })
	address1: string;

	@Column("varchar", { length: 255, nullable: true })
	address2: string;

	@Column("varchar", { length: 25, nullable: false })
	city: string;

	@Column("varchar", { length: 25, nullable: true })
	district: string;

	@Column("varchar", {
		length: 20
	})
	state: string;

	@Column("varchar", {
		length: 50
	})
	country: string;

	@Column("int", { nullable: true })
	postalcode: number;

	@Column("varchar", { length: 20, nullable: false })
	mobile: string;

	@Column("varchar", { length: 20, nullable: true })
	homephone: string;

	@Column("varchar", { length: 100, nullable: true })
	email: string;

	@Column("boolean", {
		nullable: false,
		default: () => true
	})
	isactive: Boolean;

	@Column("varchar", { length: 500, nullable: true })
	notes: string;

	@ManyToMany(type => Parents, stud => stud.address, {
		cascade: true
	})
	parents: Parents[];

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;

	// studentid: any;
	// staffid: any
	// fatherOffid: any;
	// motherOffid: any;
	// orgid: any;
}
