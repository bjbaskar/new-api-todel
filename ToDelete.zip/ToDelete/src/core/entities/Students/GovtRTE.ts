import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { BaseModel } from "../BaseModel";
import { Students } from "./Student";

@Entity("s_govtrte")
export class GovtRTE extends BaseModel {
	@PrimaryGeneratedColumn()
	id: number;

	@Column("varchar", { length: 255, nullable: false })
	CWSN: Array<string>;

	@Column("int", { nullable: false })
	amountreceived: number;

	@Column("timestamp", { nullable: false })
	amountdate: Date;

	@Column("varchar", { length: 150, nullable: false })
	facilitiesprovided: Array<string>;

	@Column("varchar", { length: 150, nullable: false })
	uniformsets: string;

	@Column("varchar", { length: 150, nullable: false })
	freetextbook: string;

	@Column("varchar", { length: 150, nullable: false })
	freetransport: string;

	@Column("varchar", { length: 500 })
	notes: string;

	@ManyToOne(type => Students, student => student.govtrte)
	student: Students;
}

// tab name => Govt. RTE Details

// RTE = Right to education
// CWSN = Children with Special Needs

// FACILITY BY CWSN	NOT APPLICABLE
// FACILITY BY CWSN	BRAILLE BOOKS
// FACILITY BY CWSN	BRAILLE KIT
// FACILITY BY CWSN	LOW VISION KIT
// FACILITY BY CWSN	HEARING AID
// FACILITY BY CWSN	BRACES
// FACILITY BY CWSN	CRUTCHES
// FACILITY BY CWSN	WHEEL CHAIR
// FACILITY BY CWSN	TRI-CYCLE
// FACILITY BY CWSN	CALLIPER
// FACILITY BY CWSN	OTHERS

// ------------------------------------------------
// Application Issued Register

// Children Selected  Register

// Admission Register in the appropriate entry level class

// Reimbursement Claimed Register.