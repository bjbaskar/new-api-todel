import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { BaseModel } from "../BaseModel";
import { Students } from "./Student";

@Entity("discipline")
export class Discipline extends BaseModel {
	@PrimaryGeneratedColumn()
	id: number;

	// studentid: IStudentModel;

	@Column("varchar", { length: 255, nullable: false })
	discipline: string;

	@Column("timestamp", { nullable: false })
	date: Date;

	@Column("varchar", { length: 500 })
	notes: string;

	// @ManyToOne(type => Students, student => student.discipline)
	// studentid: Students;
}

// === discipline ===
// nails and hair
// shoes and dress
// homework and assignment
// activity and participation
