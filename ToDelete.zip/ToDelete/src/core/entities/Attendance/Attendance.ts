import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToMany,
	ManyToOne
} from "typeorm";
import { ClassSections } from "../Master/ClassSections";
import { Students } from "../../entities/Students/Student";

@Entity("m_attendance")
export class Attendance {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	attdate: Date;

	@ManyToOne(type => ClassSections, cls => cls.id)
	classid: string;

	@ManyToOne(type => Students, stud => stud.id)
	studentid: string;

	@Column("varchar", { length: 12 })
	session: string;

	@Column("boolean", { nullable: false })
	allpresent: boolean;

	@Column("varchar", { length: 255, nullable: true })
	notes: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		nullable: true,
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}

// Store only absentees

// leave reason
// https://www.edsys.in/20-best-attendance-management-app-for-teachers/
// SELECT s.student_id, s.student_name
// ,  CASE WHEN a.id IS NOT NULL THEN 'Absent' ELSE 'Present' END as attendance_status
// FROM Students s
// LEFT JOIN Attendance a on s.student_id=a.student_id AND a.date = '2013-10-24'

// export csv pdf
// https://github.com/mbrn/filefy
// https://github.com/mbrn/material-table/blob/master/src/components/m-table-toolbar.js
// Standard Search box

// DB_HOST="localhost"
// DB_PORT=3306
// USERNAME="root"
// PASSWORD="bb"
// DB_NAME="project1"
// DB_SYNCHRONIZE=true
// DB_LOGGING=false
// DB_DROPSCHEMA=false
// "typeorm": "^0.2.16",