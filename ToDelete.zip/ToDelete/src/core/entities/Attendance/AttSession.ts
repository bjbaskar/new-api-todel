import {
	Entity,
	PrimaryGeneratedColumn,
	Column
} from "typeorm";

@Entity("a_attsession")
export class AttSession {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 5, nullable: false })
	name: string;
}
