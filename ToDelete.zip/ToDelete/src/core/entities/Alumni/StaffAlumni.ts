import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	OneToOne,
	JoinColumn,
	ManyToMany,
	JoinTable,
	OneToMany,
	ManyToOne
} from "typeorm";
import { Subject } from "../Master/Subject";
import { Users } from "../Users/Users";
import { ClassSections } from "../Master/ClassSections";
import { DocsPhotos } from "../DocsPhotos/DocsPhotos";
import { ClassTeacher } from "../Master/ClassTeacher";

@Entity("alumni_staff")
export class StaffAlumni {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("int", { nullable: false })
	staffno: string;

	@Column("int", { nullable: false })
	prefixyear: number;

	@Column("varchar", { length: 50 })
	aadhaarno: string;

	@Column("varchar", { length: 50, nullable: false })
	firstname: string;

	@Column("varchar", { length: 50, nullable: false })
	lastname: string;

	@Column("varchar", { length: 6, nullable: false })
	gender: string;

	@Column("varchar", { length: 25, nullable: false })
	designation: string;

	@Column("timestamp", { nullable: false })
	dob: Date;

	@Column("timestamp", {
		nullable: false,
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	doj: Date;

	@Column("varchar", {
		length: 20,
		default: "Indian"
	})
	nationality: string;

	@Column("varchar", {
		length: 30,
		default: "Hindu"
	})
	religion: string;

	@Column("varchar", { length: 50 })
	castecategory: string;

	@Column("varchar", { length: 50 })
	community: string;

	@Column("varchar", { length: 20 })
	mothertongue: string;

	@Column("varchar", { length: 15 })
	bloodgroup: string;

	@Column("varchar", { length: 500 })
	identification: string;

	@Column("boolean", {
		nullable: false,
		default: () => true
	})
	isactive: boolean;

	@Column("varchar", { length: 500 })
	notes: string;

	@Column("varchar", { length: 1024, nullable: true })
	photo: string;

	@Column("varchar", { length: 500 })
	user: string;

	@Column("varchar", { length: 500 })
	documents: string;

	@Column("varchar", { length: 500 })
	classteacher: string;

	@Column("varchar", { length: 500 })
	classtr: string;

	@Column("varchar", { length: 500 })
	asstclasstr: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;

	@Column("varchar", { nullable: true })
	updatedby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)",
		onUpdate: "CURRENT_TIMESTAMP(2)"
	})
	updatedon: Date;
}