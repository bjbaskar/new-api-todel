import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
} from "typeorm";

@Entity("alumni_students")
export class StudentsAlumni {
	@PrimaryGeneratedColumn("uuid")
	id: string;

	@Column("varchar", { length: 100, nullable: true })
	student_id: string;

	@Column("varchar", { length: 250, nullable: true })
	promoted_to: string;

	@Column("varchar", { length: 250, nullable: true })
	promote_reason: string;

	@Column("varchar", { length: 100, nullable: true })
	classsec: string;

	@Column("simple-json", { nullable: true })
	profile: {
		studentno: number;

		prefixyear: number;

		aadhaarno: string;

		emisno: string;

		udiseno: string;

		firstname: string;

		lastname: string;

		gender: string;

		dob: Date;

		doj: Date;

		nationality: string;

		religion: string;

		castecategory: string;

		community: string;

		mothertongue: string;

		bloodgroup: string;

		identification: string;

		isactive: boolean;

		disability: string;

		notes: string;

		photo: string;
	};

	@Column("simple-json", { nullable: true })
	parents: [{
		fathername: string;
		fatherdob: Date;
		fathergraduation: string;
		fatheroccupation: string;
		fathercompanyname: string;
		fatherincome: number;
		fatheraadhaarno: string;
		mothername: string;
		motherdob: Date;
		mothergraduation: string;
		motheroccupation: string;
		mothercompanyname: string;
		motherincome: number;
		motheraadhaarno: string;
		guardianname: string;
		guardianoccupation: string;
		notes: string;
		address: [{
			type: string;
			address1: string;
			address2: string;
			city: string;
			district: string;
			state: string;
			country: string;
			postalcode: number;
			mobile: string;
			homephone: string;
			email: string;
			notes: string;
		}]
	}];

	@Column("varchar", { length: 100, nullable: true })
	documents: string;

	@Column("simple-json", { nullable: true })
	govtrte: [{
		CWSN: Array<string>;
		amountreceived: number;
		amountdate: Date;
		facilitiesprovided: Array<string>;
		uniformsets: string;
		freetextbook: string;
		freetransport: string;
		notes: string;
	}];

	@Column("varchar", { length: 100, nullable: true })
	acadyear: string;

	@Column("simple-json", { nullable: true })
	school_id: {
		id: string,
		name: string
	};

	@Column("varchar", { length: 100, nullable: true })
	user: string;

	@Column("varchar", { nullable: false })
	createdby: string;

	@Column("timestamp", {
		precision: 2,
		default: () => "CURRENT_TIMESTAMP(2)"
	})
	createdon: Date;
}