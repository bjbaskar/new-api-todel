import { IClass } from "../classsec/IClass";
import { ISubject } from "../subjects/ISubject";

export interface ITextBooks {
	id: string;
	academicyear: string;
	edusystem: string;
	class_section: IClass;
	subject: ISubject;
	bookname: string;
	publisher: string;
	author: string;
	price: number;
	isactive: Boolean;
	booktype: string; // note, book, test note, composition
}
