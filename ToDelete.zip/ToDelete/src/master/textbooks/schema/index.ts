import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const textbookType = typeDef;
const textbookResolver = resolvers;

export { textbookType, textbookResolver };
