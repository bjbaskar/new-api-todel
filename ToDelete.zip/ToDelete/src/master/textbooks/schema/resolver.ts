import { IAppContext } from "../../../context";
import { ITextBooks } from "../ITextBooks";

export const resolvers = {
	Query: {
		async getTextBook(_: any, args: { id: string }, context: IAppContext) {
			const subjService = context.TextBookService;
			return await subjService.findTextBookById(args.id);
		},
		getTextBooks: async (_: any, args: any, context: IAppContext) => {
			return await context.TextBookService.listTextBooks();
		}
	},
	Mutation: {
		async addTextBook(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;

			const res = await context.TextBookService.addTextBook(args.input, currentUser);
			return res;
		},
		async editTextBook(
			root: any,
			args: { id: string; input: ITextBooks },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.TextBookService.editTextBook(args.id, args.input, currentUser);
			return res;
		},
		async delTextBook(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.TextBookService.delTextBook(args.id, currentUser);
			return res;
		}
	}
};
