import { injectable } from "inversify";
import { getManager, getRepository } from "typeorm";
import { ITextBooks } from "./ITextBooks";
import { TextBooks } from "../../core/entities/Master/TextBooks";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class TextBookService {
	constructor() { }

	public async addTextBook(book: ITextBooks, currentUser: string): Promise<any> {
		try {
			const oAdd = Object.assign(new TextBooks(), book);
			oAdd.createdby = currentUser;

			const res = await getRepository(TextBooks).save(oAdd);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editTextBook(id: string, book: ITextBooks, currentUser: string): Promise<any> {
		try {
			const edit = Object.assign(new TextBooks(), book);
			edit.updatedby = currentUser;

			const res = await getManager()
				.getRepository(TextBooks)
				.update(id, edit);

			const resp = await this.findTextBookById(id);
			return resp;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delTextBook(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(TextBooks)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listTextBooks(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(TextBooks)
				.createQueryBuilder("books")
				.leftJoinAndSelect("books.class_section", "class_section")
				.leftJoinAndSelect("books.subject", "subject")
				.orderBy("class_section.name", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findTextBookById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(TextBooks)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findTextBook(name: string, subject: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(TextBooks)
				.createQueryBuilder("books")
				.where("books.subject = :subject OR books.bookname = :name", {
					subject: subject,
					name: name
				})
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
