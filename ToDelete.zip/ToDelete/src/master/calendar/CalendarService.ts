import { injectable, inject } from "inversify";
import { getManager, LessThanOrEqual, MoreThanOrEqual } from "typeorm";
import moment from "moment";

import { ICalendar } from "./ICalendar";
import { Calendar } from "../../core/entities/Master/Calendar";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class CalendarService {
	constructor() { }

	public async addCalendar(calendar: ICalendar, currentUser: string): Promise<any> {
		try {

			const entity = Object.assign(new Calendar(), calendar);
			entity.createdby = currentUser;
			const startFmt = moment(calendar.start).toDate();
			const endFmt = moment(calendar.end).toDate();
			// add(1, "minute").toDate();
			entity.start = startFmt;
			entity.end = endFmt;

			const res = await getManager().getRepository(Calendar).save(entity);
			return res;

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editCalendar(id: string, calendar: ICalendar, currentUser: string): Promise<any> {
		try {
			const edit = Object.assign(new Calendar(), calendar);
			edit.updatedby = currentUser;
			const startFmt = moment(calendar.start).toDate();
			const endFmt = moment(calendar.end).toDate();
			// subtract(1, "minute").toDate();
			edit.start = startFmt;
			edit.end = endFmt;

			const res = await getManager()
				.getRepository(Calendar)
				.update(id, edit);

			if (res.raw.affectedRows > 0) {
				return { Messages: "Updated successfully" };
			} else {
				return { Messages: "No Records Updated" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delCalendar(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(Calendar)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listCalendars(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Calendar)
				.createQueryBuilder("calendar")
				.getMany();
			return res;
		} catch (error) {
			throw new Error(`UnHandledError: ${error}`);
		}
	}

	public async findCalendarById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Calendar)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new Error(`UnHandledError: ${error}`);
		}
	}

	public async getCalendarsByRange(start: Date, end: Date): Promise<any> {
		try {
			try {
				const moreThanDate = (date: Date) => MoreThanOrEqual(moment(start).format("YYYY-MM-DD HH:MM:SS"));
				const lessThanDate = (date: Date) => LessThanOrEqual(moment(end).format("YYYY-MM-DD HH:MM:SS"));

				const res = await getManager()
					.getRepository(Calendar)
					.createQueryBuilder("calendars")
					.where("calendars.fromdate = :fromDate AND calendars.todate = :toDate",
						{
							fromDate: moreThanDate,
							toDate: lessThanDate
						})
					.getMany();
				return res;
			} catch (error) {
				throw new Error(`UnHandledError: ${error}`);
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getTodaysEvents(): Promise<any> {
		try {
			const todaysDate = moment(new Date).format("YYYY-MM-DD");
			const res = await getManager()
				.getRepository(Calendar)
				.createQueryBuilder("cal")
				.where("DATE_FORMAT(cal.start, '%Y-%m-%d') = :fromDate",
					{
						fromDate: todaysDate,
					})
				.select("cal.title, cal.description")
				.getRawMany();
			return res;
		} catch (error) {
			throw new Error(`UnHandledError: ${error}`);
		}
	}
}
