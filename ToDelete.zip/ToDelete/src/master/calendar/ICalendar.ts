export interface ICalendar {
	id: string;
	title: string;
	description: string;
	eventstype: string;
	start: Date;
	end: Date;
	allDay: boolean;
}