import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const calTypeDef = typeDef;
const calResolver = resolvers;

export { calTypeDef, calResolver };
