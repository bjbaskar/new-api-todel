import { gql } from "apollo-server";

export const typeDef = gql`
  extend type Query {
    getCalendar(name: String): Calendar
	 getCalendarsByRange(start: DateTimeType,  end: DateTimeType): [Calendar]
    getCalendars: [Calendar]
	 getTodaysEvents: [Calendar]
  }
  extend type Mutation {
    addCalendar(input: CalendarInput): Calendar
    editCalendar(id: String!, input: CalendarInput): Status
    delCalendar(id: String!): Status
  }
  type Calendar {
		id: String
		title: String
		description: String
		eventstype: String
		start: DateTimeType
		end: DateTimeType
		allDay: Boolean
		createdby: String
		createdon: DateTimeType
		updatedby: String
		updatedon: DateTimeType
  }

  input CalendarInput {
	 title: String
	 description: String
	 eventstype: String
    start: DateTimeType
    end: DateTimeType
	 allDay: Boolean
  }
`;
