import { IAppContext } from "../../../context";
import { ICalendar } from "../ICalendar";

export const resolvers = {
	Query: {
		async getCalendar(_: any, args: { id: string }, context: IAppContext) {
			const calendarSvc = context.CalendarService;
			return calendarSvc.findCalendarById(args.id);
		},
		async  getCalendarsByRange(_: any, args: {
			start: Date, end: Date
		}, context: IAppContext) {
			return context.CalendarService.getCalendarsByRange(args.start, args.end);
		},
		async getCalendars(_: any, args: any, context: IAppContext) {
			// const request = context.RequestHead;
			// const auth = await context.AuthService.getAuthUser(request);
			// if (!auth) {
			// 	throw new Error(`Authentication failed`);
			// }

			return context.CalendarService.listCalendars();
		},
		async getTodaysEvents(_: any, args: any, context: IAppContext) {
			return context.CalendarService.getTodaysEvents();
		}
	},
	Mutation: {
		async addCalendar(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.CalendarService.addCalendar(args.input, currentUser);
			return res;
		},
		async editCalendar(
			root: any,
			args: { id: string, input: ICalendar },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.CalendarService.editCalendar(args.id, args.input, currentUser);
			return res;
		},
		async delCalendar(
			root: any,
			args: { id: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.CalendarService.delCalendar(args.id, currentUser);
			return res;
		}
	}
};
