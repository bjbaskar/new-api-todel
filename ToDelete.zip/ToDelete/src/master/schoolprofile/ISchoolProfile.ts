export interface ISchoolProfile {
	id: string;
	name: string;
	surname: string;
	logo: string;
	sector: string;
	provider: string;
	type: string;
	dateopened: Date;
	recognitiondate: Date;
	address: string;
	postalcode: string;
	district: string;
	taluk: string;
	phone: string;
	mobile: string;
	locality: string;
	latitude: string;
	longitude: string;
	createdby: string;
	createdon: Date;
	updateby: string;
	updatedon: Date;
}