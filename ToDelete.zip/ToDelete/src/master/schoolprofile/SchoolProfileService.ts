import { injectable } from "inversify";
import { getManager } from "typeorm";
import _ from "lodash";

import { ISchoolProfile } from "./ISchoolProfile";
import { SchoolProfile } from "../../core/entities/Master/SchoolProfile";
import { RulesRegulations } from "../../core/entities/Master/RulesRegulations";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class SchoolProfileService {
	constructor() { }

	public async getSchoolProfile(): Promise<any> {
		try {
			const profile = await getManager()
				.getRepository(SchoolProfile)
				.createQueryBuilder("schoolprofile")
				.getOne();

			const rules = await this.getSchoolRules();
			const res = Object.assign({ ...profile }, { rules: rules });

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editSchoolProfile(
		id: string,
		schoolProf: ISchoolProfile,
		currentUser: string): Promise<any> {
		try {

			const prof = Object.assign(new SchoolProfile(), schoolProf);
			prof.updatedby = currentUser;

			const res = await getManager()
				.getRepository(SchoolProfile)
				.update(id, prof);

			const oSchoolProf = await this.getSchoolProfile();
			return oSchoolProf;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async getSchoolRules(): Promise<any> {
		try {
			const rules = await getManager()
				.getRepository(RulesRegulations)
				.createQueryBuilder("rules")
				.getMany();

			const response = _(rules)
				.groupBy(grp => grp.title)
				.map((value, key) => ({
					title: key,
					data: value
				}))
				.orderBy(ord => ord.data.map(d => d.orderby), ["asc"])
				.value();

			return response;

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
