import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const schoolProfileDef = typeDef;
const schoolProfileResolver = resolvers;

export { schoolProfileDef, schoolProfileResolver };
