import { IAppContext } from "../../../context";
import { ISchoolProfile } from "../ISchoolProfile";

export const resolvers = {
	Query: {
		async getSchoolProfile(_: any, args: any, context: IAppContext) {
			const svc = context.SchoolProfileService;
			const res = await svc.getSchoolProfile();
			return res;
		}
	},
	Mutation: {
		async editSchoolProfile(
			root: any,
			args: { id: string, input: ISchoolProfile },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.SchoolProfileService.editSchoolProfile(args.id, args.input, currentUser);
			return res;
		}
	}
};
