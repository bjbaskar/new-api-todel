export interface ISubject {
	id: string;
	name: string;
	subcode: string;
	color: string;
	orderby: number;
}
