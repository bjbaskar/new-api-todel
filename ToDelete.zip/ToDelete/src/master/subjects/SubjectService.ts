import { injectable } from "inversify";
import { getManager, getRepository } from "typeorm";
import { ISubject } from "./ISubject";
import { Subject } from "../../core/entities/Master/Subject";
import { InternalServerError } from "../../core/exceptions";
import { ClassSections } from "../../core/entities/Master/ClassSections";

@injectable()
export class SubjectService {
	constructor() { }

	public async addSubject(subject: ISubject, currentUser: string): Promise<any> {
		try {
			const subjectEntity = Object.assign(new Subject(), subject);
			subjectEntity.createdby = currentUser;

			const res = await getRepository(Subject).save(subjectEntity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editSubject(id: string, subject: ISubject, currentUser: string): Promise<any> {
		try {
			const subjectEntity = Object.assign(new Subject(), subject);
			subjectEntity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(Subject)
				.update(id, subjectEntity);

			const getSubj = await this.findSubjectById(id);
			return getSubj;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delSubject(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(Subject)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listSubject(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Subject)
				.createQueryBuilder("subject")
				.orderBy({
					"subject.orderby": "ASC",
					"subject.name": "ASC"
				})
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	// public async listSubjectByClass(classId: string): Promise<any> {
	// 	try {
	// 		const res = await getManager()
	// 			.getRepository(ClassSections)
	// 			.createQueryBuilder("cls")
	// 			.where("cls.id = :clsId", { clsId: classId })
	// 			.orderBy("subject.name", "ASC")
	// 			.getMany();
	// 		return res;
	// 	} catch (error) {
	// 		throw new InternalServerError("Unhandled Error", error);
	// 	}
	// }

	public async findSubjectById(id: string): Promise<any> {
		try {
			const subjects = await getManager()
				.getRepository(Subject)
				.findOne({ where: { id: id } });
			return subjects;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findSubjects(name: string, code: string): Promise<any> {
		try {
			const subjects = await getManager()
				.getRepository(Subject)
				.createQueryBuilder("subj")
				.where("subj.code = :code OR subj.name = :name", {
					code: code,
					name: name
				})
				.getMany();
			return subjects;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
