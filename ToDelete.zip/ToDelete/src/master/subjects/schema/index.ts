import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const subjTypeDef = typeDef;
const subjResolver = resolvers;

export { subjTypeDef, subjResolver };
