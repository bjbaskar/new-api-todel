import { IAppContext } from "../../../context";
import { ISubject } from "../ISubject";

export const resolvers = {
	Query: {
		async getSubject(_: any, args: { id: string }, context: IAppContext) {
			const subjService = context.SubjectService;
			return await subjService.findSubjectById(args.id);
		},
		async getSubjects(_: any, args: any, context: IAppContext) {
			return await context.SubjectService.listSubject();
		},
		// async getSubjectsByClass(_: any, args: { classId: string }, context: IAppContext) {
		// 	return await context.SubjectService.listSubjectByClass(args.classId);
		// }
	},
	Mutation: {
		async addSubject(root: any, args: { input: ISubject }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;

			const res = await context.SubjectService.addSubject(args.input, currentUser);
			return res;
		},
		async editSubject(
			root: any,
			args: { id: string, input: ISubject },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.SubjectService.editSubject(args.id, args.input, currentUser);
			return res;
		},
		async delSubject(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.SubjectService.delSubject(args.id, currentUser);
			return res;
		}
	}
};
