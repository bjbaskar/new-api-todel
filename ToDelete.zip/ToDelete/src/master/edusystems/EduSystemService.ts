import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IEduSystems } from "./IEduSystems";
import { EduSystems } from "../../core/entities/Master/EduSystems";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class EduSystemService {
	constructor() { }

	public async addEduSystem(eduSys: IEduSystems, currentUser: string): Promise<any> {
		try {
			const eduSysEntity = Object.assign(new EduSystems(), eduSys);
			eduSysEntity.createdby = currentUser;

			const res = await getManager()
				.getRepository(EduSystems)
				.save(eduSysEntity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editEduSystem(id: string, eduSys: IEduSystems, currentUser: string): Promise<any> {
		try {
			const eduSysEntity = Object.assign(new EduSystems(), eduSys);
			eduSysEntity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(EduSystems)
				.update(id, eduSysEntity);

			const resp = await this.findEduSystemById(id);
			return resp;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delEduSystem(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(EduSystems)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listEduSystem(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(EduSystems)
				.createQueryBuilder("edusys")
				.orderBy("edusys.name", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findEduSystemById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(EduSystems)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
