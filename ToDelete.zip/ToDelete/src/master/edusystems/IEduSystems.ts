
export interface IEduSystems {
	id: string;
	name: string;
	levels: string;
}