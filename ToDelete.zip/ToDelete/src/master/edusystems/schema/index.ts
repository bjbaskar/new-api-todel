import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const eduType = typeDef;
const eduResolver = resolvers;

export { eduType, eduResolver };
