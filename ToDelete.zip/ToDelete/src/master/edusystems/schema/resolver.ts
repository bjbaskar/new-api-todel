import { IAppContext } from "../../../context";
import { IEduSystems } from "../IEduSystems";

export const resolvers = {
	Query: {
		async getEduSystem(_: any, args: { id: string }, context: IAppContext) {
			const res = context.EduSystemService;
			return res.findEduSystemById(args.id);
		},
		async getEduSystems(_: any, args: any, context: IAppContext) {
			return context.EduSystemService.listEduSystem();
		}
	},
	Mutation: {
		async addEduSystem(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.EduSystemService.addEduSystem(args.input, currentUser);
			return res;
		},
		async editEduSystem(
			root: any,
			args: { id: string; input: IEduSystems },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.EduSystemService.editEduSystem(
				args.id,
				args.input, currentUser
			);
			return res;
		},
		async delEduSystem(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.EduSystemService.delEduSystem(args.id, currentUser);
			return res;
		}
	}
};
