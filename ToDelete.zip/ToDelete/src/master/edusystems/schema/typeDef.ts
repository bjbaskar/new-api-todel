import { gql } from "apollo-server";

export const typeDef = gql`
    extend type Query {
		getEduSystem(id: String): EduSystem
		getEduSystems: [EduSystem]
    }
    extend type Mutation {
		addEduSystem(input: EduSystemInput): EduSystem
		editEduSystem(id: String!, input: EduSystemInput): EduSystem
		delEduSystem(id: String!): Status
    }
    type EduSystem   {
		id: String
		name: String
		levels: String
		createdby: String
		createdon: DateTimeType
		updatedby: String
		updatedon: DateTimeType
    }

    input EduSystemInput   {
		name: String
		levels: String
    }
`;
