import { IAppContext } from "../../../context";
import { IHoliday } from "../IHoliday";

export const resolvers = {
	Query: {
		async getHoliday(_: any, args: { id: string }, context: IAppContext) {
			const holidaySvc = context.HolidayService;
			return holidaySvc.findHolidayById(args.id);
		},
		async getHolidaysByRange(_: any, args: {
			fromdate: Date, todate: Date
		}, context: IAppContext) {
			return context.HolidayService.getHolidaysByRange(args.fromdate, args.todate);
		},
		async getHolidays(_: any, args: any, context: IAppContext) {
			// const request = context.RequestHead;
			// const auth = await context.AuthService.getAuthUser(request);
			// if (!auth) {
			// 	throw new Error(`Authentication failed`);
			// }

			return context.HolidayService.listHolidays();
		}
	},
	Mutation: {
		async addHoliday(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.HolidayService.addHoliday(args.input, currentUser);
			return res;
		},
		async editHoliday(
			root: any,
			args: { id: string, input: IHoliday },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.HolidayService.editHoliday(args.id, args.input, currentUser);
			return res;
		},
		async delHoliday(
			root: any,
			args: { id: string },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;

			const res = await context.HolidayService.delHoliday(args.id, currentUser);
			return res;
		}
	}
};
