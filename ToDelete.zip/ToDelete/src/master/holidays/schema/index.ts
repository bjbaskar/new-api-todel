import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const holidayTypeDef = typeDef;
const holidayResolver = resolvers;

export { holidayTypeDef, holidayResolver };
