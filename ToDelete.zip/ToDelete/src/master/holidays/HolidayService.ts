import { injectable, inject } from "inversify";
import { getManager, LessThanOrEqual, MoreThanOrEqual } from "typeorm";
import moment from "moment";

import { IHoliday } from "./IHoliday";
import { Holiday } from "../../core/entities/Master/Holiday";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class HolidayService {
	constructor() { }

	public async addHoliday(holiday: IHoliday, currentUser: string): Promise<any> {
		try {

			const entity = Object.assign(new Holiday(), holiday);
			entity.createdby = currentUser;

			const res = await getManager().getRepository(Holiday).save(entity);
			return res;

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editHoliday(id: string, holiday: IHoliday, currentUser: string): Promise<any> {
		try {
			const edit = Object.assign(new Holiday(), holiday);
			edit.updatedby = currentUser;

			const res = await getManager()
				.getRepository(Holiday)
				.update(id, edit);

			if (res.raw.affectedRows > 0) {
				return { Messages: "Updated successfully" };
			} else {
				return { Messages: "No Records Updated" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delHoliday(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(Holiday)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listHolidays(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Holiday)
				.createQueryBuilder("holiday")
				.orderBy("holiday.fromdate", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new Error(`UnHandledError: ${error}`);
		}
	}

	public async findHolidayById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Holiday)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new Error(`UnHandledError: ${error}`);
		}
	}

	public async getHolidaysByRange(fromdate: Date, todate: Date): Promise<any> {
		try {
			try {
				const moreThanDate = (date: Date) => MoreThanOrEqual(moment(fromdate).format("YYYY-MM-DD HH:MM:SS"));
				const lessThanDate = (date: Date) => LessThanOrEqual(moment(todate).format("YYYY-MM-DD HH:MM:SS"));

				const res = await getManager()
					.getRepository(Holiday)
					.createQueryBuilder("holidays")
					.where("holidays.fromdate = :fromDate AND holidays.todate = :toDate",
						{
							fromDate: moreThanDate,
							toDate: lessThanDate
						})
					.getMany();
				// .where("subj.code = :code OR subj.name = :name", {
				// 	code: code,
				// 	name: name
				// })
				// .where({ fromdate: moreThanDate })
				// .andWhere({ todate: lessThanDate })
				return res;
			} catch (error) {
				throw new Error(`UnHandledError: ${error}`);
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
