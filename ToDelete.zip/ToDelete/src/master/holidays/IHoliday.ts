export interface IHoliday {
	occasion: string;
	description: string;
	holidaytype: string;
	fromdate: Date;
	fdayofweek: string;
	todate: Date;
	tdayofweek: string;
	comments: string;
	status: boolean;
}
