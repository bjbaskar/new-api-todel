import { ISubject } from "../subjects/ISubject";
import { IStaff } from "../../staff/IStaff";
import { IStudent } from "../../students/IStudent";

export interface IClass {
	id: string;
	name: string;
	section: string;
	orderby: number;
	isactive: boolean;
	academicyear: string;
	asstclassteacher: string;
	edusystem: string;
	textbook: string;
	classteacher: string;

	subjects: ISubject[];
	teachers: IStaff[];
	students: IStudent[];

	is_final_year: boolean;
}

export interface IClassSubject {
	classId: string;
	subjectId: [string];
}

export interface IClassStaff {
	classteacher: string;
	asstclassteacher: string;
	subj_staff: ISubjectStaff[];
}
interface ISubjectStaff {
	subjectId: string;
	staffId: string;
}