import { injectable } from "inversify";
import { getManager, getConnection, In, QueryRunner, EntityManager } from "typeorm";
import { IClass, IClassSubject, IClassStaff } from "./IClass";
import { ClassSections } from "../../core/entities/Master/ClassSections";
import { BadRequest, BadMapping, InternalServerError } from "../../core/exceptions";

import _ from "lodash";
import { ClassTeacher } from "../../core/entities/Master/ClassTeacher";
import { Subject } from "../../core/entities/Master/Subject";

@injectable()
export class ClassService {
	constructor() { }

	public async addClassSec(classSec: IClass, subjectIds: [string], currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const classSecEntity = Object.assign(new ClassSections(), classSec);
			classSecEntity.createdby = currentUser;

			const classSaved = await queryRunner.manager
				.getRepository(ClassSections)
				.save(classSecEntity);

			const classSubj: IClassSubject = {
				classId: classSaved.id,
				subjectId: subjectIds
			};

			const res = await this.addSubjectToClass(classSubj, queryRunner.manager);
			await queryRunner.commitTransaction();

			if (res) {
				return { Messages: "Class & Subject added successfully" };
			} else {
				return { Messages: "No Records updated" };
			}

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async editClassSec(id: string, classSec: IClass, subjectIds: [string], currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			const classSecEntity = Object.assign(new ClassSections(), classSec);
			classSecEntity.updatedby = currentUser;

			await queryRunner.manager
				.getRepository(ClassSections)
				.update(id, classSecEntity);

			const classSubj: IClassSubject = {
				classId: id,
				subjectId: subjectIds
			};

			const res = await this.editSubjectToClass(classSubj, queryRunner.manager);
			await queryRunner.commitTransaction();

			if (res) {
				return { Messages: "Class & Subject updated successfully" };
			} else {
				return { Messages: "No Records updated" };
			}

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("Unhandled Error", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	public async delClassSec(id: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(ClassSections)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getAllClass(): Promise<any> {
		try {
			const classSecs = await getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("classSec")
				// .leftJoinAndMapMany("classSec.classteacher", ClassTeacher, "ct", "ct.classes = classSec.id")
				.leftJoinAndSelect("classSec.classteachersub", "ct")
				.leftJoinAndSelect("ct.subject", "subjects")
				.leftJoinAndSelect("ct.staff", "staff")
				.leftJoinAndSelect("classSec.classteacher", "classteacher")
				.leftJoinAndSelect("classSec.asstclassteacher", "asstclassteacher")
				// .leftJoinAndMapMany("classteacher.subject", qb => qb.from(Subject, "sub"), "sub", "sub.id = ct.subject")
				.leftJoinAndSelect("classSec.edusystem", "edusystem")
				.leftJoinAndSelect("classSec.academicyear", "academicyear")
				// .select(["subjects.id", "subjects.name"])
				.orderBy({
					"classSec.orderby": "ASC",
					"classSec.name": "ASC",
					"classSec.section": "ASC",
				})
				.getMany();
			return classSecs;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findClassSecById(id: string): Promise<any> {
		// .select([
		// 	"classSec.id", "classSec.name", "classSec.section",
		// 	"classSec.createdby", "classSec.createdon", "classSec.updatedby", "classSec.updatedon",
		// 	"edusystem.id", "edusystem.name", "edusystem.levels",
		// 	"academicyear.id", "academicyear.displayname"])
		// .addSelect(["subjects.id", "subjects.name"])
		try {
			const classSecs = await getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("classSec")
				.leftJoinAndSelect("classSec.subjects", "subjects")
				.where("classSec.id = :classId", { classId: id })
				.getOne();
			return classSecs;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async editSubjectToClass(classSubj: IClassSubject, queryRunner: EntityManager): Promise<any> {
		try {
			const classId = classSubj.classId;
			const subjId = classSubj.subjectId;
			// let subjDelRes: boolean = false;

			if (classId.length === 0 || !subjId.length || !subjId[0].length) {
				throw new BadRequest("Please select Class and Subject");
			}

			try {
				await getManager()
					.createQueryBuilder()
					.delete()
					.from(ClassTeacher)
					.where("classes = :id", { id: classId })
					.execute();

			} catch (error) {
				throw new InternalServerError("Class Subject Delete Error:", error);
			}

			const clsSubjects: ClassTeacher[] = [];
			for (let i = 0; i <= subjId.length - 1; i++) {
				const sub = new ClassTeacher();
				sub.classes = classId;
				sub.subject = subjId[i];
				sub.staff = undefined;
				clsSubjects.push(sub);
			}

			const result = await queryRunner
				.getRepository(ClassTeacher)
				.save(clsSubjects);
			return result;

		}
		catch (error) {
			throw new InternalServerError("Class Subject Assigning Error:", error);
		}
	}

	private async addSubjectToClass(classSubj: IClassSubject, queryRunner: EntityManager): Promise<any> {
		try {
			const classId = classSubj.classId;
			const subjId = classSubj.subjectId;

			if (classId.length === 0 || !subjId.length || !subjId[0].length) {
				throw new BadRequest("Please select Class and Subject");
			}

			const clsSubjects: ClassTeacher[] = [];
			for (let i = 0; i <= subjId.length - 1; i++) {
				const sub = new ClassTeacher();
				sub.classes = classId;
				sub.subject = subjId[i];
				sub.staff = undefined;
				clsSubjects.push(sub);
			}

			const result = await queryRunner
				.getRepository(ClassTeacher)
				.save(clsSubjects);
			return result;

			// const res = await queryRunner
			// 	.getRepository(ClassSections)
			// 	.createQueryBuilder()
			// 	.relation(ClassSections, "subjects")
			// 	.of(classId)
			// 	.add(subjId)
			// 	.then(res => {
			// 		return { Messages: "Subjects are assigned to the Class" };
			// 	})
			// 	.catch(err => {
			// 		throw new BadMapping(
			// 			"Class and Subject mapping does not match. Please select Class and Subject"
			// 		);
			// 	});
		} catch (error) {
			throw error;
		}
	}

	public async setupClassSubjRemove(classSubj: IClassSubject): Promise<any> {
		try {
			const classId = classSubj.classId;
			const subjId = classSubj.subjectId;

			if (classId.length === 0 || !subjId.length || !subjId[0].length) {
				throw new BadRequest("Please select Class and Subject");
			}

			const res = await getManager()
				.getRepository(ClassSections)
				.createQueryBuilder()
				.relation(ClassSections, "subjects")
				.of(classId)
				.remove(subjId)
				.then(res => {
					return { Messages: "Subjects are removed from the Class" };
				})
				.catch(err => {
					throw new BadMapping(
						"Class and Subject Mapping not match. Please select Class and Subject"
					);
				});
			return res;
		} catch (error) {
			throw error;
		}
	}

	public async addStaffToClass(id: string, input: IClassStaff, currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();
		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			let res_main;
			if (input.classteacher || input.asstclassteacher) {
				res_main = await queryRunner.manager
					.createQueryBuilder()
					.update(ClassSections)
					.set({
						classteacher: input.classteacher,
						asstclassteacher: input.asstclassteacher,
						updatedby: currentUser
					})
					.where("id = :id", {
						id: id
					})
					.execute();
			}

			// console.log(res_main);

			const res = await this.assignStaffToClass(id, input, queryRunner.manager);

			await queryRunner.commitTransaction();

			if (res) {
				return { Messages: "Subjects are assigned to the Class" };
			}
			else {
				return { Messages: "Error: Staff has not assigned to the selected Class" };
			}

		} catch (error) {
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addStaffToClass - Unhandled Error", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	private async assignStaffToClass(classId: string, clsStaff: IClassStaff, queryRunner: EntityManager): Promise<any> {
		try {
			const subj_staff = clsStaff.subj_staff;
			let result;
			if (classId.length === 0) {
				throw new BadRequest("Please select Class");
			}

			for (let i = 0; i <= subj_staff.length - 1; i++) {
				result = await queryRunner
					.createQueryBuilder()
					.update(ClassTeacher)
					.set({ staff: subj_staff[i].staffId })
					.where("classes = :id", {
						id: classId
					})
					.andWhere("subject = :subId", {
						subId: subj_staff[i].subjectId
					})
					.execute();
			}
			return result;
		}
		catch (error) {
			throw error;
		}
	}
}
