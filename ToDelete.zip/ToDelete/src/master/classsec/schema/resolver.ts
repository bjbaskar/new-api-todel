import { IAppContext } from "../../../context";
import { IClass, IClassSubject, IClassStaff } from "../IClass";

export const resolvers = {
	Query: {
		async getClass(_: any, args: { id: string }, context: IAppContext) {
			const subjService = context.ClassService;
			return subjService.findClassSecById(args.id);
		},
		getAllClass: async (_: any, args: any, context: IAppContext) => {
			return context.ClassService.getAllClass();
		}
	},
	Mutation: {
		async addClassSection(root: any, args: { input: IClass, subjectIds: [string] }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ClassService.addClassSec(args.input, args.subjectIds, currentUser);
			return res;
		},
		async editClassSection(
			root: any,
			args: { id: string, input: IClass, subjectIds: [string] },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ClassService.editClassSec(args.id, args.input, args.subjectIds, currentUser);
			return res;
		},
		async delClassSection(
			root: any,
			args: { id: string },
			context: IAppContext
		) {
			const res = await context.ClassService.delClassSec(args.id);
			return res;
		},
		async addStaffToClass(root: any,
			args: { id: string, input: IClassStaff },
			context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.ClassService.addStaffToClass(args.id, args.input, currentUser);
			return res;
		}
	}
};
