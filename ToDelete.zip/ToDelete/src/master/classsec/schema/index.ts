import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const classTypeDef = typeDef;
const classResolver = resolvers;

export { classTypeDef, classResolver };
