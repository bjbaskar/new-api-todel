export interface IDataConfig {
	id: string;
	name: string;
	value: string;
}
