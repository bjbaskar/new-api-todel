import { IAppContext } from "../../../context";
import { IDataConfig } from "../IDataConfig";

export const resolvers = {
	Query: {
		async getDataconfig(_: any, args: { filter: string }, context: IAppContext) {
			const dataService = context.DataConfigService;
			return await dataService.findDataConfigById(args.filter);
		},
		async getAllDataconfigs(_: any, args: any, context: IAppContext) {
			return await context.DataConfigService.listDataConfig();
		},
		async getCaste(_: any, args: any, context: IAppContext) {
			return await context.DataConfigService.getCaste();
		}
	},
	Mutation: {
		async addDataConfig(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.DataConfigService.addDataConfig(args.input, currentUser);
			return res;
		},
		async editDataConfig(
			root: any,
			args: { id: string; input: IDataConfig },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.DataConfigService.editDataConfig(
				args.id,
				args.input,
				currentUser
			);
			return res;
		},
		async delDataConfig(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.DataConfigService.delDataConfig(args.id, currentUser);
			return res;
		}
	}
};
