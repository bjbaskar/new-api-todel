import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const dConfigTypeDef = typeDef;
const dConfigResolver = resolvers;

export { dConfigTypeDef, dConfigResolver };
