import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IDataConfig } from "./IDataConfig";
import { DataConfig } from "../../core/entities/Master/DataConfig";
import { Caste } from "../../core/entities/Master/Caste";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class DataConfigService {
	constructor() { }

	public async addDataConfig(dataConfig: IDataConfig, currentUser: string): Promise<any> {
		try {
			const dataConfigEntity = Object.assign(new DataConfig(), dataConfig);

			const res = await getManager()
				.getRepository(DataConfig)
				.save(dataConfigEntity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editDataConfig(
		id: string,
		dataConfig: IDataConfig,
		currentUser: string
	): Promise<any> {
		try {

			const dataConfigEntity = Object.assign(new DataConfig(), dataConfig);

			const res = await getManager()
				.getRepository(DataConfig)
				.update(id, dataConfigEntity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delDataConfig(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(DataConfig)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listDataConfig(): Promise<any> {
		try {

			const res = await getManager()
				.getRepository(DataConfig)
				.createQueryBuilder("dconfig")
				.orderBy("dconfig.name", "ASC")
				.addOrderBy("dconfig.value", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getCaste(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(Caste)
				.createQueryBuilder("caste")
				.orderBy("caste.name", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findDataConfigById(filter: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(DataConfig)
				.createQueryBuilder("d")
				.orderBy("d.value", "ASC")
				.where("name = :filter", { filter: filter })
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}


}
