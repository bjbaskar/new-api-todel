import { IAppContext } from "../../../context";
import { IAcadYear } from "../IAcadYear";

export const resolvers = {
	Query: {
		async getAcadYear(_: any, args: { id: string }, context: IAppContext) {
			const subjService = context.AcadYearService;
			return subjService.findAcadYearById(args.id);
		},
		async getAcadYears(_: any, args: any, context: IAppContext) {
			return context.AcadYearService.listAcadYear();
		},
		async getNextAcadYear(_: any, args: any, context: IAppContext) {
			return context.AcadYearService.getNextAcadYear();
		},
		async getAcadYearByCurrent(_: any, args: { displayName: String }, context: IAppContext) {
			return context.AcadYearService.getAcadYearByCurrent();
		}
	},
	Mutation: {
		async addAcadYear(root: any, args: any, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AcadYearService.addAcadYear(args.input, currentUser);
			return res;
		},
		async editAcadYear(
			root: any,
			args: { id: string; input: IAcadYear },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AcadYearService.editAcadYear(
				args.id,
				args.input,
				currentUser
			);
			return res;
		},
		async delAcadYear(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.AcadYearService.delAcadYear(args.id, currentUser);
			return res;
		}
	}
};
