import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const aYearTypeDef = typeDef;
const aYearResolver = resolvers;

export { aYearTypeDef, aYearResolver };
