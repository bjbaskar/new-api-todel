
export interface IAcadYear {
	id: string;
	fromdate: Date;
	todate: Date;
	displayname: string;
	prefixyear: number;
	is_current: boolean;
	is_next: boolean;
}
