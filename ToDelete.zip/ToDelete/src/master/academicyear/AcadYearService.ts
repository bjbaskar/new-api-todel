import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IAcadYear } from "./IAcadYear";
import { AcadYear } from "../../core/entities/Master/AcadYear";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class AcadYearService {
	constructor() { }

	public async addAcadYear(acadYr: IAcadYear, currentUser: string): Promise<any> {
		try {
			const acadYrEntity = Object.assign(new AcadYear(), acadYr);
			acadYrEntity.createdby = currentUser;

			const res = await getManager().getRepository(AcadYear).save(acadYrEntity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editAcadYear(id: string, acadYr: IAcadYear, currentUser: string): Promise<any> {
		try {
			const acadYrEntity = Object.assign(new AcadYear(), acadYr);
			acadYrEntity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(AcadYear)
				.update(id, acadYrEntity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delAcadYear(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(AcadYear)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listAcadYear(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(AcadYear)
				.createQueryBuilder("acdyear")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getNextAcadYear(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(AcadYear)
				.createQueryBuilder("a")
				.where("a.is_current = true")
				.orWhere("a.is_next = true")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getAcadYearByCurrent(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(AcadYear)
				.createQueryBuilder("a")
				.where("a.is_current = true")
				.getOne();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findAcadYearById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(AcadYear)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
