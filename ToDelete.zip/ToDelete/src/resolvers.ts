import { makeExecutableSchema } from "apollo-server";
import { GraphQLScalarType } from "graphql";
import { Kind } from "graphql/language";
import { GraphQLUpload } from "graphql-upload";

import { merge } from "lodash";

import DateTimeType from "./common/GraphqlDate";

import { userTypeDef, userResolver } from "./users/schema";
import { roleTypeDef, roleResolver } from "./userroles/schema";

import { dConfigTypeDef, dConfigResolver } from "./master/dataconfig/schema";

import { schoolProfileDef, schoolProfileResolver } from "./master/schoolprofile/schema";
import { aYearTypeDef, aYearResolver } from "./master/academicyear/schema";
import { eduType, eduResolver } from "./master/edusystems/schema";
import { subjTypeDef, subjResolver } from "./master/subjects/schema";
import { classTypeDef, classResolver } from "./master/classsec/schema";
import { textbookType, textbookResolver } from "./master/textbooks/schema";
import { holidayTypeDef, holidayResolver } from "./master/holidays/schema";
import { calTypeDef, calResolver } from "./master/calendar/schema";

import { studentTypeDef, studentResolver } from "./students/schema";
import { staffTypeDef, staffResolver } from "./staff/schema";

import { uploadTypeDef, uploadResolver } from "./uploads/schema";

import { dashBoardTypeDef, dashBoardResolver } from "./dashboard/schema";
import { attendanceTypeDef, attendanceResolver } from "./attendance/schema";
import { assignTypeDef, assignResolver } from "./assignment/schema";

import { examTypeDef, examResolver } from "./exams/schema";

import { feedbackTypeDef, feedbackResolver } from "./feedback/schema";

import { feeParticularsType, feeParticularsResolver } from "./fee/feeparticulars/schema";
import { feeInstallmentsType, feeInstallmentsResolver } from "./fee/feeinstallments/schema";
import { feeMasterType, feeMasterResolver } from "./fee/feemaster/schema";
import { feeStudentConfigType, feeStudentConfigResolver } from "./fee/feestudentconfig/schema";
import { feeTransType, feeTransResolver } from "./fee/feetransaction/schema";
import { feeDiscountType, feeDiscountResolver } from "./fee/feediscount/schema";


const upScalartypeDefs = `
  scalar Upload
`;
const upScalarResolvers = {
	Upload: GraphQLUpload
};

const BaseQuery = `
	scalar DateTimeType
	type Query {
	_: Boolean
	}
	type Mutation {
	_: Boolean
	}
`;

const allTypeDefs = [
	BaseQuery,
	userTypeDef,
	roleTypeDef,

	schoolProfileDef,
	aYearTypeDef,
	eduType,
	subjTypeDef,
	classTypeDef,
	textbookType,
	dConfigTypeDef,

	holidayTypeDef,
	calTypeDef,

	studentTypeDef,
	staffTypeDef,

	upScalartypeDefs,
	uploadTypeDef,

	dashBoardTypeDef,
	attendanceTypeDef,

	assignTypeDef,

	examTypeDef,

	feedbackTypeDef,

	feeParticularsType,
	feeInstallmentsType,
	feeMasterType,
	feeStudentConfigType,
	feeTransType,
	feeDiscountType
];
const allResolvers = merge(
	{},
	userResolver,
	roleResolver,

	schoolProfileResolver,
	aYearResolver,
	eduResolver,
	subjResolver,
	classResolver,
	textbookResolver,
	dConfigResolver,

	holidayResolver,
	calResolver,

	studentResolver,
	staffResolver,

	upScalarResolvers,
	uploadResolver,

	dashBoardResolver,
	attendanceResolver,

	assignResolver,

	examResolver,

	feedbackResolver,

	feeParticularsResolver,
	feeInstallmentsResolver,
	feeMasterResolver,
	feeStudentConfigResolver,
	feeTransResolver,
	feeDiscountResolver
);

export default makeExecutableSchema({
	typeDefs: allTypeDefs,
	resolvers: allResolvers
});
