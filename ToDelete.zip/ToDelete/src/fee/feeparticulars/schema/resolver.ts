import { IAppContext } from "../../../context";
import { IFeeParticulars } from "../IFeeParticulars";

export const resolvers = {
	Query: {
		async getFeeParticulars(_: any, args: { id: string }, context: IAppContext) {
			const svc = context.FeeParticularService;
			return await svc.findFeeParticularsById(args.id);
		},
		async getAllFeeParticulars(_: any, args: any, context: IAppContext) {
			return await context.FeeParticularService.listFeeParticulars();
		}
	},
	Mutation: {
		async addFeeParticulars(root: any, args: { input: IFeeParticulars }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeParticularService.addFeeParticulars(args.input, currentUser);
			return res;
		},
		async editFeeParticulars(
			root: any,
			args: { id: string, input: IFeeParticulars },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeParticularService.editFeeParticulars(args.id, args.input, currentUser);
			return res;
		},
		async delFeeParticulars(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeParticularService.delFeeParticulars(args.id, currentUser);
			return res;
		}
	}
};
