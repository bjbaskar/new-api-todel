import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feeParticularsType = typeDef;
const feeParticularsResolver = resolvers;

export { feeParticularsType, feeParticularsResolver };
