export interface IFeeParticulars {
	id: string;
	name: string;
	description: string;
	acad_year: string;
	school_id: string;
}