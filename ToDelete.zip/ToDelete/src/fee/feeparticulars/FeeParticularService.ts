import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IFeeParticulars } from "./IFeeParticulars";
import { FeeParticulars } from "../../core/entities/Fee/FeeParticulars";
import { InternalServerError } from "../../core/exceptions";
import { FeeMaster } from "../../core/entities/Fee/FeeMaster";
import { FeeRegisterDetails } from "../../core/entities/Fee/FeeRegisterDetails";

@injectable()
export class FeeParticularService {
	constructor() { }

	public async addFeeParticulars(feeParticulars: IFeeParticulars, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeParticulars(), feeParticulars);
			entity.createdby = currentUser;

			const res = await getManager()
				.getRepository(FeeParticulars)
				.save(entity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editFeeParticulars(id: string, feeParticulars: IFeeParticulars, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeParticulars(), feeParticulars);
			entity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(FeeParticulars)
				.update(id, entity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delFeeParticulars(id: string, currentUser: string): Promise<any> {
		try {

			let is_found: boolean = false;

			const find_in_master = await getManager()
				.getRepository(FeeMaster)
				.createQueryBuilder("fm")
				.where("fm.fee_particulars_id = :p_id")
				.setParameter("p_id", id)
				.getMany();

			if (find_in_master.length) {
				is_found = true;
				throw new InternalServerError("Fee Particulars found in Class Fee setup. Please delete from Fee Class inorder to delete this record");
			}

			await getManager()
				.getRepository(FeeRegisterDetails)
				.createQueryBuilder("frd")
				.leftJoin(FeeMaster, "fm", "frd.fee_master_id = fm.id")
				.leftJoin(FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.where("fp.id = :p_id")
				.setParameter("p_id", id)
				.getMany()
				.then(async (d) => {
					if (d.length > 0) {
						throw new InternalServerError("Fee Particulars found in Fee Register setup. Please delete from Fee Register inorder to delete this record");
					} else {
						const res = await getManager()
							.createQueryBuilder()
							.delete()
							.from(FeeParticulars)
							.where("id = :id", { id: id })
							.execute();
						if (res.affected >= 1) {
							return { Messages: "Deleted successfully" };
						} else {
							return { Messages: "No Records Deleted" };
						}
					}
				});

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listFeeParticulars(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeParticulars)
				.createQueryBuilder("fh")
				.orderBy("fh.name", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findFeeParticularsById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeParticulars)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
