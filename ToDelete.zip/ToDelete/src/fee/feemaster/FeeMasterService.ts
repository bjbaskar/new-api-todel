import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IFeeMaster } from "./IFeeMaster";
import { FeeMaster } from "../../core/entities/Fee/FeeMaster";
import { ClassSections } from "../../core/entities/Master/ClassSections";
import { FeeInstallments } from "../../core/entities/Fee/FeeInstallments";
import { FeeParticulars } from "../../core/entities/Fee/FeeParticulars";
import { InternalServerError } from "../../core/exceptions";
import { FeeRegister } from "../../core/entities/Fee/FeeRegister";

@injectable()
export class FeeMasterService {
	constructor() { }

	public async addFeeMaster(feeMaster: IFeeMaster, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeMaster(), feeMaster);
			entity.createdby = currentUser;

			let result: any = undefined;

			const validate = await this.validate(feeMaster);

			if (validate > 0) {
				throw new Error(`Duplicate Error! Class / Fee Installments / Fee Particulars Already found.`);
			} else {
				result = await getManager()
					.getRepository(FeeMaster)
					.save(entity);
			}
			return result;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editFeeMaster(id: string, feeMaster: IFeeMaster, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeMaster(), feeMaster);
			entity.updatedby = currentUser;

			const result = await getManager()
				.createQueryBuilder()
				.update(FeeMaster)
				.set({
					due_date: entity.due_date,
					amount: entity.amount,
					is_required_to_all: entity.is_required_to_all,
					is_refundable: entity.is_refundable,
					isactive: entity.isactive,
					updatedby: currentUser
				})
				.where("id = :id", { id: id })
				.execute();

			return result;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delFeeMaster(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(FeeMaster)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listFeeMaster(class_id: string): Promise<any> {
		try {
			const qb = getManager()
				.getRepository(FeeMaster)
				.createQueryBuilder("fm")
				.leftJoinAndMapOne("fm.class_id", ClassSections, "class_sec", "class_sec.id = fm.class_id")
				.leftJoinAndMapOne("fm.fee_particulars_id", FeeParticulars, "fh", "fh.id = fm.fee_particulars_id")
				.leftJoinAndMapOne("fm.fee_installments_id", FeeInstallments, "fsr", "fsr.id = fm.fee_installments_id")
				.orderBy("class_sec.orderby", "ASC")
				.addOrderBy("fh.name", "ASC")
				.addOrderBy("fm.amount", "DESC");

			if (class_id !== "ALL") {
				qb.where("class_sec.id = :class_id", { class_id: class_id });
			}

			const res = await qb.getMany();
			return res;

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async getFilterFeeMaster(class_id: string, student_id: string): Promise<any> {
		try {
			const q_main = getManager()
				.getRepository(FeeMaster)
				.createQueryBuilder("fm")
				.select([
					"cl.id AS class_id",
					"st.id AS student_id",

					"fm.id AS fee_master_id",
					"fm.amount AS amount",
					"fm.due_date AS due_date",

					"fp.id AS fee_particulars_id",
					"fp.name AS particulars_name",

					"fi.id AS fee_installments_id",
					"fi.fee_period AS fee_period",
					"fi.term_name AS term_name",
					"fi.no_of_months AS no_of_months",
					"fi.term_month_names AS term_month_names",
					"fi.from_date AS from_date",
					"fi.to_date AS to_date",

					"fm.is_required_to_all AS is_required_to_all",
					"fm.is_refundable AS is_refundable",
					"fm.isactive AS isactive",

					"reg.amount_balance AS amount_balance"
				])
				.addSelect(
					`CASE
						WHEN reg.is_paid_fully = true THEN "FULLY_PAID"
						WHEN reg.is_paid_fully = false THEN "PARTIALLY_PAID"
						ELSE "NOT_PAID"
					END`, "paid_status"
				)
				.leftJoinAndMapOne("fm.class_id", ClassSections, "cl", "cl.id = fm.class_id")
				.leftJoin("cl.students", "st")
				.leftJoinAndMapOne("fm.fee_particulars_id", FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.leftJoinAndMapOne("fm.fee_installments_id", FeeInstallments, "fi", "fi.id = fm.fee_installments_id")
				.leftJoin(subQry => {
					const qb = subQry
						.select([
							"r.class_id AS class_id",
							"r.student_id AS student_id",
							"r_dt.is_paid_fully AS is_paid_fully",
							"r_dt.fee_master_id AS fee_master_id",
							"r_dt.amount_balance AS amount_balance",
						])
						.from(FeeRegister, "r")
						.leftJoin("r.fee_reg_details", "r_dt")
						.where("r.class_id = :classId");
					// .andWhere("r.student_id = :studentId");
					return qb;
				}, "reg",
					`reg.fee_master_id = fm.id
					AND reg.class_id = cl.id
					AND reg.student_id = st.id`)
				.where("cl.id = :classId")
				.orderBy("cl.orderby", "ASC")
				.addOrderBy("fp.name", "ASC")
				.addOrderBy("fm.amount", "DESC")
				.getQuery();

			const result = await getManager()
				.createQueryBuilder()
				.select("res.*")
				.from("(" + q_main + ")", "res")
				.where("res.paid_status != 'FULLY_PAID'")
				.andWhere("res.student_id = :studentId")
				.setParameter("classId", class_id)
				.setParameter("studentId", student_id)
				.getRawMany();

			return result;
		} catch (error) {
			throw new InternalServerError("getFilterFeeMaster: ", error);
		}
	}

	private async validate(entity: IFeeMaster): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeMaster)
				.createQueryBuilder("f")
				.where("f.class_id = :class_id", { class_id: entity.class_id })
				.andWhere("f.fee_particulars_id = :fee_particulars_id", { fee_particulars_id: entity.fee_particulars_id })
				.andWhere("f.fee_installments_id = :fee_installments_id", { fee_installments_id: entity.fee_installments_id })
				.getCount();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
