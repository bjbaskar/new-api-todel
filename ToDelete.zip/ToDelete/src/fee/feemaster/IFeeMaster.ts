export interface IFeeMaster {
	id: string;
	class_id: string;
	fee_particulars_id: string;
	fee_installments_id: string;
	due_date: Date;
	amount: number;
	is_required_to_all: boolean;
	is_refundable: boolean;
	isactive: boolean;
	acad_year: string;
	school_id: string;
}