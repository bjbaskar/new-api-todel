import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feeMasterType = typeDef;
const feeMasterResolver = resolvers;

export { feeMasterType, feeMasterResolver };
