import { IAppContext } from "../../../context";
import { IFeeMaster } from "../IFeeMaster";

export const resolvers = {
	Query: {
		async getFeeMaster(_: any, args: { class_id: string, student_id: string }, context: IAppContext) {
			const svc = context.FeeMasterService;
			return await svc.getFilterFeeMaster(args.class_id, args.student_id);
		},
		async getAllFeeMaster(_: any, args: { class_id: string }, context: IAppContext) {
			return await context.FeeMasterService.listFeeMaster(args.class_id);
		}
	},
	Mutation: {
		async addFeeMaster(root: any, args: { input: IFeeMaster }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeMasterService.addFeeMaster(args.input, currentUser);
			return res;
		},
		async editFeeMaster(
			root: any,
			args: { id: string, input: IFeeMaster },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeMasterService.editFeeMaster(args.id, args.input, currentUser);
			return res;
		},
		async delFeeMaster(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeMasterService.delFeeMaster(args.id, currentUser);
			return res;
		}
	}
};
