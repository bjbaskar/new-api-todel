import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feeDiscountType = typeDef;
const feeDiscountResolver = resolvers;

export { feeDiscountType, feeDiscountResolver };
