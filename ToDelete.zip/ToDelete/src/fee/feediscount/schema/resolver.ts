import { IAppContext } from "../../../context";
import { IFeeDiscount } from "../IFeeDiscount";

export const resolvers = {
	Query: {
		async getFeeDiscount(_: any, args: { id: string }, context: IAppContext) {
			const svc = context.FeeDiscountService;
			return await svc.findFeeDiscountById(args.id);
		},
		async getAllFeeDiscount(_: any, args: any, context: IAppContext) {
			return await context.FeeDiscountService.listFeeDiscount();
		}
	},
	Mutation: {
		async addFeeDiscount(root: any, args: { input: IFeeDiscount }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeDiscountService.addFeeDiscount(args.input, currentUser);
			return res;
		},
		async editFeeDiscount(
			root: any,
			args: { id: string, input: IFeeDiscount },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeDiscountService.editFeeDiscount(args.id, args.input, currentUser);
			return res;
		},
		async delFeeDiscount(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeDiscountService.delFeeDiscount(args.id, currentUser);
			return res;
		}
	}
};
