export interface IFeeDiscount {
	id: string;
	class_sec: string;
	student_id: string;
	fee_class: string;
	discount_reason: string;
	discount_perc: number;
	amount_discount: number;
	acad_year: string;
	school_id: string;
}