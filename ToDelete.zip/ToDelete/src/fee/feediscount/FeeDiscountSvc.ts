import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IFeeDiscount } from "./IFeeDiscount";
import { FeeDiscount } from "../../core/entities/Fee/FeeDiscount";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class FeeDiscountService {
	constructor() { }

	public async addFeeDiscount(feeHead: IFeeDiscount, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeDiscount(), feeHead);
			entity.createdby = currentUser;

			const res = await getManager()
				.getRepository(FeeDiscount)
				.save(entity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editFeeDiscount(id: string, feeHead: IFeeDiscount, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeDiscount(), feeHead);
			entity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(FeeDiscount)
				.update(id, entity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delFeeDiscount(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(FeeDiscount)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listFeeDiscount(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeDiscount)
				.createQueryBuilder("fh")
				.orderBy("fh.name", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findFeeDiscountById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeDiscount)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
