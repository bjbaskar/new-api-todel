import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IFeeInstallments } from "./IFeeInstallments";
import { FeeInstallments } from "../../core/entities/Fee/FeeInstallments";
import { InternalServerError } from "../../core/exceptions";
import moment from "moment";

@injectable()
export class FeeInstallmentService {
	constructor() { }

	public async addFeeInstallments(feeInstallment: IFeeInstallments, currentUser: string): Promise<any> {
		try {
			let result: IFeeInstallments | IFeeInstallments[];
			const entity = Object.assign(new FeeInstallments(), feeInstallment);

			const validate = await this.validateFeePeriod(entity.fee_period, entity.term_name);
			if (validate > 0) {
				throw new InternalServerError("Fee Period already found. Please try another");
			}

			const instArray: IFeeInstallments[] = [];
			if (entity.fee_period === "Monthly Fee") {
				for await (const itr of entity.term_month_names) {
					const newInst: IFeeInstallments = new FeeInstallments();

					const fDate = await this.getYearMonth(itr);
					const tDateMn = moment(fDate).endOf("month").toDate();
					const tDate = moment(tDateMn).subtract(1, "days").toDate();

					newInst.fee_period = entity.fee_period;
					newInst.term_name = itr;
					// newInst.monthly_month_name = itr;
					newInst.term_month_names = [itr];
					newInst.no_of_months = 1;
					newInst.from_date = moment(fDate).startOf("month").toDate();
					newInst.to_date = tDate;
					newInst.acad_year = entity.acad_year;
					newInst.school_id = entity.school_id;
					newInst.createdby = currentUser;
					instArray.push(newInst);
				}

				result = await getManager()
					.getRepository(FeeInstallments)
					.save(instArray);
			} else {
				entity.createdby = currentUser;
				result = await getManager()
					.getRepository(FeeInstallments)
					.save(entity);
			}

			return result;

		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async getYearMonth(str: string): Promise<any> {
		try {
			const options = [
				{ value: 0, label: "Jan" },
				{ value: 1, label: "Feb" },
				{ value: 2, label: "Mar" },
				{ value: 3, label: "Apr" },
				{ value: 4, label: "May" },
				{ value: 5, label: "Jun" },
				{ value: 6, label: "Jul" },
				{ value: 7, label: "Aug" },
				{ value: 8, label: "Sep" },
				{ value: 9, label: "Oct" },
				{ value: 10, label: "Nov" },
				{ value: 11, label: "Dec" },
			];

			const s = str.split("-");
			if (s.length && s.length === 2) {
				const filterData = options.filter((x) => x.label === s[0]);
				const val = filterData.map(d => d.value)[0];
				return [Number(s[1]), Number(val)];
			}
			else {
				return [];
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	private async validateFeePeriod(fee_period: string, term_name: string): Promise<any> {
		try {
			if (fee_period === "Monthly Fee") {
			}
			const res = await getManager()
				.getRepository(FeeInstallments)
				.createQueryBuilder("fi")
				.where("fi.fee_period =:feePeriod", { feePeriod: fee_period })
				.andWhere("fi.term_name =:tName", { tName: term_name })
				.getCount();

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}


	public async editFeeInstallments(id: string, feeInstallment: IFeeInstallments, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeInstallments(), feeInstallment);
			entity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(FeeInstallments)
				.update(id, entity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delFeeInstallments(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(FeeInstallments)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listFeeInstallments(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeInstallments)
				.createQueryBuilder("fr")
				.orderBy("fr.fee_period", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findFeeInstallmentsById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeInstallments)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
