export interface IFeeInstallments {
	id: string;
	fee_period: string;
	term_name: string;
	// is_monthly_fee: boolean;
	// is_one_time_fee: boolean;
	// monthly_month_name: string;
	term_month_names: [string];
	no_of_months: number;
	from_date: Date;
	to_date: Date;
	acad_year: string;
	school_id: string;
	createdby: string;
	updatedby: string;
}