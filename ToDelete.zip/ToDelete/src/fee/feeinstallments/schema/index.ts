import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feeInstallmentsType = typeDef;
const feeInstallmentsResolver = resolvers;

export { feeInstallmentsType, feeInstallmentsResolver };
