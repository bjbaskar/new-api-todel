import { IAppContext } from "../../../context";
import { IFeeInstallments } from "../IFeeInstallments";

export const resolvers = {
	Query: {
		async getFeeInstallments(_: any, args: { id: string }, context: IAppContext) {
			const svc = context.FeeInstallmentService;
			return await svc.findFeeInstallmentsById(args.id);
		},
		async getAllFeeInstallments(_: any, args: any, context: IAppContext) {
			return await context.FeeInstallmentService.listFeeInstallments();
		}
	},
	Mutation: {
		async addFeeInstallments(root: any, args: { input: IFeeInstallments }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeInstallmentService.addFeeInstallments(args.input, currentUser);
			return res;
		},
		async editFeeInstallments(
			root: any,
			args: { id: string, input: IFeeInstallments },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeInstallmentService.editFeeInstallments(args.id, args.input, currentUser);
			return res;
		},
		async delFeeInstallments(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeInstallmentService.delFeeInstallments(args.id, currentUser);
			return res;
		}
	}
};
