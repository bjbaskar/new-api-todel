import { injectable, inject } from "inversify";
import { getManager, getConnection, EntityManager } from "typeorm";
import { IFeeDailyTransaction, IFeeRegister, IFeeParams, IFeeDetails } from "./IFeeTrans";
import { FeeTransaction } from "../../core/entities/Fee/FeeTransaction";
import { InternalServerError, NotFound } from "../../core/exceptions";
import { FeeMaster } from "../../core/entities/Fee/FeeMaster";
import { FeeRegister } from "../../core/entities/Fee/FeeRegister";
import { FeeRegisterDetails } from "../../core/entities/Fee/FeeRegisterDetails";
import { ClassSections } from "../../core/entities/Master/ClassSections";
import { FeeParticulars } from "../../core/entities/Fee/FeeParticulars";
import { FeeInstallments } from "../../core/entities/Fee/FeeInstallments";
import { Students } from "../../core/entities/Students/Student";
import moment from "moment";
import _ from "lodash";
import shortid from "shortid";

import { IFeeMaster } from "../feemaster/IFeeMaster";
import { IFeeHeader, IFeeReceipt } from "./IReceipt";
import { FeeTransactionRptSvc } from "./FeeTransactionRptSvc";

@injectable()
export class FeeTransactionService extends FeeTransactionRptSvc {

	private PARAMS: IFeeParams;

	constructor() {
		super();
		this.PARAMS = {
			receipt_no: undefined,
			class_id: "",
			student_id: "",
			pay_mode: "",
			paydate: new Date(),
			trans_id: ""
		};
	}

	public async addFeeTrans(feeTrans: IFeeRegister, currentUser: string): Promise<any> {
		const connection = getConnection();
		const queryRunner = connection.createQueryRunner();

		try {
			await queryRunner.connect();
			await queryRunner.startTransaction();

			// let blnResult: boolean = false;
			// const class_id = feeTrans.class_id;
			// const student_id = feeTrans.student_id;
			this.PARAMS.class_id = feeTrans.class_id;
			this.PARAMS.student_id = feeTrans.student_id;
			this.PARAMS.pay_mode = feeTrans.pay_mode;
			this.PARAMS.receipt_no = await this.getReceiptNo(queryRunner.manager);
			this.PARAMS.paydate = feeTrans.paydate;
			this.PARAMS.trans_id = await this.generateId(queryRunner.manager);

			// ----- add to fee_transaction table -----

			if (!feeTrans || !feeTrans.fee_details) {
				throw new NotFound("Fee Details cannot be empty.");
			}

			const addToReg = await this.addFeeRegister(
				queryRunner.manager,
				feeTrans,
				currentUser
			);


			// const fee_details = feeTrans.fee_details;
			// const feeTransArray: Array<any> = [];

			// for await (const d of fee_details) {
			// 	if (d.amount_paid > 0) {
			// 		const eTr: IFeeDailyTransaction = {} as IFeeDailyTransaction;
			// 		eTr.paydate = d.paydate;
			// 		eTr.class_id = this.PARAMS.class_id;
			// 		eTr.student_id = this.PARAMS.student_id;
			// 		eTr.fee_master_id = d.fee_master_id;
			// 		eTr.pay_mode = this.PARAMS.pay_mode;
			// 		eTr.amount_paid = d.amount_paid;
			// 		eTr.receipt_no = this.PARAMS.receipt_no;
			// 		eTr.receipt_duplicate = 0;
			// 		eTr.iscancel = false;
			// 		eTr.cancel_reason = "";
			// 		eTr.fee_trans_id = this.PARAMS.trans_id;
			// 		eTr.acad_year = feeTrans.acad_year;
			// 		eTr.school_id = feeTrans.school_id;
			// 		eTr.createdby = currentUser;

			// 		feeTransArray.push(eTr);
			// 	}
			// }

			// const res = await queryRunner.manager
			// 	.createQueryBuilder()
			// 	.insert()
			// 	.into(FeeTransaction)
			// 	.values(feeTransArray)
			// 	.execute()
			// 	.then(async (r) => {

			// 		// ----- add to fee_register and fee_register_details -----

			// 		const addToReg = await this.addFeeRegister(
			// 			queryRunner.manager,
			// 			feeTrans,
			// 			currentUser
			// 		);

			// 		blnResult = addToReg;
			// 	})
			// 	.catch(async (error) => {
			// 		blnResult = false;
			// 		throw new InternalServerError("Unable to save", error);
			// 	});

			await queryRunner.commitTransaction();

			return {
				receipt_no: this.PARAMS.receipt_no
			};

		} catch (error) {
			console.log("error: ", error);
			await queryRunner.rollbackTransaction();
			throw new InternalServerError("addFeeTrans: ", error);
		}
		finally {
			await queryRunner.release();
		}
	}

	private async addFeeRegister(
		queryRunner: EntityManager,
		feeTrans: IFeeRegister,
		currentUser: string
	): Promise<any> {
		try {
			let blnResult: boolean = false;

			let regIsFound: FeeRegister = await this.checkFeeRegister(queryRunner);

			const frEntity = new FeeRegister();

			frEntity.paydate = feeTrans.paydate;
			frEntity.class_id = feeTrans.class_id;
			frEntity.student_id = feeTrans.student_id;
			frEntity.acad_year = feeTrans.acad_year;
			frEntity.school_id = feeTrans.school_id;
			frEntity.createdby = currentUser;

			// frEntity.fee_reg_details = feeDetails;
			const feeDetails = feeTrans.fee_details;

			const t_amount_payable = _.sumBy(feeDetails, "amount_payable");
			const t_amount_discount = _.sumBy(feeDetails, "amount_discount");
			let t_amount_paid = _.sumBy(feeDetails, "amount_paid");
			let t_amount_balance = 0; // _.sumBy(feeDetails, "amount_balance");

			if (regIsFound) {
				t_amount_paid = regIsFound.total_amount_paid + t_amount_paid;
				frEntity.total_amount_paid = t_amount_paid;

				t_amount_balance = (t_amount_payable) - (t_amount_paid);
				frEntity.total_amount_balance = t_amount_balance;
			} else {
				frEntity.total_amount_paid = t_amount_paid;

				t_amount_balance = t_amount_payable - t_amount_paid;
				frEntity.total_amount_balance = t_amount_balance;
			}

			frEntity.total_amount_payable = t_amount_payable;
			frEntity.total_amount_discount = t_amount_discount;

			if (!regIsFound) {
				await queryRunner
					.getRepository(FeeRegister)
					.save(frEntity)
					.then(async (res) => {
						regIsFound = res;

						await this.addFeeRegisterDetails(
							queryRunner,
							feeTrans,
							regIsFound,
							currentUser
						);

						blnResult = true;
					})
					.catch(async (error) => {
						blnResult = false;
						throw new InternalServerError("addFeeRegister Unable to add", error);
					});
			} else {
				await queryRunner
					.createQueryBuilder()
					.update(FeeRegister)
					.set({
						paydate: feeTrans.paydate,
						total_amount_payable: t_amount_payable,
						total_amount_discount: t_amount_discount,
						total_amount_paid: t_amount_paid,
						total_amount_balance: t_amount_balance,
						updatedby: currentUser
					})
					.where("class_id = :classId")
					.andWhere("student_id = :studentId")
					.setParameter("classId", this.PARAMS.class_id)
					.setParameter("studentId", this.PARAMS.student_id)
					.execute()
					.then(async (r) => {

						await this.addFeeRegisterDetails(
							queryRunner,
							feeTrans,
							regIsFound,
							currentUser
						);

						blnResult = true;
						console.log(r);
					})
					.catch((error: any) => {
						blnResult = false;
						throw new InternalServerError("addFeeRegister Unable to update", error);
					});
			}

			return blnResult;
		} catch (error) {
			throw new InternalServerError("checkFeeRegister", error);
		}
	}

	private async addFeeRegisterDetails(
		queryRunner: EntityManager,
		feeTrans: IFeeRegister,
		feeReg: FeeRegister,
		currentUser: string): Promise<any> {
		try {

			if (!feeReg) {
				throw new InternalServerError("addFeeRegisterDetails: unable to find FeeRegister record !");
			}

			let blnResult: boolean = false;

			const fee_details = feeTrans.fee_details;

			for await (const d of fee_details) {

				if (Number(d.amount_paid) > 0) {

					const fee_master_id = d.fee_master_id;

					const dtIsFound: FeeRegisterDetails = await this.checkFeeRegisterDetails(
						queryRunner,
						fee_master_id
					);

					const fDt = new FeeRegisterDetails();

					fDt.paydate = d.paydate;
					fDt.fee_master_id = fee_master_id;
					fDt.pay_mode = d.pay_mode;
					fDt.fee_register_id = feeReg;
					fDt.receipt_no = this.PARAMS.receipt_no;
					fDt.createdby = currentUser;

					fDt.amount_payable = d.amount_payable;
					fDt.amount_discount = d.amount_discount;

					let AMT_PAID = d.amount_paid;
					if (dtIsFound) {
						AMT_PAID = dtIsFound.amount_paid + AMT_PAID;
					}
					fDt.amount_paid = AMT_PAID;

					const bal = Number(d.amount_payable) - Number(AMT_PAID);
					fDt.amount_balance = bal;

					if (Number(d.amount_payable) === Number(AMT_PAID)) {
						fDt.is_paid_fully = true;
					} else if (Number(d.amount_payable) > Number(AMT_PAID)) {
						fDt.is_paid_fully = false;
					} else if (Number(d.amount_payable) < Number(AMT_PAID)) {
						fDt.is_paid_fully = true;
					}

					fDt.fee_trans_id = this.PARAMS.trans_id;

					if (!dtIsFound) {
						await queryRunner
							.getRepository(FeeRegisterDetails)
							.save(fDt)
							.then(async (r) => {
								blnResult = true;
							})
							.catch(async (error) => {
								blnResult = false;
								throw new InternalServerError("addFeeRegister details Unable to add", error);
							});

					} else {
						await queryRunner
							.createQueryBuilder()
							.update(FeeRegisterDetails)
							.set({
								paydate: fDt.paydate,
								pay_mode: fDt.pay_mode,
								amount_payable: fDt.amount_payable,
								amount_discount: fDt.amount_discount,
								amount_paid: fDt.amount_paid,
								amount_balance: fDt.amount_balance,
								is_paid_fully: fDt.is_paid_fully,
								receipt_no: fDt.receipt_no,
								fee_trans_id: this.PARAMS.trans_id,
								updatedby: currentUser
							})
							.where("id = :dtId")
							.setParameter("dtId", dtIsFound.id)
							.execute()
							.then(async (r) => {

								console.log(r);
								blnResult = true;

							})
							.catch((error) => {
								blnResult = false;
								throw new InternalServerError("addFeeRegister details Unable to update", error);
							});
					}

					// add to fee_transaction table with amount_paid and balance amount
					const eTr: IFeeDailyTransaction = {} as IFeeDailyTransaction;
					eTr.paydate = new Date();
					eTr.class_id = this.PARAMS.class_id;
					eTr.student_id = this.PARAMS.student_id;
					eTr.fee_master_id = d.fee_master_id;
					eTr.pay_mode = this.PARAMS.pay_mode;
					eTr.amount_paid = d.amount_paid;
					eTr.amount_balance = bal;
					eTr.receipt_no = this.PARAMS.receipt_no;
					eTr.receipt_duplicate = 0;
					eTr.iscancel = false;
					eTr.cancel_reason = "";
					eTr.fee_trans_id = this.PARAMS.trans_id;
					eTr.acad_year = feeTrans.acad_year;
					eTr.school_id = feeTrans.school_id;
					eTr.createdby = currentUser;

					// feeTransArray.push(eTr);

					await queryRunner
						.createQueryBuilder()
						.insert()
						.into(FeeTransaction)
						.values(eTr)
						.execute()
						.then((r) => {
							blnResult = true;
						});
				}

			}

			return blnResult;
		} catch (error) {
			throw new InternalServerError("addFeeRegisterDetails", error);
		}
	}

	private async checkFeeRegister(
		queryRunner: EntityManager): Promise<FeeRegister> {
		try {

			const result = await queryRunner
				.getRepository(FeeRegister)
				.createQueryBuilder("fr")
				.where("fr.class_id = :classId")
				.andWhere("fr.student_id = :studentId")
				.setParameter("classId", this.PARAMS.class_id)
				.setParameter("studentId", this.PARAMS.student_id)
				.getOne();

			return result;
		} catch (error) {
			throw new InternalServerError("checkFeeRegister:", error);
		}
	}

	private async checkFeeRegisterDetails(
		queryRunner: EntityManager,
		fee_master_id: string): Promise<FeeRegisterDetails> {
		try {

			const result = await queryRunner
				.getRepository(FeeRegisterDetails)
				.createQueryBuilder("frd")
				.leftJoin("frd.fee_register_id", "fee_reg")
				.where("fee_reg.class_id = :classId")
				.andWhere("fee_reg.student_id = :studentId")
				.andWhere("frd.fee_master_id = :feeMasterId")
				.setParameter("classId", this.PARAMS.class_id)
				.setParameter("studentId", this.PARAMS.student_id)
				.setParameter("feeMasterId", fee_master_id)
				.getOne();

			return result;
		} catch (error) {
			throw new InternalServerError("checkFeeRegister", error);
		}
	}

	private async generateId(queryRunner: EntityManager): Promise<any> {
		try {

			const TRANS_ID: string = shortid.generate();

			const result = await queryRunner
				.getRepository(FeeTransaction)
				.createQueryBuilder("ft")
				.where("ft.fee_trans_id = :transId")
				.setParameter("transId", TRANS_ID)
				.getCount();

			if (result === 0) {
				return TRANS_ID;
			} else {
				return this.generateId(queryRunner);
			}
		} catch (error) {
			throw new InternalServerError("checkFeeRegister", error);
		}
	}

	private async getReceiptNo(queryRunner: EntityManager): Promise<any> {
		try {

			const result = await queryRunner
				.getRepository(FeeTransaction)
				.createQueryBuilder("ft")
				.select("MAX(ft.receipt_no) AS receipt_no")
				.orderBy("ft.receipt_no", "DESC")
				.getRawOne();

			const prefix_receipt_no: string = (moment().format("MM"));
			let receipt_no: string = "0";

			if (!result.receipt_no) {
				receipt_no = prefix_receipt_no + "" + 1;
			}
			else if (result.receipt_no && result.receipt_no !== 0) {
				const prx_r = Number(result.receipt_no.toString().substring(0, 2));
				const len_rn = result.receipt_no.toString().length;
				const sx_r = Number(result.receipt_no.toString().substring(2, len_rn));
				const newNo = Number(sx_r) + 1;

				if (prx_r === Number(prefix_receipt_no)) {
					receipt_no = prefix_receipt_no + "" + newNo;
				} else {
					receipt_no = prefix_receipt_no + "" + 1;
				}
			} else {
				receipt_no = prefix_receipt_no + "" + 1;
			}

			return Number(receipt_no);
		} catch (error) {
			throw new InternalServerError("getReceiptNo", error);
		}
	}

	public async getFeeReceipt(
		class_id: string,
		student_id: string,
		paydate: Date,
		receipt_no: number): Promise<any> {
		try {
			const p_paydate = moment(paydate).format("YYYY-MM-DD");

			// get receipt for the fee payment
			const getTransQuery = getManager()
				.getRepository(FeeTransaction)
				.createQueryBuilder("ft")
				.select([
					"class_sec.id AS class_id",
					"CONCAT(class_sec.name, ' - ', class_sec.section) AS class_name",
					"stud.id AS student_id",
					"CONCAT(stud.firstname, ' ', stud.lastname) AS student_name",
					"stud.studentno AS studentno",
					"pr.fathername AS fathersname",
					"adrs.address1 AS address1",
					"adrs.address2 AS address2",
					"adrs.city AS city",
					"adrs.district AS district",
					"adrs.postalcode AS postalcode",
					"adrs.mobile AS mobile",

					"fm.id AS fee_master_id",
					"fm.due_date AS due_date",
					"fm.amount AS payable_amount",

					"ft.amount_paid AS amount_paid",
					"ft.receipt_no AS receipt_no",
					"ft.paydate AS paydate",
					"ft.pay_mode AS pay_mode",
					"ft.createdby AS createdby",
					"ft.createdon AS createdon",
					"ft.updatedby AS updatedby",
					"ft.updatedon AS updatedon",

					"fp.name AS particulars_name",
					"fi.id AS install_id",
					"fi.fee_period AS fee_period",
					"fi.term_name AS term_name",
					"fi.no_of_months AS no_of_months"
				])
				.leftJoinAndMapMany("ft.fee_master_id", FeeMaster, "fm", "ft.fee_master_id = fm.id")
				.leftJoinAndMapOne("fm.class_id", ClassSections, "class_sec", "class_sec.id = fm.class_id")
				.leftJoinAndSelect("class_sec.students", "stud")
				.leftJoinAndSelect("stud.parents", "pr")
				.leftJoinAndSelect("pr.address", "adrs")
				.leftJoinAndMapOne("fm.fee_particulars_id", FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.leftJoinAndMapOne("fm.fee_installments_id", FeeInstallments, "fi", "fi.id = fm.fee_installments_id")
				.where("fm.class_id = :classId")
				.andWhere("stud.id = :studentId")
				.andWhere("DATE_FORMAT(ft.paydate, '%Y-%m-%d') = :payDate")
				.andWhere("ft.receipt_no = :receiptNo")
				.setParameter("classId", class_id)
				.setParameter("studentId", student_id)
				.setParameter("payDate", p_paydate)
				.setParameter("receiptNo", receipt_no);
			// .setParameter("receiptNo", 10);
			// .andWhere("fr.acad_year = :acadYear", { acadYear: acad_year})
			// .andWhere("fr.school_id = :schoolId", { schoolId: school_id})

			const getData = await getTransQuery.getRawMany();

			const getBal = await getManager()
				.getRepository(FeeRegister)
				.createQueryBuilder("fr")
				.where("fr.class_id = :classId")
				.andWhere("fr.student_id = :studentId")
				.setParameter("classId", class_id)
				.setParameter("studentId", student_id)
				.getOne();

			const getAmtPaid = _.sumBy(getData, "amount_paid");
			const getBalData = {
				total_amount_paid: getAmtPaid,
				total_amount_balance: getBal.total_amount_balance
			};

			const result: Array<IFeeReceipt> = _.chain(getData)
				.groupBy("student_id")
				.map((value, key) => {

					let keyValue: string = undefined;
					const feeDetailsArr: any = [];
					let header: any = {};

					_.map(value, o => {

						const feeDt = _.pick(o, [
							"paid_status",
							"particulars_name",
							"fee_period",
							"term_name",
							"no_of_months",
							"amount_discount",
							"amount_paid",
							"is_paid_fully",
							"due_date"
						]);

						feeDetailsArr.push(feeDt);

						if (key !== keyValue) {
							keyValue = o.student_id;
							header = _.pick(o, [
								"class_id",
								"class_name",
								"student_id",
								"studentno",
								"student_name",
								"fathersname",
								"address1",
								"address2",
								"city",
								"district",
								"postalcode",
								"mobile",
								"paydate",
								"pay_mode",
								"receipt_no",
								"acad_year",
								"school_id",
								"createdby",
								"createdon",
								"updatedby",
								"updatedon"
							]);
						}
					});

					header = Object.assign({ ...header, ...getBalData });

					const oResult: IFeeReceipt = {
						id: (key),
						fee_register: header,
						fee_details: feeDetailsArr,
						acad_year: "acadyear",
						school_id: "schoolid"
					};
					return oResult;
				})
				.value();

			const finalResult = result.length ? result[0] : result;
			return finalResult;
		} catch (error) {
			throw new InternalServerError("getFeeReceipt: ", error);
		}
	}

	public async getPriorBalance(class_id: string, student_id: string): Promise<any> {
		try {
			const todayDueDate = moment().format("YYYY-MM-DD");

			const regSelectedCols = [
				"r.total_amount_payable AS total_amount_payable",
				"r.total_amount_discount AS total_amount_discount",
				"r.total_amount_paid AS total_amount_paid",
				"r.total_amount_balance AS total_amount_balance",

				"reg_dt.paydate AS paydate",
				"reg_dt.fee_register_id AS fee_register_id",
				"reg_dt.fee_master_id AS fee_master_id",
				"reg_dt.pay_mode AS pay_mode",
				"reg_dt.amount_payable AS amount_payable",
				"reg_dt.amount_discount AS amount_discount",
				"reg_dt.amount_paid AS amount_paid",
				"reg_dt.amount_balance AS amount_balance",
				"reg_dt.is_paid_fully AS is_paid_fully",
				"reg_dt.receipt_no AS receipt_no",
				"reg_dt.createdby AS createdby",
				"reg_dt.updatedby AS updatedby",
			];

			// student who has NOT paid, PARTIALLY paid the fee for the due date
			const getPriorBal = await getManager()
				.getRepository(FeeMaster)
				.createQueryBuilder("fm")
				.select([
					"class_sec.id AS class_id",
					"class_sec.name AS class_name",
					"stud.id AS student_id",
					"stud.firstname AS student_name",
					"fm.id AS fee_master_id",
					"fm.due_date AS due_date",
					"fm.amount AS payable_amount",

					"reg.amount_discount AS amount_discount",
					"reg.amount_paid AS amount_paid",
					"reg.amount_balance AS amount_balance",
					"reg.is_paid_fully AS is_paid_fully",

					"fp.name AS particulars_name",
					"fi.id AS install_id",
					"fi.fee_period AS fee_period",
					"fi.term_name AS term_name",
					"fi.no_of_months AS no_of_months",
					"fi.from_date AS from_date",
					"fi.to_date AS to_date",

					"reg.total_amount_payable AS total_amount_payable",
					"reg.total_amount_discount AS total_amount_discount",
					"reg.total_amount_paid AS total_amount_paid",
					"reg.total_amount_balance AS total_amount_balance"
				])
				.addSelect(
					`CASE
						WHEN reg.is_paid_fully = true THEN reg.amount_payable
						WHEN reg.is_paid_fully = false THEN reg.amount_payable
						ELSE fm.amount
					END`, "amount_payable"
				)
				.addSelect(
					`CASE
						WHEN reg.is_paid_fully = true THEN "FULLY_PAID"
						WHEN reg.is_paid_fully = false THEN "PARTIALLY_PAID"
						ELSE "NOT_PAID"
					END`, "paid_status"
				)
				.leftJoinAndMapOne("fm.class_id", ClassSections, "class_sec", "class_sec.id = fm.class_id")
				.leftJoinAndSelect("class_sec.students", "stud")
				.leftJoinAndMapOne("fm.fee_particulars_id", FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.leftJoinAndMapOne("fm.fee_installments_id", FeeInstallments, "fi", "fi.id = fm.fee_installments_id")
				.leftJoin(subQry => {
					const qb = subQry
						.select(regSelectedCols)
						.from(FeeRegister, "r")
						.leftJoinAndSelect("r.fee_reg_details", "reg_dt")
						.where("r.class_id = :classId")
						.andWhere("r.student_id = :studentId");
					return qb;
				}, "reg", "reg.fee_master_id = fm.id")
				.where("fm.class_id = :classId")
				.andWhere("stud.id = :studentId")
				.andWhere("DATE_FORMAT(fm.due_date, '%Y-%m-%d') <= :dueDate")
				.setParameter("classId", class_id)
				.setParameter("studentId", student_id)
				.setParameter("dueDate", todayDueDate)
				// .andWhere("fr.acad_year = :acadYear", { acadYear: acad_year})
				// .andWhere("fr.school_id = :schoolId", { schoolId: school_id})
				.getRawMany();

			// filter to get partially paid and not paid students
			const result = getPriorBal.filter((d) => d.paid_status !== "FULLY_PAID"); // _.unionBy(getMasterData, getPriorBal, "fee_master_id");

			// Sum of Register and Register_Details
			const r_total_payable = _.sumBy(result, "amount_payable");
			const r_total_discount = _.sumBy(
				result,
				"amount_discount"
			);
			const r_total_paid = "0.00"; // _.sumBy(result, "amount_paid");
			const r_total_balance = _.sumBy(result, "amount_balance");

			const totals = {
				total_amount_payable: r_total_payable,
				total_amount_discount: r_total_discount,
				total_amount_paid: r_total_paid,
				total_amount_balance: r_total_balance,
			};

			const finalResult: any = {
				fee_data: result,
				totals: totals
			};

			return finalResult;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editFeeTrans(id: string, feeHead: IFeeRegister, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeTransaction(), feeHead);
			entity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(FeeTransaction)
				.update(id, entity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delFeeTrans(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(FeeTransaction)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

}
