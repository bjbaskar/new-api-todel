export interface IFeeDetails {
	id: string;
	paid_status: string;
	particulars_name: string;
	fee_period: string;
	term_name: string;
	no_of_months: string;
	amount_payable: number;
	amount_discount: number;
	amount_paid: number;
	amount_balance: number;
	is_paid_fully: boolean;
	receipt_no: number;
	due_date: Date;
	createdby: string;
	updatedby: string;
}

export interface IFeeHeader {
	id: string;
	paydate: Date;
	class_id: string;
	class_name: string;
	student_id: string;
	student_name: string;
	pay_mode: string;
	total_amount_payable: number;
	total_amount_discount: number;
	total_amount_paid: number;
	total_amount_balance: number;
	acad_year: string;
	school_id: string;
	createdby: string;
	createdon: Date;
	updatedby: string;
	updatedon: Date;
}

export interface IFeeReceipt {
	id: string;
	fee_register: IFeeHeader;
	fee_details: Array<IFeeDetails>;
	acad_year: "acadyear";
	school_id: "schoolid";
}