import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feeTransType = typeDef;
const feeTransResolver = resolvers;

export { feeTransType, feeTransResolver };
