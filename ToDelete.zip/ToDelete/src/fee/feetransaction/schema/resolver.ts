import { IAppContext } from "../../../context";
import { IFeeRegister } from "../IFeeTrans";

export const resolvers = {
	Query: {
		async getPriorBalance(_: any, args: { class_id: string, student_id: string }, context: IAppContext) {
			const result = await context.FeeTransactionService.getPriorBalance(args.class_id, args.student_id);
			return result;
		},
		async getFeeReceipt(_: any, args: {
			class_id: string,
			student_id: string,
			paydate: Date,
			receipt_no: number
		}, context: IAppContext) {
			const result = await context.FeeTransactionService.getFeeReceipt(
				args.class_id,
				args.student_id,
				args.paydate,
				args.receipt_no);
			return result;
		},
		async getTransWidgetRpt(_: any, args: {
			from_date: Date,
			to_date: Date
		}, context: IAppContext) {
			const result = await context.FeeTransactionService.getTransWidgetRpt(
				args.from_date,
				args.to_date
			);
			return result;
		},
		async getClasswiseFeeRpt(_: any, args: {
			class_id: string,
			from_date: Date,
			to_date: Date,
			rpt_type: string,
			particulars_id: string,
			installments_id: string
		}, context: IAppContext) {
			const result = await context.FeeTransactionService.getClassFeeReport(
				args.class_id,
				args.from_date,
				args.to_date,
				args.rpt_type,
				args.particulars_id,
				args.installments_id
			);
			return result;
		},
		async getFeeSummaryReport(_: any, args: {}, context: IAppContext) {
			const result = await context.FeeTransactionService.getFeeSummaryReport();
			return result;
		},

		async getStudentInvoice(_: any, args: {
			class_id: string,
			student_id: string,
			from_date: Date,
			to_date: Date,
		}, context: IAppContext) {
			const result = await context.FeeTransactionService.getStudentInvoice(
				args.class_id,
				args.student_id,
				args.from_date,
				args.to_date,
			);
			return result;
		},

		async getTransactionReport(_: any, args: {
			class_id: string,
			from_date: Date,
			to_date: Date
		}, context: IAppContext) {
			const result = await context.FeeTransactionService.getTransactionReport(
				args.class_id,
				args.from_date,
				args.to_date,
			);
			return result;
		}

	},
	Mutation: {
		async addFeeTransaction(root: any, args: { input: IFeeRegister }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeTransactionService.addFeeTrans(args.input, currentUser);
			return res;
		},
		async editFeeTransaction(
			root: any,
			args: { id: string, input: IFeeRegister },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeTransactionService.editFeeTrans(args.id, args.input, currentUser);
			return res;
		},
		async delFeeTransaction(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeTransactionService.delFeeTrans(args.id, currentUser);
			return res;
		}
	}
};
