import { injectable } from "inversify";
import {
	getManager,
	EntityManager
} from "typeorm";
import _ from "lodash";
import moment from "moment";

import { InternalServerError } from "../../core/exceptions";
import { FeeTransaction } from "../../core/entities/Fee/FeeTransaction";
import { ITransWidgetReport } from "./IFeeReports";
import { FeeRegister } from "../../core/entities/Fee/FeeRegister";
import { FeeMaster } from "../../core/entities/Fee/FeeMaster";
import { FeeRegisterDetails } from "../../core/entities/Fee/FeeRegisterDetails";
import { Students } from "../../core/entities/Students/Student";
import { ClassSections } from "../../core/entities/Master/ClassSections";
import { FeeParticulars } from "../../core/entities/Fee/FeeParticulars";
import { FeeInstallments } from "../../core/entities/Fee/FeeInstallments";

@injectable()
export class FeeTransactionRptSvc {

	constructor() {
	}

	public async getTransWidgetRpt(fromDate: Date, toDate: Date): Promise<ITransWidgetReport> {
		try {

			const result: ITransWidgetReport = {} as ITransWidgetReport;

			let f_paydate = moment().format("YYYY-MM-DD");
			let t_paydate = moment().format("YYYY-MM-DD");

			if (fromDate) {
				f_paydate = moment(fromDate).format("YYYY-MM-DD");
			}
			if (toDate) {
				t_paydate = moment(toDate).format("YYYY-MM-DD");
			}

			// to get daily transaction cash memo for the selected date range or today's date
			const daily_tr = await getManager()
				.getRepository(FeeTransaction)
				.createQueryBuilder("ft")
				.select([
					"SUM(amount_paid) AS total_amount_paid",
					"COUNT(DISTINCT(student_id)) AS total_students"
				])
				.where("DATE_FORMAT(ft.paydate, '%Y-%m-%d') BETWEEN :fromDate AND :toDate")
				.setParameter("fromDate", f_paydate)
				.setParameter("toDate", t_paydate)
				.getRawOne();

			const daily_tr_res = {
				amount: daily_tr.total_amount_paid,
				no_of_student: daily_tr.total_students
			};
			result.daily_trans = daily_tr_res;

			// to get fully paid and partially paid for the selected date range or today's date
			const q_main = getManager()
				.getRepository(FeeRegister)
				.createQueryBuilder("fr")
				.select([
					"fr_dt.is_paid_fully AS is_paid_fully",
					"fr_dt.amount_paid AS amount_paid",
					"fr.student_id AS student_id"
				])
				// .innerJoin(FeeRegister, "fr",
				// 	`fr.class_id = ft.class_id
				// 	AND fr.student_id = ft.student_id`)
				.innerJoin("fr.fee_reg_details", "fr_dt")
				// .where("ft.fee_master_id = fr_dt.fee_master_id")
				.where("DATE_FORMAT(fr_dt.paydate, '%Y-%m-%d') BETWEEN :fromDate AND :toDate")
				.getQuery();

			const daily_paid = await getManager()
				.createQueryBuilder()
				.select([
					"res.is_paid_fully AS is_paid_fully"
				])
				.addSelect("SUM(res.amount_paid) AS total_amount_paid")
				// .addSelect(
				// 	`CASE
				// 		WHEN res.is_paid_fully = true THEN SUM(res.amount_paid)
				// 		WHEN res.is_paid_fully = false THEN SUM(res.amount_paid)
				// 		ELSE 0
				// 	END`, "total_amount_paid"
				// )
				.from("(" + q_main + ")", "res")
				.groupBy("res.is_paid_fully")
				.setParameter("fromDate", f_paydate)
				.setParameter("toDate", t_paydate)
				.getRawMany();

			const daily_paid_stud = await getManager()
				.createQueryBuilder()
				.select([
					"res.is_paid_fully AS is_paid_fully",
					"COUNT(DISTINCT(res.student_id)) AS total_students"
				])
				// .addSelect(
				// 	`CASE
				// 		WHEN res.is_paid_fully = true THEN COUNT(DISTINCT(res.student_id))
				// 		WHEN res.is_paid_fully = false THEN COUNT(DISTINCT(res.student_id))
				// 		ELSE NULL
				// 	END`, "total_students"
				// )
				.from("(" + q_main + ")", "res")
				.groupBy("res.is_paid_fully")
				.setParameter("fromDate", f_paydate)
				.setParameter("toDate", t_paydate)
				.getRawMany();

			let p_paid = {
				amount: 0,
				no_of_student: 0
			};

			let f_paid = {
				amount: 0,
				no_of_student: 0
			};

			_.map(daily_paid, d => {
				if (d.is_paid_fully) {
					f_paid = {
						amount: d.total_amount_paid,
						no_of_student: 0
					};
				} else {
					p_paid = {
						amount: d.total_amount_paid,
						no_of_student: 0
					};
				}
				return;
			});

			_.map(daily_paid_stud, d => {
				if (d.is_paid_fully) {
					f_paid = { ...f_paid, no_of_student: d.total_students };
				} else {
					p_paid = { ...p_paid, no_of_student: d.total_students };
				}
				return;
			});

			result.fully_paid = f_paid;
			result.partially_paid = p_paid;

			return result;

		} catch (error) {
			throw new InternalServerError("getTransWidgetRpt: ", error);
		}
	}

	public async getClassFeeReport(
		class_id: string,
		fromDate: Date,
		toDate: Date,
		rpt_type: string,
		particulars_id: string,
		installments_id: string): Promise<any> {
		try {

			let result: Array<any> = [];

			let f_paydate = moment().format("YYYY-MM-DD");
			let t_paydate = moment().format("YYYY-MM-DD");

			if (fromDate) {
				f_paydate = moment(fromDate).format("YYYY-MM-DD");
			}
			if (toDate) {
				t_paydate = moment(toDate).format("YYYY-MM-DD");
			}

			// to get class-wise fee report
			const qb_cl = getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("cl")
				.select([
					"cl.id AS class_id",
					"CONCAT(cl.name, ' - ', cl.section) AS class_name",
					"cl.orderby AS cls_orderby",

					"st.id AS student_id",
					"CONCAT(st.firstname, ' ', st.lastname) AS student_name",
					"st.studentno AS studentno",

					"fp.id AS fee_particulars_id",
					"fp.name AS particulars_name",

					"fi.fee_period AS fee_period",
					"fi.term_name AS term_name",
					"fi.no_of_months AS no_of_months",

					"fm.id AS fee_master_id",
					"fm.amount AS payable_amount",
					"fm.due_date AS due_date",

					"reg.amount_paid AS amount_paid",
					"reg.amount_discount AS amount_discount",
					"reg.amount_balance AS amount_balance",
					"reg.paydate AS paydate"
				])
				.addSelect(
					`CASE
						WHEN reg.is_paid_fully = true THEN "FULLY_PAID"
						WHEN reg.is_paid_fully = false THEN "PARTIALLY_PAID"
						ELSE "NOT_PAID"
					END`, "paid_status"
				)
				.leftJoin("cl.students", "st")
				.leftJoin(FeeMaster, "fm", "cl.id = fm.class_id")
				// .leftJoinAndMapMany("fm.class_id", ClassSections, "cl", "cl.id = fm.class_id")
				.innerJoinAndMapMany("fm.fee_particulars_id", FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.innerJoinAndMapMany("fm.fee_installments_id", FeeInstallments, "fi", "fi.id = fm.fee_installments_id")
				.leftJoin(subQry => {
					const qb = subQry
						.select([
							"r.class_id AS class_id",
							"r.student_id AS student_id",
							"r_dt.is_paid_fully AS is_paid_fully",
							"r_dt.amount_paid AS amount_paid",
							"r_dt.amount_discount AS amount_discount",
							"r_dt.amount_balance AS amount_balance",
							"r_dt.fee_master_id AS fee_master_id",
							"r_dt.paydate AS paydate"
						])
						.from(FeeRegister, "r")
						.leftJoin("r.fee_reg_details", "r_dt");
					return qb;
				}, "reg", "reg.fee_master_id = fm.id AND reg.class_id = cl.id AND reg.student_id = st.id")
				.where("DATE_FORMAT(fm.due_date, '%Y-%m-%d') <= :toDate");

			if (class_id && class_id !== "ALL") {
				qb_cl.andWhere("fm.class_id = :classId");
			}
			if (particulars_id && particulars_id !== "ALL") {
				qb_cl.andWhere("fp.id = :particulars_id");
			}
			if (installments_id && installments_id !== "ALL") {
				qb_cl.andWhere("fi.id = :installments_id");
			}

			const qb_res = qb_cl.getQuery();

			const final_qry = getManager()
				.createQueryBuilder()
				.select("res.*")
				.from("(" + qb_res + ")", "res");

			if (rpt_type === "NOT_PAID") {
				final_qry.andWhere("paid_status = 'NOT_PAID'");
			}
			if (rpt_type === "PARTIALLY_PAID") {
				final_qry.andWhere("paid_status = 'PARTIALLY_PAID'");
			}
			if (rpt_type === "FULLY_PAID") {
				final_qry.andWhere("paid_status = 'FULLY_PAID'");
			}

			result = await final_qry
				.orderBy("res.cls_orderby", "ASC")
				.addOrderBy("res.student_name", "ASC")
				.setParameter("classId", class_id)
				.setParameter("fromDate", f_paydate)
				.setParameter("toDate", t_paydate)
				.setParameter("particulars_id", particulars_id)
				.getRawMany();

			return result;

		} catch (error) {
			throw new InternalServerError("getClassFeeReport: ", error);
		}
	}

	public async getFeeSummaryReport(): Promise<any> {
		try {

			const due_date = moment().format("YYYY-MM-DD");

			const q_cl = getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("cl")
				.select([
					"cl.id AS class_id",
					"CONCAT(cl.name, ' - ', cl.section) AS cl_name",
					"COUNT(st.firstname) AS noofst"
				])
				.leftJoin("cl.students", "st")
				.where("st.isactive = true")
				.groupBy("class_id")
				.addGroupBy("cl_name")
				.getQuery();

			const q_fm = getManager()
				.getRepository(FeeMaster)
				.createQueryBuilder("fm")
				.select([
					"fm.class_id AS class_id",
					"SUM(fm.amount) as per_st_amount"
				])
				.where("fm.due_date <= :dueDate")
				.groupBy("fm.class_id")
				.getQuery();

			const q_reg = getManager()
				.getRepository(FeeRegister)
				.createQueryBuilder("fr")
				.select([
					"fr.class_id as class_id",
					"SUM(fr.total_amount_paid) as t_amt"
				])
				.groupBy("fr.class_id")
				.getQuery();

			const res = getManager()
				.createQueryBuilder()
				.select([
					"cl.cl_name AS class_name",
					"cl.noofst AS no_of_st",
					"m.per_st_amount AS per_st_amount",
					"(m.per_st_amount * cl.noofst) AS payable_amount",
					"r.t_amt AS total_amount_paid",
				])
				.addSelect(
					`CASE
						WHEN ((m.per_st_amount * cl.noofst) - r.t_amt) IS NULL THEN (m.per_st_amount * cl.noofst)
						ELSE ((m.per_st_amount * cl.noofst) - r.t_amt)
					END`, "overdue_amount"
				)
				.from("(" + q_cl + ")", "cl")
				.leftJoin("(" + q_fm + ")", "m", "cl.class_id = m.class_id")
				.leftJoin("(" + q_reg + ")", "r", "cl.class_id = r.class_id")
				.leftJoin(ClassSections, "cls", "cls.id = cl.class_id")
				.setParameter("dueDate", due_date)
				.orderBy("cls.orderby", "ASC")
				.getRawMany();

			return res;
		} catch (error) {
			throw new InternalServerError("getFeeSummaryReport: ", error);
		}
	}

	public async getStudentInvoice(
		class_id: string,
		student_id: string,
		from_date: Date,
		to_date: Date,
	): Promise<any> {
		try {

			const f_paydate = moment(from_date).format("YYYY-MM-DD");
			const t_paydate = moment(to_date).format("YYYY-MM-DD");

			const qb_cl = getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("cl")
				.select([
					"cl.id AS class_id",
					"CONCAT(cl.name, ' - ', cl.section) AS class_name",
					"cl.orderby AS cls_orderby",

					"st.id AS student_id",
					"CONCAT(st.firstname, ' ', st.lastname) AS student_name",
					"st.studentno AS studentno",

					"fp.id AS fee_particulars_id",
					"fp.name AS particulars_name",

					"fi.fee_period AS fee_period",
					"fi.term_name AS term_name",
					"fi.no_of_months AS no_of_months",

					"fm.id AS fee_master_id",
					"fm.amount AS payable_amount",
					"fm.due_date AS due_date",

					"ft.amount_paid AS amount_paid",
					"ft.amount_balance AS amount_balance",
					"ft.paydate AS paydate",

					"reg.amount_discount AS amount_discount"
				])
				.addSelect(
					`CASE
						WHEN reg.is_paid_fully = true THEN "FULLY_PAID"
						WHEN reg.is_paid_fully = false THEN "PARTIALLY_PAID"
						ELSE "NOT_PAID"
					END`, "paid_status"
				)
				.leftJoin("cl.students", "st")
				.leftJoin(FeeMaster, "fm", "cl.id = fm.class_id")
				.innerJoin(FeeTransaction, "ft",
					`ft.class_id = cl.id
					AND ft.student_id = st.id
					AND ft.fee_master_id = fm.id`)
				.innerJoinAndMapMany("fm.fee_particulars_id", FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.innerJoinAndMapMany("fm.fee_installments_id", FeeInstallments, "fi", "fi.id = fm.fee_installments_id")
				.innerJoin(subQry => {
					const qb = subQry
						.select([
							"r.class_id AS class_id",
							"r.student_id AS student_id",
							"r_dt.is_paid_fully AS is_paid_fully",
							"r_dt.amount_paid AS amount_paid",
							"r_dt.amount_discount AS amount_discount",
							"r_dt.amount_balance AS amount_balance",
							"r_dt.fee_master_id AS fee_master_id",
							"r_dt.paydate AS paydate",
							"r_dt.fee_trans_id AS fee_trans_id"
						])
						.from(FeeRegister, "r")
						.leftJoin("r.fee_reg_details", "r_dt")
						.where("r.class_id = :classId")
						.andWhere("r.student_id = :studentId")
						.andWhere("DATE_FORMAT(r_dt.paydate, '%Y-%m-%d') BETWEEN :fromDate AND :toDate");
					return qb;
				}, "reg",
					`reg.fee_master_id = fm.id
					AND reg.class_id = cl.id
					AND reg.student_id = st.id`)
				.where("reg.class_id = :classId")
				.andWhere("reg.student_id =:studentId")
				.andWhere("DATE_FORMAT(ft.paydate, '%Y-%m-%d') BETWEEN :fromDate AND :toDate")
				.orderBy("fi.term_name", "ASC")
				.addOrderBy("fp.name", "ASC")
				.addOrderBy("ft.paydate", "DESC");

			const q_res = await qb_cl
				.setParameter("classId", class_id)
				.setParameter("studentId", student_id)
				.setParameter("fromDate", f_paydate)
				.setParameter("toDate", t_paydate)
				.getRawMany();

			const q_total = {
				total_amount_paid: _.sumBy(q_res, "amount_paid"),
				total_amount_discount: _.sumBy(q_res, "amount_discount"),
				total_amount_balance: _.sumBy(q_res, "amount_balance")
			};

			const result = {
				rows: q_res,
				total: q_total
			};

			return result;

		} catch (error) {
			throw new InternalServerError("getFeeSummaryReport: ", error);
		}
	}

	public async getTransactionReport(
		class_id: string,
		from_date: Date,
		to_date: Date,
	): Promise<any> {
		try {

			const f_paydate = moment(from_date).format("YYYY-MM-DD");
			const t_paydate = moment(to_date).format("YYYY-MM-DD");

			const qb_cl = getManager()
				.getRepository(ClassSections)
				.createQueryBuilder("cl")
				.select([
					"cl.id AS class_id",
					"CONCAT(cl.name, ' - ', cl.section) AS class_name",
					"cl.orderby AS cls_orderby",

					"st.id AS student_id",
					"CONCAT(st.firstname, ' ', st.lastname) AS student_name",
					"st.studentno AS studentno",

					"fp.id AS fee_particulars_id",
					"fp.name AS particulars_name",

					"fi.fee_period AS fee_period",
					"fi.term_name AS term_name",
					"fi.no_of_months AS no_of_months",

					"fm.id AS fee_master_id",
					"fm.amount AS payable_amount",
					"fm.due_date AS due_date",

					"ft.amount_paid AS amount_paid",
					"ft.amount_balance AS amount_balance",
					"ft.paydate AS paydate",

					"NULL AS amount_discount",
					"'' AS paid_status"
				])
				.leftJoin("cl.students", "st")
				.leftJoin(FeeMaster, "fm", "cl.id = fm.class_id")
				.innerJoin(FeeTransaction, "ft",
					`ft.class_id = cl.id
					AND ft.student_id = st.id
					AND ft.fee_master_id = fm.id`)
				.innerJoinAndMapMany("fm.fee_particulars_id", FeeParticulars, "fp", "fp.id = fm.fee_particulars_id")
				.innerJoinAndMapMany("fm.fee_installments_id", FeeInstallments, "fi", "fi.id = fm.fee_installments_id")
				.where("DATE_FORMAT(ft.paydate, '%Y-%m-%d') BETWEEN :fromDate AND :toDate");

			if (class_id !== "ALL") {
				qb_cl.andWhere("cl.id = :classId");
			}

			qb_cl.orderBy("cl.orderby", "ASC")
				.addOrderBy("ft.paydate", "DESC")
				.addOrderBy("fi.term_name", "ASC")
				.addOrderBy("fp.name", "ASC");

			const q_res = await qb_cl
				.setParameter("classId", class_id)
				.setParameter("fromDate", f_paydate)
				.setParameter("toDate", t_paydate)
				.getRawMany();

			const q_total = {
				total_amount_paid: _.sumBy(q_res, "amount_paid"),
				total_amount_discount: 0,
				total_amount_balance: _.sumBy(q_res, "amount_balance")
			};

			const result = {
				rows: q_res,
				total: q_total
			};

			return result;

		} catch (error) {
			throw new InternalServerError("getTransactionReport: ", error);
		}
	}

}