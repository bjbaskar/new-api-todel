

interface IAmountCount {
	amount: number;
	no_of_student: number;
}

export interface ITransWidgetReport {
	daily_trans: IAmountCount;
	// overdue: IAmountCount;
	partially_paid: IAmountCount;
	fully_paid: IAmountCount;
}