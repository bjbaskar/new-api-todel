export interface IFeeDetails {
	id: string;
	paydate: Date;
	fee_register_id: string;
	fee_master_id: string;
	pay_mode: string;
	amount_payable: number;
	amount_discount: number;
	amount_paid: number;
	amount_balance: number;
	is_paid_fully: boolean;
	receipt_no: number;
	createdby: string;
	updatedby: string;
}

export interface IFeeRegister {
	id: string;
	paydate: Date;
	class_id: string;
	student_id: string;
	fee_details: Array<IFeeDetails>;
	pay_mode: string;
	total_amount_payable: number;
	total_amount_discount: number;
	total_amount_paid: number;
	total_amount_balance: number;
	acad_year: string;
	school_id: string;
	createdby: string;
	updatedby: string;
}

export interface IFeeDailyTransaction {
	id: string;
	paydate: Date;
	class_id: string;
	student_id: string;
	fee_master_id: string;
	pay_mode: string;
	amount_paid: number;
	amount_balance: number;
	receipt_no: number;
	receipt_duplicate: number;
	iscancel: boolean;
	cancel_reason: string;
	fee_trans_id: string;
	acad_year: string;
	school_id: string;
	createdby: string;
	updatedby: string;
}

export interface IFeeParams {
	receipt_no: number;
	class_id: string;
	student_id: string;
	pay_mode: string;
	paydate: Date;
	trans_id: string;
}