import { injectable, inject } from "inversify";
import { getManager } from "typeorm";
import { IFeeStudentConfig } from "./IFeeStudentConfig";
import { FeeStudentConfig } from "../../core/entities/Fee/FeeStudentConfig";
import { InternalServerError } from "../../core/exceptions";

@injectable()
export class FeeStudentConfigService {
	constructor() { }

	public async addFeeStudent(feeStud: IFeeStudentConfig, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeStudentConfig(), feeStud);
			entity.createdby = currentUser;

			const res = await getManager()
				.getRepository(FeeStudentConfig)
				.save(entity);
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async editFeeStudent(id: string, feeStud: IFeeStudentConfig, currentUser: string): Promise<any> {
		try {
			const entity = Object.assign(new FeeStudentConfig(), feeStud);
			entity.updatedby = currentUser;

			const res = await getManager()
				.getRepository(FeeStudentConfig)
				.update(id, entity);

			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async delFeeStudent(id: string, currentUser: string): Promise<any> {
		try {
			const res = await getManager()
				.createQueryBuilder()
				.delete()
				.from(FeeStudentConfig)
				.where("id = :id", { id: id })
				.execute();
			if (res.affected >= 1) {
				return { Messages: "Deleted successfully" };
			} else {
				return { Messages: "No Records Deleted" };
			}
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async listFeeStudent(): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeStudentConfig)
				.createQueryBuilder("fsc")
				.orderBy("fsc.class_sec", "ASC")
				.getMany();
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}

	public async findFeeStudentById(id: string): Promise<any> {
		try {
			const res = await getManager()
				.getRepository(FeeStudentConfig)
				.findOne({ where: { id: id } });
			return res;
		} catch (error) {
			throw new InternalServerError("Unhandled Error", error);
		}
	}
}
