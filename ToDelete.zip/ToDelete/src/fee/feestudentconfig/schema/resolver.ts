import { IAppContext } from "../../../context";
import { IFeeStudentConfig } from "../IFeeStudentConfig";

export const resolvers = {
	Query: {
		async getFeeStudent(_: any, args: { id: string }, context: IAppContext) {
			const svc = context.FeeStudentConfigService;
			return await svc.findFeeStudentById(args.id);
		},
		async getAllFeeStudent(_: any, args: any, context: IAppContext) {
			return await context.FeeStudentConfigService.listFeeStudent();
		}
	},
	Mutation: {
		async addFeeStudent(root: any, args: { input: IFeeStudentConfig }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeStudentConfigService.addFeeStudent(args.input, currentUser);
			return res;
		},
		async editFeeStudent(
			root: any,
			args: { id: string, input: IFeeStudentConfig },
			context: IAppContext
		) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeStudentConfigService.editFeeStudent(args.id, args.input, currentUser);
			return res;
		},
		async delFeeStudent(root: any, args: { id: string }, context: IAppContext) {
			const currentUser = context.CurrentUser.UserName;
			const res = await context.FeeStudentConfigService.delFeeStudent(args.id, currentUser);
			return res;
		}
	}
};
