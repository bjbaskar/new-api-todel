import { typeDef } from "./typeDef";
import { resolvers } from "./resolver";

const feeStudentConfigType = typeDef;
const feeStudentConfigResolver = resolvers;

export { feeStudentConfigType, feeStudentConfigResolver };
