export interface IFeeStudentConfig {
	id: string;
	class_sec: string;
	student_id: string;
	fee_class: string;
	isactive: boolean;
	acad_year: string;
	school_id: string;
}